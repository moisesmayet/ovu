--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3 (Debian 12.3-1.pgdg100+1)
-- Dumped by pg_dump version 12.3 (Debian 12.3-1.pgdg100+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_algoritmo; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_algoritmo (
    id integer NOT NULL,
    formula text NOT NULL,
    unidad_medida character varying(100) NOT NULL,
    metodologia text,
    descripcion text,
    indicador_id integer NOT NULL
);


ALTER TABLE public.core_algoritmo OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_algoritmo_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_algoritmo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_algoritmo_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_algoritmo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_algoritmo_id_seq OWNED BY public.core_algoritmo.id;


--
-- Name: core_componente; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_componente (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    codigo character varying(5) NOT NULL,
    descripcion text,
    eliminable boolean NOT NULL,
    visible boolean NOT NULL
);


ALTER TABLE public.core_componente OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_componente_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_componente_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_componente_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_componente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_componente_id_seq OWNED BY public.core_componente.id;


--
-- Name: core_corte; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_corte (
    id integer NOT NULL,
    periodo character varying(3) NOT NULL,
    visible boolean NOT NULL,
    nombre character varying(100),
    descripcion text,
    ano smallint NOT NULL,
    CONSTRAINT core_corte_ano_check CHECK ((ano >= 0))
);


ALTER TABLE public.core_corte OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_corte_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_corte_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_corte_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_corte_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_corte_id_seq OWNED BY public.core_corte.id;


--
-- Name: core_dato; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_dato (
    id integer NOT NULL,
    valor numeric(11,3) NOT NULL,
    corte_id integer NOT NULL,
    indicador_id integer NOT NULL,
    segregacion_id integer NOT NULL
);


ALTER TABLE public.core_dato OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_dato_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_dato_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_dato_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_dato_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_dato_id_seq OWNED BY public.core_dato.id;


--
-- Name: core_fuenteinformacion; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_fuenteinformacion (
    id integer NOT NULL,
    fuente_informacion character varying(50) NOT NULL,
    web character varying(200),
    registrado date NOT NULL,
    indicador_id integer,
    termino_id integer
);


ALTER TABLE public.core_fuenteinformacion OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_fuenteinformacion_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_fuenteinformacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_fuenteinformacion_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_fuenteinformacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_fuenteinformacion_id_seq OWNED BY public.core_fuenteinformacion.id;


--
-- Name: core_indicador; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_indicador (
    id integer NOT NULL,
    nombre character varying(200) NOT NULL,
    codigo character varying(10) NOT NULL,
    descripcion text,
    definicion text,
    eliminable boolean NOT NULL,
    visible boolean NOT NULL,
    cobertura_geografica character varying(5) NOT NULL,
    periodicidad character varying(2) NOT NULL,
    lectura text NOT NULL,
    observaciones text,
    componente_id integer NOT NULL
);


ALTER TABLE public.core_indicador OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_indicador_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_indicador_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_indicador_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_indicador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_indicador_id_seq OWNED BY public.core_indicador.id;


--
-- Name: core_informe; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_informe (
    id integer NOT NULL,
    fecha date NOT NULL,
    archivo character varying(100) NOT NULL,
    visible boolean NOT NULL,
    url character varying(200) NOT NULL
);


ALTER TABLE public.core_informe OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_informe_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_informe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_informe_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_informe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_informe_id_seq OWNED BY public.core_informe.id;


--
-- Name: core_objetivos; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_objetivos (
    id integer NOT NULL,
    objetivo character varying(100) NOT NULL,
    ovu_id integer NOT NULL
);


ALTER TABLE public.core_objetivos OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_objetivos_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_objetivos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_objetivos_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_objetivos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_objetivos_id_seq OWNED BY public.core_objetivos.id;


--
-- Name: core_ovu; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_ovu (
    id integer NOT NULL,
    nombre character varying(15),
    definicion text NOT NULL
);


ALTER TABLE public.core_ovu OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_ovu_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_ovu_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_ovu_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_ovu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_ovu_id_seq OWNED BY public.core_ovu.id;


--
-- Name: core_referencia; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_referencia (
    id integer NOT NULL,
    institucion character varying(100)
);


ALTER TABLE public.core_referencia OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_referencia_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_referencia_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_referencia_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_referencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_referencia_id_seq OWNED BY public.core_referencia.id;


--
-- Name: core_referencia_indicador; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_referencia_indicador (
    id integer NOT NULL,
    referencia_id integer NOT NULL,
    indicador_id integer NOT NULL
);


ALTER TABLE public.core_referencia_indicador OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_referencia_indicador_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_referencia_indicador_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_referencia_indicador_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_referencia_indicador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_referencia_indicador_id_seq OWNED BY public.core_referencia_indicador.id;


--
-- Name: core_segregacion; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_segregacion (
    id integer NOT NULL,
    parametro character varying(100) NOT NULL,
    parametro_opcional character varying(100)
);


ALTER TABLE public.core_segregacion OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_segregacion_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_segregacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_segregacion_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_segregacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_segregacion_id_seq OWNED BY public.core_segregacion.id;


--
-- Name: core_segregacion_indicador; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_segregacion_indicador (
    id integer NOT NULL,
    segregacion_id integer NOT NULL,
    indicador_id integer NOT NULL
);


ALTER TABLE public.core_segregacion_indicador OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_segregacion_indicador_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_segregacion_indicador_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_segregacion_indicador_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_segregacion_indicador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_segregacion_indicador_id_seq OWNED BY public.core_segregacion_indicador.id;


--
-- Name: core_termino; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.core_termino (
    id integer NOT NULL,
    tipo character varying(1) NOT NULL,
    variable text,
    definicion text,
    algoritmo_id integer NOT NULL
);


ALTER TABLE public.core_termino OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_termino_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.core_termino_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.core_termino_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: core_termino_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.core_termino_id_seq OWNED BY public.core_termino.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO "PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF";

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: core_algoritmo id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_algoritmo ALTER COLUMN id SET DEFAULT nextval('public.core_algoritmo_id_seq'::regclass);


--
-- Name: core_componente id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_componente ALTER COLUMN id SET DEFAULT nextval('public.core_componente_id_seq'::regclass);


--
-- Name: core_corte id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_corte ALTER COLUMN id SET DEFAULT nextval('public.core_corte_id_seq'::regclass);


--
-- Name: core_dato id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato ALTER COLUMN id SET DEFAULT nextval('public.core_dato_id_seq'::regclass);


--
-- Name: core_fuenteinformacion id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_fuenteinformacion ALTER COLUMN id SET DEFAULT nextval('public.core_fuenteinformacion_id_seq'::regclass);


--
-- Name: core_indicador id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_indicador ALTER COLUMN id SET DEFAULT nextval('public.core_indicador_id_seq'::regclass);


--
-- Name: core_informe id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_informe ALTER COLUMN id SET DEFAULT nextval('public.core_informe_id_seq'::regclass);


--
-- Name: core_objetivos id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_objetivos ALTER COLUMN id SET DEFAULT nextval('public.core_objetivos_id_seq'::regclass);


--
-- Name: core_ovu id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_ovu ALTER COLUMN id SET DEFAULT nextval('public.core_ovu_id_seq'::regclass);


--
-- Name: core_referencia id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia ALTER COLUMN id SET DEFAULT nextval('public.core_referencia_id_seq'::regclass);


--
-- Name: core_referencia_indicador id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia_indicador ALTER COLUMN id SET DEFAULT nextval('public.core_referencia_indicador_id_seq'::regclass);


--
-- Name: core_segregacion id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion ALTER COLUMN id SET DEFAULT nextval('public.core_segregacion_id_seq'::regclass);


--
-- Name: core_segregacion_indicador id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion_indicador ALTER COLUMN id SET DEFAULT nextval('public.core_segregacion_indicador_id_seq'::regclass);


--
-- Name: core_termino id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_termino ALTER COLUMN id SET DEFAULT nextval('public.core_termino_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add social account	9	add_socialaccount
34	Can change social account	9	change_socialaccount
35	Can delete social account	9	delete_socialaccount
36	Can view social account	9	view_socialaccount
37	Can add social application	10	add_socialapp
38	Can change social application	10	change_socialapp
39	Can delete social application	10	delete_socialapp
40	Can view social application	10	view_socialapp
41	Can add social application token	11	add_socialtoken
42	Can change social application token	11	change_socialtoken
43	Can delete social application token	11	delete_socialtoken
44	Can view social application token	11	view_socialtoken
45	Can add Token	12	add_token
46	Can change Token	12	change_token
47	Can delete Token	12	delete_token
48	Can view Token	12	view_token
49	Can add token	13	add_tokenproxy
50	Can change token	13	change_tokenproxy
51	Can delete token	13	delete_tokenproxy
52	Can view token	13	view_tokenproxy
53	Can add user	14	add_user
54	Can change user	14	change_user
55	Can delete user	14	delete_user
56	Can view user	14	view_user
57	Can add algoritmo	15	add_algoritmo
58	Can change algoritmo	15	change_algoritmo
59	Can delete algoritmo	15	delete_algoritmo
60	Can view algoritmo	15	view_algoritmo
61	Can add componente	16	add_componente
62	Can change componente	16	change_componente
63	Can delete componente	16	delete_componente
64	Can view componente	16	view_componente
65	Can add corte	17	add_corte
66	Can change corte	17	change_corte
67	Can delete corte	17	delete_corte
68	Can view corte	17	view_corte
69	Can add indicador	18	add_indicador
70	Can change indicador	18	change_indicador
71	Can delete indicador	18	delete_indicador
72	Can view indicador	18	view_indicador
73	Can add ovu	19	add_ovu
74	Can change ovu	19	change_ovu
75	Can delete ovu	19	delete_ovu
76	Can view ovu	19	view_ovu
77	Can add termino	20	add_termino
78	Can change termino	20	change_termino
79	Can delete termino	20	delete_termino
80	Can view termino	20	view_termino
81	Can add Segregación	21	add_segregacion
82	Can change Segregación	21	change_segregacion
83	Can delete Segregación	21	delete_segregacion
84	Can view Segregación	21	view_segregacion
85	Can add referencia	22	add_referencia
86	Can change referencia	22	change_referencia
87	Can delete referencia	22	delete_referencia
88	Can view referencia	22	view_referencia
89	Can add objetivos	23	add_objetivos
90	Can change objetivos	23	change_objetivos
91	Can delete objetivos	23	delete_objetivos
92	Can view objetivos	23	view_objetivos
93	Can add Fuentes de información	24	add_fuenteinformacion
94	Can change Fuentes de información	24	change_fuenteinformacion
95	Can delete Fuentes de información	24	delete_fuenteinformacion
96	Can view Fuentes de información	24	view_fuenteinformacion
97	Can add dato	25	add_dato
98	Can change dato	25	change_dato
99	Can delete dato	25	delete_dato
100	Can view dato	25	view_dato
101	Can add informe	26	add_informe
102	Can change informe	26	change_informe
103	Can delete informe	26	delete_informe
104	Can view informe	26	view_informe
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.


--
-- Data for Name: core_algoritmo; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_algoritmo (id, formula, unidad_medida, metodologia, descripcion, indicador_id) FROM stdin;
406	<p>AT=100-(TP+TR)</p>	Porcentaje  %	<p>Luego de calculadas las tasas de promoci&oacute;n y de repetici&oacute;n, se realiza una suma de ambas, dicho resultado se resta de 100, su diferencia resultara en la tasa de abandono.</p>		299
380	<p>CDE= (A/A+B)</p>	Coeficiente	<p>Se requiere construir la distribuci&oacute;n acumulada de los a&ntilde;os de escolaridad de la poblaci&oacute;n adulta, a partir de la informaci&oacute;n disponible en los censos de poblaci&oacute;n y/o encuestas de hogares. Se calcula a partir de la curva de Lorenz. En ella se relacionan los porcentajes acumulados de poblaci&oacute;n con, en este caso, porcentajes acumulados de a&ntilde;os de escolaridad que posee la poblaci&oacute;n. El coeficiente se obtiene dividiendo el &aacute;rea comprendida entre la recta de &ldquo;equidad perfecta&rdquo; y la curva de Lorenz por el &aacute;rea total bajo la recta mencionada.</p>		273
463	<p>CPEC= &sum;C<sub>ect</sub>/CT</p>	Promedio	<p>Se determina la sumatoria de costo de todos los tipos de educaci&oacute;n continua entre el costo total.</p>		356
411	<p>Dm= &Sigma;AEsG/GrT</p>	Porcentaje  %	<p>Se realiza una sumatoria de los a&ntilde;os de estudios de los graduados y se divide entre la cantidad de graduados.</p>		304
412	<p>Dm= &Sigma;NG/GrT</p>	Porcentaje  %	<p>Se realiza una sumatoria de las notal totales de todos los graduados y se divide entre la cantidad de graduados.</p>		305
396	<p>%EG=(EGG/TEG)*100</p>\n<p>%EG=(EGP/TEG)*100</p>	EGTS= Estudiantes graduados de nivel técnico superior	<p>TEG= Total de estudiantes graduados</p>		289
460	<p>EMC= ECE/n</p>	%	<p>Se determina a trav&eacute;s de los matriculados por campo de estudio entre el total de matriculados</p>	<p>EMC= % de estudiantes seg&uacute;n &aacute;rea de estudio</p>	353
436	<p>%EmNE=(EmNEi / TEm)*100</p>	Porcentaje	<p>Se determina dividiendo la cantidad de empleados con nivel educativo ( i ), entre el total de total de empleados, y el resultado se multiplica por 100.</p>	<p>%EmNE= Porcentaje de empleados por nivel educativo i= Doctorado, maestr&iacute;a, educaci&oacute;n b&aacute;sica</p>	329
461	<p>EmToR= EmToR/n</p>	%	<p>Se determina a trav&eacute;s de los matriculados por rama de estudio y tipo de oferta entre el total de matriculados</p>	<p>EmToR= % de estudiantes seg&uacute;n rama de estudio y tipo de oferta</p>	354
391	<p>%ENC=ENC/ENT</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		284
393	<p>%ENN= ENN/ENT</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		286
390	<p>%ENR= ENR/ENT</p>	porcentaje	<p>Se divide la cantidad de estudiantes de nuevo ingreso por escuela y recinto entre el total de estudiantes de nuevo ingreso</p>		283
397	<p>%ERG=(ERG/TERGR)*100</p>\n<p>%ERPg=(ERPg/TERPgR)*100</p>	Porcentaje	<p>Se determina dividiendo la cantidad de estudiantes de nivel grado y postgrado que se retiraron, entre el total estudiantes retirados de grado y postgrado en todos los recintos.</p>		290
427	<p>%ES= &Sigma;ES/TEE</p>	Porcentaje	<p>Se suma el total de empleados que respondieron estar satisfechos en general, con cada uno de los departamentos sobre el total de empleados encuestados, el resultado se multiplica por cien.</p>		320
379	<p>GPE<sub>PIB</sub>= (GPE<sub>i</sub>/PIB<sub>i</sub>) x 100</p>	Porcentaje	<p>Se divide el gasto p&uacute;blico en educaci&oacute;n en un a&ntilde;o espec&iacute;fico&lrm;, &lrm;entre el producto interno bruto total &lrm;(&lrm;a precios corrientes&lrm;) &lrm;para ese mismo a&ntilde;o&lrm;, el resultado se multiplica por 100.</p>		272
394	<p>Indicador estimado por el MESCyT</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		287
383	<p>IPG= TBM<sub>f</sub>/ TBM<sub>m</sub></p>	Relación	<p>Se divide la tasa bruta de matricula femenina entre la tasa bruta de matricula masculina</p>		276
452	<p>IR=&sum;NSG/CS</p>	Porcentaje	<p>Se determina mediante la sumatoria del Nivel de satisfacci&oacute;n por el uso de la red social Facebook sobre las categor&iacute;a de satisfacci&oacute;n, el resultado se multiplico por 100.</p>		345
431	<p>%Nepd= Ne<sub>i</sub>/Tpd</p>	Porcentaje	<p>Se divide nivel educativo del personal docente entre el total de personal docente, y el resultado se multiplica por 100</p>		324
378	<p>N<sub>t+a</sub> = N<sub>t</sub> + B<sub>t,t+a</sub> - D<sub>t,t+a</sub> +M<sub>t,t+a</sub></p>	Porcentaje	<p>Se suma la poblaci&oacute;n en el instante o poblaci&oacute;n de partida y los nacimientos ocurridos durante el per&iacute;odo de evaluaci&oacute;n y se le restan las defunciones ocurridas durante el per&iacute;odo de evaluaci&oacute;n, para luego sumarles los migrantes netos estimados en ese mismo periodo</p>		271
410	<p>TET= (AETR/TAE)*100</p>	Porcentaje	<p>Se divide la cantidad de Alumnos egresados en el tiempo m&iacute;nimo requerido, entre el total alumnos egresados y el resultado se multiplica por 100</p>		303
446	<p>%PAcrs<sub>t</sub>=PAcrs<sub>I</sub>/TPAcrs</p>	Porcentaje	<p>Se dividen Participantes en actividades de responsabilidad social, seg&uacute;n tipo de proyecto entre Total de participantes en actividades de responsabilidad social, y el resultado se multiplica por 100</p>		339
434	<p>%PASmt=(TPASmt/PAS)*100</p>	Porcentaje	<p>Se divide el total personal administrativo y de servicios de medio tiempo entre el total del personal administrativo y de servicios y el resultado se multiplica por 100</p>		327
433	<p>%PAStc=(TPAStc/PAS)*100</p>	Porcentaje	<p>Se divide el total personal administrativo y de servicios que trabaja tiempo completo entre el total del personal administrativo y de servicios y el resultado se multiplica por 100</p>		326
432	<p>PDF=&Sigma;TPDF</p>	Sumatoria	<p>Se sum&oacute; el total de personal docente que se desempe&ntilde;a como: personal administrativo y labores docentes.</p>		325
430	<p>%PDmt=(TPDmt/TPD)*100</p>	Porcentaje	<p>Se divide el total personal docente de medio tiempo entre el total del personal docente y el resultado se multiplica por 100</p>		323
428	<p>%PDph=(TPDph/TPD)*100</p>	Porcentaje	<p>Se divide el total personal docente por horas entre el total del personal docente y el resultado se multiplica por 100</p>		321
429	<p>%PDtc=(TPDtc/TPD)*100</p>	Porcentaje	<p>Se divide el total personal docente tiempo completo entre el total del personal docente y el resultado se multiplica por 100</p>		322
456	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		349
424	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		317
423	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		316
422	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		315
421	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		314
420	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		313
419	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		312
418	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		311
417	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		310
416	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		309
415	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		308
414	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		307
413	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		306
402	<p>Pendiente de Informaci&oacute;n</p>	Porcentaje			295
399	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		292
392	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		285
389	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		282
388	<p>Pendiente de Informaci&oacute;n</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		281
404	<p>PERP=ERP/TET</p>	Porcentaje	<p>Es el resultado de la sumatoria de la cantidad de egresados que estar&iacute;an dispuestos a realizar alg&uacute;n postgrado en la UAPA entre el total de estudiantes egresados</p>		297
403	<p>PET=ET<sub>u</sub>/TET</p>	Porcentaje	<p>Es el resultado de la sumatoria de la cantidad de egresados seg&uacute;n la universidad de referencia entre el total de estudiantes egresados que se transfirieron</p>		296
405	<p>PETP=ETP/TEE</p>	Porcentaje	<p>Es el resultado de la sumatoria de la cantidad de egresados Estudiantes que terminaron en el tiempo de su pensum entre el total de estudiantes egresados</p>		298
450	<p>PUR<sub>F</sub>=&sum;TI/CI</p>	Porcentaje	<p>Se determina mediante la sumatoria del total de ingresos a la red social Facebook sobre las categor&iacute;as de ingreso, el resultado se multiplico por 100.</p>		343
435	<p>RPAS/Pdocente</p>	Relación	<p>Se divide el total Personal Administrativo y de servicios entre Personal docente.</p>		328
400	<p>RPA= TA/TP</p>	Razón	<p>Se obtiene al dividir la cantidad de estudiantes matriculados entre el total de docentes.</p>		293
426	<p>%SEgpe= &Sigma;ESgpe/TEE</p>	Porcentaje	<p>Se suma el total de estudiantes que respondieron estar satisfechos en general, con cada una de las escuelas y los diferentes servicios ofrecidos sobre el total de estudiantes encuestados, el resultado se multiplica por cien.</p>		319
425	<p>%SEgpe= &Sigma;ESgpe/TEE</p>	Porcentaje	<p>Se suma el total de estudiantes que respondieron estar satisfechos en general, con cada una de las escuelas y los diferentes servicios ofrecidos, sobre el total de estudiantes encuestados, el resultado se multiplica por cien.</p>		318
444	<p>TAcPex=&sum;AcPex</p>	Sumatoria	<p>Se sumaron todas la actividades realizas por un programa de extensi&oacute;n de la UAPA</p>		337
381	<p>TA= (TAA<sub>15</sub>+/PT<sub>15</sub>+) x 100</p>	Porcentaje	<p>Se calcula dividiendo el total de la poblaci&oacute;n analfabeta de 15 a&ntilde;os y m&aacute;s de edad sobre total de la poblaci&oacute;n de 15 a&ntilde;os y m&aacute;s, y multiplicamos este cociente por 100.</p>		274
382	<p>TBM= TNS<sub>18-24</sub> / TNS</p>	Relación	<p>Se divide el n&uacute;mero de alumnos matriculados del nivel superior independientemente de su edad, por la poblaci&oacute;n de 18 a 24 a&ntilde;os (edad que corresponde oficialmente a ese nivel de ense&ntilde;anza) por cien (100).</p>		275
449	<p>TCPurs=&sum;CPurs</p>	Sumatoria	<p>Se sumaron todos los comentarios seg&uacute;n la categor&iacute;a aplicada al tipo de comentario, favorable o desfavorable en las redes sociales.</p>		342
462	<p>TEED= &sum;EED</p>	Sumatoria	<p>Se determina la sumatoria del los estudiantes egresados del programa habilitaci&oacute;n docente.</p>		355
455	<p>TEE<sub>x</sub>= EGEA/ET</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		348
395	<p>TEM= &sum;TEMi</p>	'Sumatoria	<p>Es la sumatoria del total de estudiantes matriculados en un per&iacute;odo de tiempo determinado.</p>		288
437	<p>TEnivYco= &sum;ENivyCO</p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de empleados seg&uacute;n la categorizaci&oacute;n de empleados, cruzado con su nivel educativo.</p>		330
401	<p>TER= &sum;TERi</p>	Sumatoria	<p>Se obtiene a trav&eacute;s de la sumatoria de los estudiantes matriculados reinscritos en otra titulaci&oacute;n o post grado en la universidad en un periodo de tiempo determinado.</p>		294
458	<p>TE<sub>q</sub>= &sum;E<sub>q</sub></p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de equipos que dispone la UAPA para actividades acad&eacute;micas seg&uacute;n recinto.</p>		351
408	<p>Tex= CSA/CPA</p>	Porcentaje  %	<p>Se obtienen el numero de cr&eacute;ditos superados por la poblaci&oacute;n total de alumnos y el numero de cr&eacute;ditos presentados en examen por dicha cantidad de alumnos y se divide el resultado de las variables en el orden mencionado anteriormente</p>		301
409	<p>TG= (GT/GE)*100</p>	Porcentaje  %	<p>Se divide el total de graduandos entre el total esperado y se multiplica dicho resultado por cien</p>		302
377	<p>TIA= [(IPC<sub>f</sub>- IPC<sub>i</sub>) / IPC<sub>i</sub>] x 100</p>	Porcentaje	<p>Se determina mediante la resta del &iacute;ndice de precio al consumidor final y el &Iacute;ndice de precio al consumidor inicial dividido entre &Iacute;ndice de precio al consumidor inicial, el resultado se multiplica por 100.</p>		270
448	<p>TIDrs=&sum;IDrs</p>	Sumatoria	<p>Se sumaron los diferentes tipos de Informaci&oacute;n que se difunden en redes sociales que dispone la UAPA</p>		341
454	<p>TIL= EEA/ET</p>	Sin mayor detalle	<p>Sin mayor detalle</p>		347
440	<p>TIP=&sum;IP</p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de manuscritos realizados por el personal institucional sujetos a arbitraje y el estatus.</p>		333
439	<p>TIR<sub>t</sub>=&sum;IR</p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de investigaciones realizadas por el personal de la UAPA y el estatus de los trabajos</p>		332
453	<p>TMg<sub>t</sub>=&sum;MgRsF<sub>t</sub></p>	Sumatoria	<p>Sin mayor detalle</p>		346
386	<p>TOA= &sum;TOAie</p>	Sin mayor detalle	<p>Se determina mediante la sumatoria de la cantidad de programas de postgrados ofertadas en la UAPA seg&uacute;n el recinto.</p>		279
387	<p>TOA= &sum;TOAies</p>	Sin mayor detalle	<p>Se determina mediante la sumatoria de la cantidad de carreras ofertadas en la UAPA seg&uacute;n la Escuela.</p>		280
385	<p>TOA= &sum;TOA<sub>ie</sub></p>	Sin mayor detalle	<p>Se determina mediante la sumatoria de la cantidad de programas de grados ofertadas en la UAPA seg&uacute;n el recinto.</p>		278
384	<p>TOA= &sum;TOA<sub>i</sub></p>	Sin mayor detalle	<p>Se determina mediante la sumatoria de la cantidad de carreras ofertadas seg&uacute;n el nivel acad&eacute;mico.</p>		277
443	<p>TPex=&sum;Pex</p>	Sumatoria	<p>Se sumaron todas las programas de extensi&oacute;n que se realizan en la universidad UAPA</p>		336
438	<p>TPI<sub>t</sub>=&sum;PI</p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de personal que investiga en la UAPA seg&uacute;n titulaci&oacute;n acad&eacute;mica y recinto de trabajo</p>		331
398	<p>TPPA= &sum;TPPAi</p>	Sumatoria	<p>Es la sumatoria del total de estudiantes a prueba acad&eacute;mica por no alcanzar que su &iacute;ndice cuatrimestral sea menor de 2.00, excepto el primer cuatrimestre y que su &iacute;ndice acumulado sea menor de 2.00, excepto el primer cuatrimestre en un periodo de tiempo determinado.</p>		291
442	<p>TPP<sub>t</sub>=&sum;PP</p>	Sumatoria	<p>Se sumaron todas las publicaciones autor&iacute;a de la universidad UAPA que est&aacute;n en proceso</p>		335
445	<p>TPrs<sub>t</sub>=&sum;Prs</p>	Sumatoria	<p>Se sumaron todas las proyectos de responsabilidad social que se realizan en la universidad UAPA</p>		338
441	<p>TPR=&sum;PR</p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de publicaciones con sello editorial o institucional de la UAPA.</p>		334
407	<p>Trend= EGT/AICT</p>	Porcentaje  %	<p>Se divide la cantidad de egresados totales, entre la cantidad de alumnos inscritos que cumplieron el tiempo requerido para el grado.</p>		300
447	<p>TRS=&sum;RS</p>	Sumatoria	<p>Se contabilizaron y sumaron todas las cuentas activas en redes sociales que dispone la UAPA</p>		340
457	<p>TR<sub>ec</sub>= &sum;TR<sub>aa</sub></p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de&nbsp;espacios para actividades acad&eacute;micas seg&uacute;n recinto.</p>		350
451	<p>TS<sub>t</sub>=&sum;S</p>	Sumatoria	<p>Se determina por medio a la sumatoria del total de seguidores en los diferentes medios sociales</p>		344
459	<p>TT<sub>ec</sub>= &sum;T<sub>b</sub></p>	Sumatoria	<p>Se determina mediante la sumatoria de la cantidad de butacas destinadas a la formaci&oacute;n acad&eacute;mica presencial seg&uacute;n recinto.</p>		352
\.


--
-- Data for Name: core_componente; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_componente (id, nombre, codigo, descripcion, eliminable, visible) FROM stdin;
60	Contexto económico y social	C0	\N	f	t
61	Oferta Académica	C1	\N	f	t
62	Demanda Universitaria	C2	\N	f	t
63	Procesos Académicos	C3	\N	f	t
64	Resultados Académicos	C4	\N	f	t
65	Satisfacción de los Usuarios	C5	\N	f	t
66	Recursos Humanos	C6	\N	f	t
68	Extension y Responsabilidad Social	C8	\N	f	t
69	Redes Sociales	C9	\N	f	t
70	Inserción Laboral	C10	\N	f	t
71	Patrimonio de la  Universidad	C11	\N	f	t
72	Educación Continua	C12	\N	f	t
67	Investigación y Publicaciones	C7	<p>Note that Thymeleaf has integrations for both versions 3.x and 4.x of the Spring Framework, provided by two separate libraries called <code>thymeleaf-spring3</code> and <code>thymeleaf-spring4</code>. These libraries are packaged in separate <code>.jar</code> files (<code>thymeleaf-spring3-{version}.jar</code> and <code>thymeleaf-spring4-{version}.jar</code>) and need to be added to your classpath in order to use Thymeleaf&rsquo;s Spring integrations in your application.</p>	f	t
\.


--
-- Data for Name: core_corte; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_corte (id, periodo, visible, nombre, descripcion, ano) FROM stdin;
1	a	t	Anual 2017		2017
2	a	t	Anual 2018		2018
3	a	t	Anual 2019		2019
4	a	t	Anual 2020		2020
5	a	t	Anual 2021		2021
6	a	t	Anual 2011		2011
\.


--
-- Data for Name: core_dato; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_dato (id, valor, corte_id, indicador_id, segregacion_id) FROM stdin;
1	22.000	1	277	24736
2	15.000	1	277	24737
3	1.000	1	277	24738
2042	21.000	2	277	24738
2043	13.000	2	277	24737
2044	1.000	2	277	24736
2045	21.000	3	277	24738
2046	12.000	3	277	24737
2047	1.000	3	277	24736
2051	20.000	5	277	24738
2053	1.000	5	277	24736
2052	5.000	5	277	24737
2050	1.000	4	277	24736
219	2.000	2	331	24754
2049	9.000	4	277	24737
2048	20.000	4	277	24738
218	4.000	2	331	24751
412	6.800	3	341	24779
411	179.000	3	341	24776
410	2339.000	3	341	24775
409	4.360	3	341	24777
408	115.000	3	341	24774
402	2.060	1	341	24779
401	78.000	1	341	24776
400	3439.000	1	341	24775
396	6.930	1	341	24777
395	262.000	1	341	24774
363	76.000	3	350	4
362	80.000	3	350	3
361	123.000	3	350	2
360	76.000	2	350	4
359	80.000	2	350	3
358	123.000	2	350	2
357	81.000	1	350	4
356	80.000	1	350	3
355	117.000	1	350	2
2074	0.340	6	272	24780
217	3.000	2	331	24748
216	0.000	2	331	24753
215	12.000	2	331	24750
214	4.000	2	331	24747
213	0.000	2	331	24752
212	21.000	2	331	24749
211	15.000	2	331	24746
210	2.000	1	331	24754
209	4.000	1	331	24751
208	3.000	1	331	24748
207	0.000	1	331	24753
206	12.000	1	331	24750
205	4.000	1	331	24747
204	0.000	1	331	24752
203	13.000	1	331	24749
202	11.000	1	331	24746
201	2.000	5	331	24754
200	3.000	5	331	24751
199	2.000	5	331	24748
198	0.000	5	331	24753
197	5.000	5	331	24750
196	4.000	5	331	24747
195	0.000	5	331	24752
194	12.000	5	331	24749
193	8.000	5	331	24746
192	2.000	4	331	24754
191	3.000	4	331	24751
190	2.000	4	331	24748
189	0.000	4	331	24753
188	5.000	4	331	24750
187	1.000	4	331	24747
186	0.000	4	331	24752
185	12.000	4	331	24749
184	7.000	4	331	24746
2205	1.000	3	286	25195
2204	2.000	3	286	25196
2203	635.000	3	286	25200
2202	2.000	3	286	25187
2201	8.000	3	286	25188
2200	1.000	3	286	25189
2199	4.000	3	286	25191
2198	1909.000	3	286	25192
2197	2.000	3	286	25170
2196	5.000	3	286	25169
2195	4.000	3	286	25168
2194	1.000	3	286	25167
2193	6.000	3	286	25165
2192	2866.000	3	286	25164
2191	3.000	2	286	25195
2190	1.000	2	286	25197
2189	1.000	2	286	25198
2188	2.000	2	286	25199
2187	769.000	2	286	25200
2186	2.000	2	286	25186
2185	3.000	2	286	25187
2184	6.000	2	286	25188
2183	1.000	2	286	25190
2182	5.000	2	286	25191
2181	2667.000	2	286	25192
2180	5.000	2	286	25169
2179	12.000	2	286	25168
2178	2.000	2	286	25166
2177	11.000	2	286	25165
2176	4102.000	2	286	25164
2175	1.000	1	286	25194
2174	1.000	1	286	25195
2173	1.000	1	286	25198
2172	1.000	1	286	25199
2171	1287.000	1	286	25200
2170	1.000	1	286	25186
2169	10.000	1	286	25187
2168	7.000	1	286	25188
2167	1.000	1	286	25189
2166	1.000	1	286	25190
2165	8.000	1	286	25191
2164	3871.000	1	286	25192
2163	2.000	1	286	25170
2162	13.000	1	286	25169
2161	15.000	1	286	25165
2160	4788.000	1	286	25164
2159	2.000	5	286	25195
2158	1.000	5	286	25196
2157	6.000	5	286	25199
2156	1427.000	5	286	25200
2155	1.000	5	286	25186
2154	9.000	5	286	25187
2153	10.000	5	286	25188
2152	1.000	5	286	25190
2151	14.000	5	286	25191
2150	4179.000	5	286	25192
2149	2.000	5	286	25170
2148	8.000	5	286	25169
2147	5.000	5	286	25168
2146	2.000	5	286	25166
2145	17.000	5	286	25165
2144	5413.000	5	286	25164
2143	2.000	4	286	25199
2142	1159.000	4	286	25200
2141	1.000	4	286	25187
2140	3.000	4	286	25191
2139	4104.000	4	286	25192
2138	1.000	4	286	25170
2137	2.000	4	286	25169
2136	2.000	4	286	25168
2135	1.000	4	286	25166
2134	7.000	4	286	25165
2133	5363.000	4	286	25164
3240	94.000	3	314	25300
3239	96.000	3	314	25299
3238	96.000	3	314	25298
3237	100.000	3	314	25297
3236	97.000	3	314	25296
3235	96.000	3	314	25295
3234	93.000	3	314	25294
3233	94.000	3	314	25287
3232	98.000	3	314	25292
3231	87.000	3	314	25291
3230	89.000	3	314	25290
3229	88.000	3	314	25289
3228	92.000	3	314	25288
3227	88.000	3	314	25302
3226	92.000	3	314	25301
3225	90.000	3	314	25286
3224	88.000	3	314	25285
3223	85.000	3	314	25284
3222	90.000	3	314	25283
3221	92.000	3	314	25282
3220	89.000	3	314	25281
3219	93.000	2	314	25300
1528	218.000	3	284	25089
1527	23.000	3	284	25087
1526	48.000	3	284	25084
1525	16.000	3	284	25082
1524	140.000	3	284	25080
1523	82.000	3	284	25079
1522	26.000	3	284	25078
1521	50.000	3	284	25077
1520	42.000	3	284	25075
1519	37.000	3	284	25074
1518	40.000	3	284	25073
1517	17.000	3	284	25071
1516	33.000	3	284	25064
1515	59.000	3	284	25062
1514	251.000	3	284	25057
1513	36.000	3	284	25056
1512	170.000	3	284	25055
1511	48.000	3	284	25053
1510	278.000	2	284	25089
1509	141.000	2	284	25084
1508	43.000	2	284	25082
1507	198.000	2	284	25080
1506	106.000	2	284	25079
1505	65.000	2	284	25078
1504	127.000	2	284	25077
1503	35.000	2	284	25075
1502	112.000	2	284	25074
1501	58.000	2	284	25073
1500	79.000	2	284	25070
1499	44.000	2	284	25064
1498	69.000	2	284	25062
1497	40.000	2	284	25060
1496	111.000	2	284	25057
1495	81.000	2	284	25056
1494	239.000	2	284	25055
1493	95.000	2	284	25053
1492	235.000	1	284	25089
1491	38.000	1	284	25088
1490	1.000	1	284	25084
1489	137.000	1	284	25080
1488	56.000	1	284	25079
1487	78.000	1	284	25077
1486	32.000	1	284	25075
1485	59.000	1	284	25074
1484	83.000	1	284	25073
1483	17.000	1	284	25071
1482	101.000	1	284	25070
1481	33.000	1	284	25060
1480	154.000	1	284	25057
1479	177.000	1	284	25055
1478	49.000	1	284	25053
1477	376.000	5	284	25089
1476	59.000	5	284	25084
1475	29.000	5	284	25082
1474	50.000	5	284	25079
1473	41.000	5	284	25078
1472	94.000	5	284	25077
1471	47.000	5	284	25075
1470	27.000	5	284	25074
1469	55.000	5	284	25073
1468	18.000	5	284	25071
1467	363.000	5	284	25055
1466	225.000	5	284	25053
1465	34.000	4	284	25082
1464	301.000	4	284	25080
1463	55.000	4	284	25078
1462	152.000	4	284	25077
1461	103.000	4	284	25075
1460	19.000	4	284	25074
1459	123.000	4	284	25073
1458	353.000	4	284	25070
1457	25.000	4	284	25057
1456	31.000	4	284	25054
1455	90.000	4	284	25053
1380	101.000	3	284	24834
1379	64.000	3	284	235
1378	156.000	3	284	232
1377	74.000	3	284	220
1376	41.000	3	284	217
1375	58.000	3	284	214
1374	39.000	3	284	208
1373	59.000	3	284	166
1372	10.000	3	284	242
1371	146.000	3	284	239
1370	42.000	3	284	236
1369	296.000	3	284	233
1368	114.000	3	284	230
1367	1.000	3	284	227
1366	102.000	3	284	224
1365	212.000	3	284	221
1364	142.000	3	284	218
1363	99.000	3	284	215
1362	106.000	3	284	212
1361	39.000	3	284	209
1360	334.000	3	284	167
1359	8.000	3	284	243
1358	86.000	3	284	24836
1357	73.000	3	284	240
1356	79.000	3	284	237
1355	238.000	3	284	234
1354	96.000	3	284	231
1353	26.000	3	284	228
1352	131.000	3	284	225
1351	201.000	3	284	222
1350	162.000	3	284	219
1349	94.000	3	284	216
1348	175.000	3	284	213
1347	25.000	3	284	210
1346	211.000	3	284	168
1270	78.000	2	284	235
1269	223.000	2	284	232
1268	137.000	2	284	220
1267	66.000	2	284	217
1266	90.000	2	284	214
1265	31.000	2	284	208
1264	83.000	2	284	166
1263	192.000	2	284	239
1262	38.000	2	284	236
1261	399.000	2	284	233
1260	192.000	2	284	230
1259	142.000	2	284	224
1258	352.000	2	284	221
1257	222.000	2	284	218
1256	76.000	2	284	215
1255	208.000	2	284	212
1254	23.000	2	284	209
1253	482.000	2	284	167
1252	68.000	2	284	240
1251	153.000	2	284	237
1250	425.000	2	284	234
1249	180.000	2	284	231
1248	25.000	2	284	228
1247	180.000	2	284	225
1246	341.000	2	284	222
1245	218.000	2	284	219
1244	140.000	2	284	216
1243	259.000	2	284	213
1242	15.000	2	284	210
1241	303.000	2	284	168
1148	1.000	1	284	241
1147	150.000	1	284	235
1146	450.000	1	284	232
1145	176.000	1	284	220
1144	97.000	1	284	217
1143	128.000	1	284	214
1142	84.000	1	284	208
1141	105.000	1	284	166
1140	24.000	1	284	242
1139	283.000	1	284	239
1138	81.000	1	284	236
1137	757.000	1	284	233
1136	249.000	1	284	230
1135	220.000	1	284	224
1134	581.000	1	284	221
1133	309.000	1	284	218
1132	324.000	1	284	215
1131	248.000	1	284	212
1130	83.000	1	284	209
1129	599.000	1	284	167
1128	9.000	1	284	243
1127	112.000	1	284	240
1126	199.000	1	284	237
1125	753.000	1	284	234
1124	184.000	1	284	231
1123	81.000	1	284	228
1122	296.000	1	284	225
1121	478.000	1	284	222
1120	252.000	1	284	219
1119	240.000	1	284	216
1118	320.000	1	284	213
1117	74.000	1	284	210
1116	17.000	1	284	192
1115	458.000	1	284	168
1080	2.000	5	284	241
1079	136.000	5	284	235
1078	532.000	5	284	232
1077	23.000	5	284	226
1076	27.000	5	284	223
1075	185.000	5	284	220
1074	68.000	5	284	217
1073	134.000	5	284	214
1072	68.000	5	284	208
1071	112.000	5	284	166
1070	10.000	5	284	242
1069	303.000	5	284	239
1068	88.000	5	284	236
1067	937.000	5	284	233
1066	245.000	5	284	230
1065	239.000	5	284	224
1064	601.000	5	284	221
1063	324.000	5	284	218
1062	213.000	5	284	215
1061	181.000	5	284	212
1060	68.000	5	284	209
1059	637.000	5	284	167
1058	11.000	5	284	243
1057	142.000	5	284	240
1056	232.000	5	284	237
1055	1017.000	5	284	234
1054	188.000	5	284	231
1053	78.000	5	284	228
1052	341.000	5	284	225
1051	535.000	5	284	222
1050	295.000	5	284	219
1049	240.000	5	284	216
1048	351.000	5	284	213
1047	80.000	5	284	210
1046	28.000	5	284	195
1045	12.000	5	284	192
1044	451.000	5	284	168
1006	1.000	4	284	238
1005	139.000	4	284	235
1004	535.000	4	284	232
1003	20.000	4	284	226
1002	36.000	4	284	223
1001	152.000	4	284	220
1000	71.000	4	284	217
999	96.000	4	284	214
998	111.000	4	284	166
997	330.000	4	284	239
996	107.000	4	284	236
995	938.000	4	284	233
994	256.000	4	284	230
993	1.000	4	284	227
992	263.000	4	284	224
991	616.000	4	284	221
990	295.000	4	284	218
989	176.000	4	284	215
988	91.000	4	284	212
987	27.000	4	284	209
986	643.000	4	284	167
985	136.000	4	284	240
984	167.000	4	284	237
983	1023.000	4	284	234
982	183.000	4	284	231
981	61.000	4	284	228
980	294.000	4	284	225
979	462.000	4	284	222
978	258.000	4	284	219
977	217.000	4	284	216
976	304.000	4	284	213
975	75.000	4	284	210
974	72.000	4	284	207
973	502.000	4	284	168
938	46.000	3	284	24730
937	70.000	3	284	24732
936	170.000	3	284	24735
935	69.000	2	284	24730
934	102.000	2	284	24732
933	193.000	2	284	24735
932	102.000	1	284	24730
931	305.000	1	284	24735
930	156.000	5	284	24730
929	374.000	5	284	24735
928	344.000	4	284	24735
3218	93.000	2	314	25299
3217	94.000	2	314	25298
3216	90.000	2	314	25297
3215	91.000	2	314	25296
3214	93.000	2	314	25295
3213	92.000	2	314	25294
3212	92.000	2	314	25287
3211	93.000	2	314	25292
3210	92.000	2	314	25291
3209	88.000	2	314	25290
3208	89.000	2	314	25289
3207	88.000	2	314	25288
3206	89.000	2	314	25302
3205	93.000	2	314	25301
3204	88.000	2	314	25286
3203	88.000	2	314	25285
3202	88.000	2	314	25284
3201	86.000	2	314	25283
3200	91.000	2	314	25282
3199	91.000	2	314	25281
3198	97.000	1	314	25297
3197	89.000	1	314	25295
3196	96.000	1	314	25294
3195	91.000	1	314	25287
3194	86.000	1	314	25292
3193	83.000	1	314	25291
3192	82.000	1	314	25290
3191	83.000	1	314	25289
3190	90.000	1	314	25288
3189	87.000	1	314	25302
3188	86.000	1	314	25301
3187	90.000	1	314	25286
3186	88.000	1	314	25285
3185	83.000	1	314	25284
3184	87.000	1	314	25283
3183	91.000	1	314	25282
3182	95.000	1	314	25281
3181	89.000	5	314	25300
3180	77.000	5	314	25299
3179	83.000	5	314	25298
3178	81.000	5	314	25297
3177	83.000	5	314	25296
3176	82.000	5	314	25295
3175	86.000	5	314	25294
3174	93.000	5	314	25287
3173	70.000	5	314	25292
3172	82.000	5	314	25291
3171	82.000	5	314	25290
3170	81.000	5	314	25289
3169	84.000	5	314	25288
3168	81.000	5	314	25302
3167	88.000	5	314	25301
3166	83.000	5	314	25286
3165	85.000	5	314	25285
3164	83.000	5	314	25284
2565	90.000	1	311	25259
2564	96.000	1	311	25256
2563	80.000	1	311	25253
2562	92.000	1	311	25250
2561	85.000	1	311	25247
2560	89.000	1	311	25244
2559	86.000	1	311	25241
2558	93.000	1	311	25238
2557	94.000	1	311	25235
2556	89.000	1	311	25232
2555	85.000	1	311	25260
2554	96.000	1	311	25257
2553	88.000	1	311	25254
2552	92.000	1	311	25251
2551	91.000	1	311	25248
2550	92.000	1	311	25245
2549	89.000	1	311	25242
2548	93.000	1	311	25239
2547	89.000	1	311	25236
2546	82.000	1	311	25233
2545	91.000	1	311	25258
2544	95.000	1	311	25255
2543	74.000	1	311	25252
2542	96.000	1	311	25249
2541	94.000	1	311	25246
2540	96.000	1	311	25243
2539	90.000	1	311	25240
2538	97.000	1	311	25237
2537	97.000	1	311	25234
2536	90.000	1	311	25231
2535	88.000	5	311	25259
2534	78.000	5	311	25256
2533	79.000	5	311	25253
2532	74.000	5	311	25250
2531	91.000	5	311	25247
2530	87.000	5	311	25244
2529	91.000	5	311	25241
2528	91.000	5	311	25238
2527	88.000	5	311	25235
2526	86.000	5	311	25232
2525	89.000	5	311	25260
2524	82.000	5	311	25257
2523	78.000	5	311	25254
2522	87.000	5	311	25251
2521	88.000	5	311	25248
2520	89.000	5	311	25245
2519	91.000	5	311	25242
2518	89.000	5	311	25239
2517	80.000	5	311	25236
2516	76.000	5	311	25233
2515	93.000	5	311	25258
2514	83.000	5	311	25255
2513	86.000	5	311	25252
2512	82.000	5	311	25249
2511	95.000	5	311	25246
2510	94.000	5	311	25243
2509	95.000	5	311	25240
2508	95.000	5	311	25237
2507	93.000	5	311	25234
2506	89.000	5	311	25231
2505	93.000	4	311	25259
2504	83.000	4	311	25256
2503	81.000	4	311	25253
2502	79.000	4	311	25250
2501	93.000	4	311	25247
2500	90.000	4	311	25244
2499	89.000	4	311	25241
2498	93.000	4	311	25238
2497	90.000	4	311	25235
2496	89.000	4	311	25232
2495	85.000	4	311	25260
2494	74.000	4	311	25257
2493	72.000	4	311	25254
2492	81.000	4	311	25251
2491	85.000	4	311	25248
2490	82.000	4	311	25245
2489	86.000	4	311	25242
2488	83.000	4	311	25239
2487	70.000	4	311	25236
2486	71.000	4	311	25233
2485	94.000	4	311	25258
2484	89.000	4	311	25255
2483	85.000	4	311	25252
2482	79.000	4	311	25249
2481	95.000	4	311	25246
2480	95.000	4	311	25243
2479	93.000	4	311	25240
2478	94.000	4	311	25237
2477	90.000	4	311	25234
2476	86.000	4	311	25231
3163	84.000	5	314	25283
3162	86.000	5	314	25282
3161	81.000	5	314	25281
5002	33.300	3	349	25552
5001	66.700	3	349	25551
5000	20.000	3	349	25549
4999	20.000	3	349	25548
4998	40.000	3	349	25547
4997	20.000	3	349	25546
4996	16.000	3	349	25545
4995	8.000	3	349	25544
4994	56.000	3	349	25543
4993	20.000	3	349	25542
4992	9.100	2	349	25553
4991	40.900	2	349	25552
4990	18.200	2	349	25551
4989	31.800	2	349	25550
4988	7.800	2	349	25549
4987	45.600	2	349	25548
4986	22.200	2	349	25547
4985	24.400	2	349	25546
4984	14.200	2	349	25545
4983	30.600	2	349	25544
4982	39.600	2	349	25543
4981	15.700	2	349	25542
4980	66.700	1	349	25552
4979	33.300	1	349	25551
4978	7.100	1	349	25549
4977	57.100	1	349	25548
4976	28.600	1	349	25547
4975	7.100	1	349	25546
4974	4.700	1	349	25545
4973	44.200	1	349	25544
4972	25.600	1	349	25543
4971	25.600	1	349	25542
4970	37.500	5	349	25553
4969	37.500	5	349	25552
4968	25.000	5	349	25550
4967	14.300	5	349	25549
4966	50.000	5	349	25548
4965	14.300	5	349	25547
4964	21.400	5	349	25546
4963	6.600	5	349	25545
4962	52.200	5	349	25544
4961	30.400	5	349	25543
4960	10.800	5	349	25542
4959	83.300	4	349	25552
4958	16.700	4	349	25551
4957	65.200	4	349	25549
4956	26.100	4	349	25548
4955	8.700	4	349	25546
4954	1.700	4	349	25545
4953	38.300	4	349	25544
4952	40.000	4	349	25543
4951	20.000	4	349	25542
776	3.000	3	353	24824
775	2.000	3	353	24823
774	1.000	3	353	24818
773	19.000	3	353	24817
765	5.000	1	353	24828
764	5.000	1	353	24824
763	18.000	1	353	24823
762	5.000	1	353	24827
761	12.000	1	353	24821
760	1.000	1	353	24820
759	6.000	1	353	24826
758	13.000	1	353	24818
757	35.000	1	353	24817
756	3.000	5	353	24825
755	17.000	5	353	24824
754	24.000	5	353	24823
753	1.000	5	353	24822
752	20.000	5	353	24821
751	8.000	5	353	24820
750	14.000	5	353	24819
749	9.000	5	353	24818
748	53.000	5	353	24817
772	4.000	2	353	24824
771	2.000	2	353	24823
770	7.000	2	353	24821
769	5.000	2	353	24820
768	1.000	2	353	24829
767	11.000	2	353	24818
766	33.000	2	353	24817
4814	14.000	2	327	25529
4813	20.000	2	327	25526
4812	46.000	2	327	25523
4811	13.000	2	327	25520
4810	28.000	2	327	25517
4809	49.000	2	327	25514
4808	11.000	2	327	25511
4807	13.000	2	327	25508
4806	18.000	2	327	25505
4805	4.000	2	327	25499
4804	8.000	2	327	25496
4803	4.000	2	327	25495
4802	1.000	2	327	25493
4801	2.000	2	327	25487
4800	2.000	2	327	25486
4799	2.000	2	327	25481
4798	1.000	2	327	25480
4797	5.000	2	327	25478
4796	30.000	2	327	25477
4795	4.000	2	327	25476
4794	2.000	2	327	25471
4793	3.000	2	327	25469
4792	7.000	2	327	25468
4791	3.000	2	327	25467
4790	12.000	2	327	25466
4789	12.000	2	327	25465
4788	1.000	2	327	25464
4787	14.000	2	327	25463
4786	20.000	2	327	25462
4785	22.000	2	327	25460
4784	48.000	2	327	25459
4783	5.000	2	327	25458
4782	2.000	2	327	25451
4781	3.000	2	327	25450
4780	4.000	2	327	25449
4779	20.000	1	327	25529
4778	34.000	1	327	25526
4777	55.000	1	327	25523
4776	24.000	1	327	25520
4775	51.000	1	327	25517
4774	69.000	1	327	25514
4773	20.000	1	327	25511
4772	20.000	1	327	25508
4771	21.000	1	327	25505
4770	1.000	1	327	25502
4769	1.000	1	327	25499
4768	15.000	1	327	25496
4767	1.000	1	327	25495
4766	1.000	1	327	25493
4765	6.000	1	327	25487
4764	2.000	1	327	25486
4763	3.000	1	327	25483
4762	1.000	1	327	25481
4761	3.000	1	327	25480
4760	8.000	1	327	25478
4759	20.000	1	327	25477
4758	4.000	1	327	25476
4757	1.000	1	327	25475
4756	1.000	1	327	25472
4755	13.000	1	327	25469
4754	4.000	1	327	25468
4753	1.000	1	327	25467
4752	14.000	1	327	25466
4751	11.000	1	327	25465
4750	1.000	1	327	25464
4749	21.000	1	327	25463
4748	11.000	1	327	25462
4747	1.000	1	327	25461
4746	26.000	1	327	25460
4745	49.000	1	327	25459
4744	7.000	1	327	25458
4743	2.000	1	327	25451
4742	3.000	1	327	25450
4741	4.000	1	327	25449
4740	19.000	5	327	25529
4739	29.000	5	327	25526
4738	43.000	5	327	25523
4737	26.000	5	327	25520
4736	48.000	5	327	25517
4735	88.000	5	327	25514
4734	11.000	5	327	25511
4733	12.000	5	327	25508
4732	15.000	5	327	25505
4731	1.000	5	327	25501
4730	5.000	5	327	25499
4729	13.000	5	327	25496
4728	2.000	5	327	25495
4727	1.000	5	327	25493
4726	5.000	5	327	25487
4725	2.000	5	327	25486
4724	3.000	5	327	25484
4723	1.000	5	327	25481
4722	2.000	5	327	25480
4721	10.000	5	327	25478
4720	21.000	5	327	25477
4719	3.000	5	327	25476
4718	8.000	5	327	25469
4717	13.000	5	327	25466
4716	12.000	5	327	25465
4715	1.000	5	327	25464
4714	25.000	5	327	25463
4713	14.000	5	327	25462
4712	26.000	5	327	25460
4711	43.000	5	327	25459
4710	8.000	5	327	25458
4709	2.000	5	327	25451
4708	2.000	5	327	25450
4707	4.000	5	327	25449
4706	17.000	4	327	25529
4705	26.000	4	327	25526
4704	64.000	4	327	25523
4703	21.000	4	327	25520
4702	48.000	4	327	25517
4701	57.000	4	327	25514
4700	9.000	4	327	25511
4699	14.000	4	327	25508
4698	1.000	4	327	25507
4697	18.000	4	327	25505
4696	1.000	4	327	25504
4695	2.000	4	327	25502
4694	2.000	4	327	25499
4693	19.000	4	327	25496
4692	2.000	4	327	25495
4691	1.000	4	327	25493
4690	4.000	4	327	25487
4689	2.000	4	327	25486
4688	3.000	4	327	25484
4687	1.000	4	327	25481
4686	2.000	4	327	25480
4685	12.000	4	327	25478
4684	28.000	4	327	25477
4683	2.000	4	327	25476
4682	4.000	4	327	25474
4681	1.000	4	327	25473
4680	2.000	4	327	25471
4679	4.000	4	327	25468
4678	2.000	4	327	25467
4677	9.000	4	327	25466
4676	8.000	4	327	25465
4675	12.000	4	327	25463
4674	17.000	4	327	25462
4673	18.000	4	327	25460
4672	31.000	4	327	25459
4671	4.000	4	327	25458
4670	4.000	4	327	25450
4669	4.000	4	327	25449
\.


--
-- Data for Name: core_fuenteinformacion; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_fuenteinformacion (id, fuente_informacion, web, registrado, indicador_id, termino_id) FROM stdin;
\.


--
-- Data for Name: core_indicador; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_indicador (id, nombre, codigo, descripcion, definicion, eliminable, visible, cobertura_geografica, periodicidad, lectura, observaciones, componente_id) FROM stdin;
346	Posición de la institución respecto a la competencia	RS.07		<p>Hace referencia al mayor nivel logrado de "Me gusta" en los diferentes medios sociales de las universidades en un periodo de tiempo determinado.</p>	t	f	Na	A	<p>Pendiente la informaci&oacute;n</p>		69
324	Titulación del personal docente	RH.03	\N	<p>Nivel educativo m&aacute;s alto alcanzado por el personal docente</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
298	Egresados en el tiempo mínimo según pensum 	PA.11	\N	Es la proporción de estudiantes egresados que estarían según el tiempo mínimo que establece el pensum de su carrera UAPA	t	t	Na	A	Pendiente la información	\N	63
270	Tasa de inflación	CES.01	<p>Tasa de inflaci&oacute;n anualizada de la econom&iacute;a dominicana. Se refiere a la variaci&oacute;n de los precios por a&ntilde;o..........</p>	<p>Tasa de inflaci&oacute;n anualizada de la econom&iacute;a dominicana. Se refiere a la variaci&oacute;n de los precios por a&ntilde;o.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	60
271	Estimaciones y proyecciones de la población total por año calendario	CES.02	\N	<p>Son las estimaciones de la poblaci&oacute;n en el tiempo en relaci&oacute;n a la estructura de los fen&oacute;menos demogr&aacute;ficos como la mortalidad, fecundidad y migraciones.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	60
272	Gasto público en educación como porcentaje del PIB por nivel educativo	CES.03	\N	<p>Es la relaci&oacute;n porcentual que existe entre el gasto p&uacute;blico en educaci&oacute;n y el Producto Interno Bruto (PIB) en un a&ntilde;o fiscal.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	60
273	Coeficiente de desigualdad educativa	CES.04	\N	<p>Es la forma de medici&oacute;n de la distribuci&oacute;n de la educaci&oacute;n, aproximada por los a&ntilde;os de escolaridad, dando cuenta de la disparidad o desigualdad en la distribuci&oacute;n de la misma en una poblaci&oacute;n determinada.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	60
274	Tasa de analfabetismo de la población de 15 años y más	CES.05	\N	<p>Es la proporci&oacute;n la poblaci&oacute;n que no sabe leer ni escribir de 15 a&ntilde;os y m&aacute;s en relaci&oacute;n del tota de la poblaci&oacute;n en ese mismo rango de edad.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	60
275	Tasa bruta de matrícula nivel superior	CES.06	\N	Es la relación entre la matrícula total del nivel superior sin tomar en cuenta la edad de los alumnos y la población en edad oficial de escolarización correspondiente al mismo nivel de enseñanza en un mismo año académico	t	t	Na	A	Pendiente la información	\N	60
276	Índice de paridad de género en tasa bruta de matricula según nivel educativo	CES.07	\N	El Índice de Paridad de Género es la relación entre la tasa bruta de matricula de la población femenina y la masculina.	t	t	Na	A	Pendiente la información	\N	60
277	Distribución de la oferta académica por recinto	OA.01	\N	<p>Este indicador mide la cantidad de carreras ofertadas por la UAPA en cada uno de sus recintos y programa acad&eacute;mico.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	61
278	Distribución Oferta Académica a nivel de Grado por recinto	OA.02	\N	<p>Este indicador mide la cantidad de carreras ofertadas por la UAPA en cada uno de las escuelas seg&uacute;n el programa acad&eacute;mico y recintos.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	61
279	Distribución Oferta Académica a nivel de Post-Grado por recinto	OA.03	\N	<p>Proporci&oacute;n de plazas cubiertas en carrera determinada con relaci&oacute;n a la capacidad de oferta o plazas disponibles en la misma carrera.</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	61
280	Distribución de la oferta académica por área de conocimiento (Escuela)	OA.04	\N	Este indicador mide el porcentaje de participación de las carreras ofertadas a nivel de grado por la UAPA entre el total de la oferta  de grado.	t	t	Na	A	Pendiente la información	\N	61
281	Solicitudes de Admisión	DU.01	\N	<p>Cantidad de solicitudes de admisi&oacute;n recibidas</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	62
282	Solicitudes de admisión aprobadas	DU.02	\N	<p>Cantidad de solicitudes de admisi&oacute;n aceptadas</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	62
283	Participantes de nuevo ingreso por recinto	DU.03	\N	<p>Cantidad de alumnos de nuevo ingreso por recinto educativo</p>	t	t	Na	TR	<p>Pendiente la informaci&oacute;n</p>	\N	62
284	Participantes de nuevo ingreso por carrera	DU.04	\N	<p>Cantidad de alumnos de nuevo ingreso seg&uacute;n la carrera inscrita</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	62
285	Participantes de nuevo ingreso transferidos	DU.05	\N	<p>Cantidad de alumnos de nuevo ingreso que estudiaban en otra universidad</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	62
286	Participantes matriculados de nuevo ingreso según nacionalidad	DU.06	\N	<p>Cantidad de alumnos de nuevo ingreso seg&uacute;n nacionalidad</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	62
287	Posición de las instituciones de educación superior según el mayor nivel de registro de matrículas de nuevo ingreso	DU.07	\N	Hace referencia a las universidades que obtuvieron un mayor numero de estudiantes de nuevo ingreso en un año determinado.	t	t	Na	A	Pendiente la información	\N	62
288	Participantes Matriculados	PA.01	\N	<p>Numero de alumnos matriculados</p>	t	t	Na	CT	<p>Pendiente la informaci&oacute;n</p>	\N	63
289	Participantes Egresados	PA.02	\N	Muestra la cantidad o frecuencia de graduados por mes de los programas de grado, postgrado y técnico superior.	t	t	Na	CU	Pendiente la información	\N	63
290	Participantes retirados	PA.03	\N	Se refiere a la cantidad de estudiantes matriculados en algún momento que se retiraron de la universidad.	t	t	Na	CU	Pendiente la información	\N	63
291	Cambios a prueba académica	PA.04	\N	Se refiere a aquellos estudiantes que no alcanzan un nivel mínimo requerido. Su índice cuatrimestral sea menor de 2.00, excepto el primer cuatrimestre y\nb) Su índice acumulado sea menor de 2.00, excepto el primer cuatrimestre.\n	t	t	Na	P	Pendiente la información	\N	63
292	Cambios de carrera	PA.05	\N	Pendiente de Información	t	t	Na	P	Pendiente la información	\N	63
293	Participantes por facilitador	PA.06	\N	Relación entre la cantidad de alumnos por profesor	t	t	Na	P	Pendiente la información	\N	63
294	Participantes Egresados reinscritos	PA.07	\N	La cantidad de egresados reinscritos en otra titulación o post grado	t	t	Na	P	Pendiente la información	\N	63
295	Participantes activos	PA.08	\N	\N	t	t	Na	A	Pendiente la información	\N	63
296	Estudiantes egresados trasferidos de otra universidad	PA.09	\N	Es la proporción de estudiantes egresados que en algún momento se transfirieron de otra universidad hacia la UAPA	t	t	Na	A	Pendiente la información	\N	63
297	Egresados interesados en realizar alguna especialidad o post grado en la UAPA	PA.10	\N	Es la proporción de estudiantes egresados que estarían dispuestos a realizar algún postgrado en la UAPA	t	t	Na	A	Pendiente la información	\N	63
299	Tasa de abandono	RA.01	\N	Porcentaje de participantes que abandonan antes de finalizar el proceso de grado. Es la diferencia entre 100% y las tasas de promoción y repetición. 	t	t	Na	BM	Pendiente la información	\N	64
300	Tasa de rendimiento	RA.02	\N	Es el porcentaje de egresados que realizaron en grado en el tiempo requerido, según la cantidad de alumnos inscritos que cumplen con el tiempo requerido	t	t	Na	BM	Pendiente la información	\N	64
301	Tasa de éxito	RA.03	\N	Es la relación porcentual entre el numero de créditos superados por el total de alumnos y el numero de créditos presentados a evaluación por dicha cantidad de alumnos	t	t	Na	BM	Pendiente la información	\N	64
302	Tasa de Graduación	RA.04	\N	Es el numero total de graduados en el año t, expresado como porcentaje de la población con el tiempo teórico cumplido de graduación. 	t	t	Na	BM	Pendiente la información	\N	64
303	Tasa de eficiencia terminal	RA.05	\N	Es el numero de alumnos que egresan en el tiempo mínimo especificado en el grado por cada cien alumnos egresados	t	t	Na	A	Pendiente la información	\N	64
304	Duración media de estudios	RA.06	\N	Es el resultado de la sumatoria de los años de duración de los graduados entre la cantidad total de graduados 	t	t	Na	BM	Pendiente la información	\N	64
305	Nota media de los participantes graduados	RA.07	\N	Es el resultado de la sumatoria de los notas de  los graduados entre la cantidad total de graduados 	t	t	Na	BM	Pendiente la información	\N	64
306	Satisfacción con el desempeño docente	SU.01	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n con el nivel de desempe&ntilde;o competente de los facilitadores de las escuelas de Psicolog&iacute;a, Negocios y Ciencias Jur&iacute;dicas y Pol&iacute;ticas de la sede y los recintos, se incluyeron otros facilitadores a quienes se les solicit&oacute; el seguimiento mediante la evaluaci&oacute;n.</p>	t	t	Na	BT	<p>Pendiente la informaci&oacute;n</p>	\N	65
307	Cumplimiento de las obligaciones docentes	SU.02	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n con el cumplimiento de las obligaciones que deben ejercer los facilitadores como: Llega puntual al inicio de las facilitaciones presenciales, cumple con los tiempos establecidos para las facilitaciones virtuales o semipresenciales, realiza su participaci&oacute;n en los cursos virtuales atendiendo las fechas establecidas en la calendarizaci&oacute;n, desarrolla sus facilitaciones en base a los programas de las asignaturas dando fiel cumplimiento a estas.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
308	Satisfacción de los participantes con el plan de estudios	SU.03	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los participantes con el plan de estudios.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
309	Satisfacción de los egresados con el plan de estudios	SU.04	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los egresados con el plan de estudios.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
310	Satisfacción de los facilitadores con el plan de estudios	SU.05	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los facilitadores con el plan de estudios.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
311	Satisfacción del personal administrativo y de servicios con la gestión de los programas académicos	SU.06	\N	<p>Pendiente de Informaci&oacute;n</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	65
312	Satisfacción de los participantes extranjeros con los servicios académicos	SU.07	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los participantes con los servicios acad&eacute;micos.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
313	Satisfacción de los participantes extranjeros con los servicios no académicos	SU.08	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los participantes con los servicios no acad&eacute;micos.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
314	Tendencia de la satisfacción de los participantes en el extranjero	SU.09	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n general de los participantes en el extranjero.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
315	Satisfacción de los participantes en el extranjero por dimensiones	SU.10	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem o dimensiones de los participantes en el extranjero.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
316	Percepción de satisfacción de los empleados con el clima laboral	SU.11	\N	<p>Calificaci&oacute;n porcentual asignada al &iacute;tem satisfacci&oacute;n de los empleados con el clima laboral.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
317	Percepción de satisfacción de los empleados con el clima laboral por dimensiones	SU.12	\N	<p>Calificaci&oacute;n porcentual asignada al &iacute;tem satisfacci&oacute;n de los empleados con el clima laboral por dimensiones.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
318	Porcentaje de satisfacción de los participantes	SU.13	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los participantes de manera general, por escuela y por servicios de los diferentes departamentos</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
319	Comparación del porcentaje de satisfacción por recinto	SU.14	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los participantes de manera general, por escuela y por servicios de los diferentes departamentos</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
320	Comparación del porcentaje de satisfacción de los empleados	SU.15	\N	<p>Puntuaci&oacute;n media obtenida en encuestas contestadas seg&uacute;n &iacute;tem satisfacci&oacute;n de los empleados de manera general por departamentos.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	65
321	Personal docente por horas	RH.01	\N	<p>Este indicador mide la cantidad de docentes que prestan sus servicios a la universidad por horas.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
322	Personal docente a tiempo completo	RH.02	\N	<p>Este indicador mide la cantidad de docentes que prestan sus servicios a la universidad a tiempo completo.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
323	Personal docente de medio tiempo	RH.02.1	\N	<p>Este indicador mide la cantidad de docentes que prestan sus servicios a la universidad solo a medio tiempo.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
325	Personal docente funcionario	RH.04	\N	<p>Se refiere al personal docente que adem&aacute;s de sus labores como docentes ocupan una posici&oacute;n de mayor nivel jer&aacute;rquico dentro de la universidad</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
326	Personal administrativo y de servicios a tiempo completo	RH.05	\N	<p>Este indicador mide la cantidad de personal administrativo y de servicios que prestan sus servicios a la universidad a tiempo completo.</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	66
327	Personal administrativo y de servicios a medio tiempo	RH.06	\N	<p>Este indicador mide la cantidad de personal administrativo y de servicios que prestan sus servicios a la universidad solo a medio tiempo.</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	66
328	Relación PAS/Docente	RH.07	\N	<p>El indicador mide la cantidad de personal docente que presta sus servicios en la universidad en relaci&oacute;n al numero de personal administrativo y de servicios universitario.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
329	Distribución porcentual de empleados administrativos por recinto y sexo, según nivel académico más alto	RH.08	\N	<p>Este indicador mide el nivel educativo del talento humano de la instituci&oacute;n, para cada uno de sus recintos.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
330	Cantidad de empleados administrativos por nivel académico más alto, según recinto y categoría ocupacional, 2017	RH.09	\N	<p>Este indicador mide el nivel educativo m&aacute;s alto alcanzado por los empleados administrativos de la UAPA, seg&uacute;n la actividad ocupacional.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	66
331	Personal Investigador	IP.01	\N	Pendiente de Información	t	t	Na	A	Pendiente la información	\N	67
332	Investigaciones realizadas	IP.02	\N	<p>Total de investigaciones realizadas por la universidad UAPA</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	67
333	Investigaciones en proceso	IP.03	\N	<p>Total de investigaciones que est&aacute;n en proceso en la universidad UAPA</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	67
334	Publicaciones realizadas	IP.04	\N	<p>Total de publicaciones autor&iacute;a de la universidad UAPA</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	67
335	Publicaciones en proceso	IP.05	\N	<p>Total de publicaciones autor&iacute;a de la universidad UAPA que est&aacute;n en proceso</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	67
336	Programas de extensión	ERS.01	\N	Son aquellos programas que surgen por la necesidad de vincular la universidad con la comunidad, a través de una seria de actividades que van en favor de las necesidades requeridas.	t	t	Na	A	Pendiente la información	\N	68
337	Actividades de extensión	ERS.02	\N	<p>Son aquellos actividades que vinculan la universidad con la comunidad y que re realizan a trav&eacute;s de un programa de extensi&oacute;n.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	68
338	Proyectos de responsabilidad social universitaria	ERS.03	\N	<p>Son aquellos proyectos de asistencia social que se realizan desde la universidad en el cual los participantes son voluntarios</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	68
339	Actividades de responsabilidad social	ERS.04	\N	<p>Se refiere al porcentaje de personas inscritas que desean participar en el voluntariado, seg&uacute;n los diferentes tipos de proyectos de responsabilidad social realizados por la universidad</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	68
340	Redes sociales en que incursiona la UAPA	RS.01	\N	Son todas aquellas redes sociales en las cuales la UAPA dispone de una cuenta activa para la difusión e intercambio de Información	t	t	Na	BM	Pendiente la información	\N	69
341	Tipo de información que se difunde en las redes	RS.02	\N	Son todos los tipos de información que postea la universidad en los diferentes medios sociales como medio de difusión de Información de carácter relevante.	t	t	Na	M	Pendiente la información	\N	69
342	Comentarios de los usuarios de las redes sobre institución	RS.03	\N	Se refiere a la categoría asignada al tipo de comentario: Favorable o  desfavorable publicados en las redes sociales  de la UAPA.	t	t	Na	M	Pendiente la información	\N	69
343	Periodicidad en el uso de las redes	RS.04	\N	Es la frecuencia de entradas de los usuarios de la red social Facebook de la universidad medida por el numero de veces que ingresan.	t	t	Na	A	Pendiente la información	\N	69
344	Cantidad de seguidores en las redes sociales	RS.05	\N	Total de seguidores en los diferentes medios sociales que incursiona la universidad	t	t	Na	BM	Pendiente la información	\N	69
345	Influencia en las redes	RS.06	\N	Se mide a través del nivel de satisfacción de los usuario en el uso de la red social Facebook.	t	t	Na	A	Pendiente la información	\N	69
347	Tasa de inserción laboral	IL.01	\N	Es la proporción de …(Alumnos, egresados, etc) que tienen trabajo (en el área?)	t	t	Na	BM	Pendiente la información	\N	70
348	Tasa de egresados que han trabajado alguna vez	IL.02	\N	<p>Proporci&oacute;n de egresados que han tenido alg&uacute;n trabajo dentro del total</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	70
349	Satisfacción de los empleadores con egresados UAPA	IL.03	\N	<p>Pendiente de Informaci&oacute;n</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	70
350	Edificaciones	PU.01	\N	<p>Este indicador mide la cantidad de recintos que dispone la universidad.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	71
351	Inventario de equipos y materiales	PU.02	\N	<p>Este indicador mide la cantidad de equipos (mobiliario, hardware, etc) que dispone la universidad.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	71
352	Infraestructura tecnológica	PU.03	\N	<p>Este indicador estima el total de la infraestructura tecnol&oacute;gica de la universidad (red inal&aacute;mbrica, red al&aacute;mbrica, software, etc) que dispone la universidad.</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	71
353	Distribución de oferta técnica según área de conocimiento	EC.01	\N	<p>Porcentaje de estudiantes seg&uacute;n &aacute;rea de estudio</p>	t	t	Na	BM	<p>Pendiente la informaci&oacute;n</p>	\N	72
354	Distribución de la oferta técnica por tipo, según rama de educación continua	EC.02	\N	<p>Es la sumatoria total del tipo de oferta t&eacute;cnica seg&uacute;n la rama entre el total de oferta t&eacute;cnica de todas las ramas de ense&ntilde;anza</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	72
355	Cantidad de estudiantes egresado en habilitación docente y otros tipo de oferta técnica	EC.03	\N	<p>Es la sumatoria total del total de estudiantes egresados del programa habilitaci&oacute;n docente impartido por la universidad en la sede y con apertura en algunas provincias.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	72
356	Costo promedio de educación continua	EC.04	\N	<p>Es la sumatoria total de costos de los tipos de educaci&oacute;n continua ofertados por la universidad seg&uacute;n el costo total.</p>	t	t	Na	A	<p>Pendiente la informaci&oacute;n</p>	\N	72
\.


--
-- Data for Name: core_informe; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_informe (id, fecha, archivo, visible, url) FROM stdin;
1	2019-05-25	uploads/banner.jpg	t	https://drive.google.com/file/d/14ZQ0z22BVh-O0tvNn3K_L-4vxrYcGYIP/view?usp=sharing
\.


--
-- Data for Name: core_objetivos; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_objetivos (id, objetivo, ovu_id) FROM stdin;
\.


--
-- Data for Name: core_ovu; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_ovu (id, nombre, definicion) FROM stdin;
\.


--
-- Data for Name: core_referencia; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_referencia (id, institucion) FROM stdin;
\.


--
-- Data for Name: core_referencia_indicador; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_referencia_indicador (id, referencia_id, indicador_id) FROM stdin;
\.


--
-- Data for Name: core_segregacion; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_segregacion (id, parametro, parametro_opcional) FROM stdin;
187	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Ciencias de la Naturaleza 
188	Santo Domingo Oriental	Ciencia de la Educación, Mención Ciencias de la Naturaleza 
189	Santiago (sede)	Ciencia de la Educación, Mención Ciencias de la Naturaleza 
190	Cibao Oriental (Nagua)	Lengua Española y Literatura Orientada a la Educacion Secundaria
191	Santo Domingo Oriental	Lengua Española y Literatura Orientada a la Educacion Secundaria
192	Santiago (sede)	Lengua Española y Literatura Orientada a la Educacion Secundaria
193	Cibao Oriental (Nagua)	Matematica  Orientada a la Educacion Secundaria
194	Santo Domingo Oriental	Matematica  Orientada a la Educacion Secundaria
195	Santiago (sede)	Matematica  Orientada a la Educacion Secundaria
423	Santiago (sede)	Gerencia de Recursos Humanos 
422	Santo Domingo Oriental	Gerencia de Recursos Humanos 
421	Cibao Oriental (Nagua)	Gerencia de Recursos Humanos 
196	Cibao Oriental (Nagua)	Ciencias Sociales Orienada a la Educacion Secundaria
197	Santo Domingo Oriental	Ciencias Sociales Orienada a la Educacion Secundaria
198	Santiago (sede)	Ciencias Sociales Orienada a la Educacion Secundaria
417	Santiago (sede)	Psicología Clínica 
416	Santo Domingo Oriental	Psicología Clínica 
415	Cibao Oriental (Nagua)	Psicología Clínica 
414	Santiago (sede)	Educación Inicial 
413	Santo Domingo Oriental	Educación Inicial 
412	Cibao Oriental (Nagua)	Educación Inicial 
199	Cibao Oriental (Nagua)	Ingles Orientado a la Educacion
200	Santo Domingo Oriental	Ingles Orientado a la Educacion
201	Santiago (sede)	Ingles Orientado a la Educacion
202	Cibao Oriental (Nagua)	Educacion Primaria, Primer Ciclo
203	Santo Domingo Oriental	Educacion Primaria, Primer Ciclo
204	Santiago (sede)	Educacion Primaria, Primer Ciclo
205	Cibao Oriental (Nagua)	Educación Inicial
206	Santo Domingo Oriental	Educación Inicial
207	Santiago (sede)	Educación Inicial
208	Cibao Oriental (Nagua)	Informática Gerencial 
209	Santo Domingo Oriental	Informática Gerencial 
210	Santiago (sede)	Informática Gerencial 
211	Cibao Oriental (Nagua)	Ingeniería en Software 
212	Santo Domingo Oriental	Ingeniería en Software 
213	Santiago (sede)	Ingeniería en Software 
214	Cibao Oriental (Nagua)	Lenguas Modernas Mención Turismo 
215	Santo Domingo Oriental	Lenguas Modernas Mención Turismo 
216	Santiago (sede)	Lenguas Modernas Mención Turismo 
217	Cibao Oriental (Nagua)	Administración de Empresas 
218	Santo Domingo Oriental	Administración de Empresas 
219	Santiago (sede)	Administración de Empresas 
220	Cibao Oriental (Nagua)	Contabilidad Empresarial 
221	Santo Domingo Oriental	Contabilidad Empresarial 
222	Santiago (sede)	Contabilidad Empresarial 
223	Cibao Oriental (Nagua)	Mercadeo 
224	Santo Domingo Oriental	Mercadeo 
225	Santiago (sede)	Mercadeo 
226	Cibao Oriental (Nagua)	Administración de Empresas Turísticas 
227	Santo Domingo Oriental	Administración de Empresas Turísticas 
228	Santiago (sede)	Administración de Empresas Turísticas 
229	Cibao Oriental (Nagua)	Psicología Clínica 
230	Santo Domingo Oriental	Psicología Clínica 
231	Santiago (sede)	Psicología Clínica 
25529	Nagua	Servicios Generales/Grado-Pregrado
233	Santo Domingo Oriental	Psicología Educativa 
234	Santiago (sede)	Psicología Educativa 
235	Cibao Oriental (Nagua)	Psicología 
236	Santo Domingo Oriental	Psicología 
237	Santiago (sede)	Psicología 
238	Cibao Oriental (Nagua)	Psicología Industrial 
239	Santo Domingo Oriental	Psicología Industrial 
240	Santiago (sede)	Psicología Industrial 
241	Cibao Oriental (Nagua)	Periodismo digital
242	Santo Domingo Oriental	Periodismo digital
243	Santiago (sede)	Periodismo digital
352	Cibao Oriental (Nagua)	Gerencia de Recursos Humanos 
353	Santo Domingo Oriental	Gerencia de Recursos Humanos 
359	Santo Domingo Oriental	Gestión de Centros Educativos 
360	Santiago (sede)	Gestión de Centros Educativos 
361	Cibao Oriental (Nagua)	Historia, con Orientación a la Enseñanza 
362	Santo Domingo Oriental	Historia, con Orientación a la Enseñanza 
363	Santiago (sede)	Historia, con Orientación a la Enseñanza 
364	Cibao Oriental (Nagua)	Informática, con Orientación a la Enseñanza 
365	Santo Domingo Oriental	Informática, con Orientación a la Enseñanza 
366	Santiago (sede)	Informática, con Orientación a la Enseñanza 
367	Cibao Oriental (Nagua)	Biología, con Orientación a la Enseñanza 
368	Santo Domingo Oriental	Biología, con Orientación a la Enseñanza 
369	Santiago (sede)	Biología, con Orientación a la Enseñanza 
370	Cibao Oriental (Nagua)	Educación, Mención Lengua Española, Segundo Ciclo 
371	Santo Domingo Oriental	Educación, Mención Lengua Española, Segundo Ciclo 
372	Santiago (sede)	Educación, Mención Lengua Española, Segundo Ciclo 
373	Cibao Oriental (Nagua)	Lengua Española y Literatura, con Orientación a la Enseñanza 
374	Santo Domingo Oriental	Lengua Española y Literatura, con Orientación a la Enseñanza 
375	Santiago (sede)	Lengua Española y Literatura, con Orientación a la Enseñanza 
376	Cibao Oriental (Nagua)	Educación, Matemática Física, Segundo Ciclo 
377	Santo Domingo Oriental	Educación, Matemática Física, Segundo Ciclo 
378	Santiago (sede)	Educación, Matemática Física, Segundo Ciclo 
379	Cibao Oriental (Nagua)	Matemática, con Orientación a la Enseñanza 
357	Santiago (sede)	Mercadeo 
356	Santo Domingo Oriental	Mercadeo 
355	Cibao Oriental (Nagua)	Mercadeo 
354	Santiago (sede)	Gerencia de Recursos Humanos 
358	Cibao Oriental (Nagua)	Gestión de Centros Educativos 
380	Santo Domingo Oriental	Matemática, con Orientación a la Enseñanza 
381	Santiago (sede)	Matemática, con Orientación a la Enseñanza 
382	Cibao Oriental (Nagua)	Educación, Mención Historia y Geografía Segundo Ciclo 
383	Santo Domingo Oriental	Educación, Mención Historia y Geografía Segundo Ciclo 
384	Santiago (sede)	Educación, Mención Historia y Geografía Segundo Ciclo 
385	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario
386	Santo Domingo Oriental	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario
387	Santiago (sede)	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario
388	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
389	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
390	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
391	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
392	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
393	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
394	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
395	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
396	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
397	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
398	Santo Domingo Oriental	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
399	Santiago (sede)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
400	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.
401	Santo Domingo Oriental	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.
402	Santiago (sede)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.
403	Cibao Oriental (Nagua)	Ciencias de la Educacion, Mencion Gestion de Centros Educativos
404	Santo Domingo Oriental	Ciencias de la Educacion, Mencion Gestion de Centros Educativos
405	Santiago (sede)	Ciencias de la Educacion, Mencion Gestion de Centros Educativos
406	Cibao Oriental (Nagua)	Mercadeo, mencion Gerencia de mercadeo
407	Santo Domingo Oriental	Mercadeo, mencion Gerencia de mercadeo
408	Santiago (sede)	Mercadeo, mencion Gerencia de mercadeo
409	Cibao Oriental (Nagua)	Mercadeo, Mención  Mercadeo Politico
410	Santo Domingo Oriental	Mercadeo, Mención  Mercadeo Politico
411	Santiago (sede)	Mercadeo, Mención  Mercadeo Politico
418	Cibao Oriental (Nagua)	Derecho Civil y Procesal Civil Contemporáneos
419	Santo Domingo Oriental	Derecho Civil y Procesal Civil Contemporáneos
25053	Santiago (sede)	Gerencia de Recursos Humanos  - MGH
25054	Santiago (sede)	Mercadeo (Postgrado)
25055	Santiago (sede)	Gestión de Centros Educativos  - MGC
25056	Santiago (sede)	Historia, con Orientación a la Enseñanza - MAH
25057	Santiago (sede)	Informática, con Orientación a la Enseñanza  - EIN
25058	Santiago (sede)	Biología, con Orientación a la Enseñanza 
25059	Santiago (sede)	Educación, Mención Lengua Española, Segundo Ciclo 
25060	Santiago (sede)	Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL
25061	Santiago (sede)	Educación, Matemática Física, Segundo Ciclo 
25062	Santiago (sede)	Matemática, con Orientación a la Enseñanza - EMA
25063	Santiago (sede)	Educación, Mención Historia y Geografía Segundo Ciclo 
25064	Santiago (sede)	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM
25065	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
25066	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
25067	Santiago (sede)	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
25068	Santiago (sede)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
25069	Santiago (sede)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario
25070	Santiago (sede)	Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC
25071	Santiago (sede)	Mercadeo, mencion Gerencia de mercadeo - MMG
25072	Santiago (sede)	Mercadeo, Mención  Mercadeo Politico
25073	Santiago (sede)	Educación Inicial  - MEI
25074	Santiago (sede)	Psicología Clínica  - MPC
25075	Santiago (sede)	Derecho Civil y Procesal Civil Contemporáneos MCP
25076	Santiago (sede)	Gerencia de Recursos Humanos 
25077	Santiago (sede)	Dirección Financiera - MDF
25078	Santiago (sede)	Legislación de Tierras  - MLT
25079	Santiago (sede)	Derecho Penal y Procesal Penal Contemporáneos  - MPP
25080	Santiago (sede)	Gestión de la Tecnología Educativa - MGT
25081	Santiago (sede)	Gestion de Instituciones Educativas Virtuales
25082	Santiago (sede)	Derecho Constitucional - MDC
232	Cibao Oriental (Nagua)	Psicología Educativa
25528	Nagua	Servicios Generales/Maestria
25527	Nagua	Servicios Generales/Doctorado
24737	Total oferta académica postgrado	\N
24736	Total oferta académica grado	\N
24738	Total oferta académica técnico superior	\N
434	Santo Domingo Oriental	Gestión de la Tecnología Educativa 
24767	Originales aceptados	Secciones de libros
435	Santiago (sede)	Gestión de la Tecnología Educativa 
436	Cibao Oriental (Nagua)	Gestion de Instituciones Educativas Virtuales
437	Santo Domingo Oriental	Gestion de Instituciones Educativas Virtuales
438	Santiago (sede)	Gestion de Instituciones Educativas Virtuales
439	Cibao Oriental (Nagua)	Derecho Constitucional
440	Santo Domingo Oriental	Derecho Constitucional
24779	Desfavorables	Frecuencia porcentual (%)
24778	Neutros	Frecuencia porcentual (%)
24777	Favorables	Frecuencia porcentual (%)
24776	Desfavorables	Frecuencia absoluta
24775	Neutros	Frecuencia absoluta
24774	Favorables	Frecuencia absoluta
441	Santiago (sede)	Derecho Constitucional
445	Cibao Oriental (Nagua)	Maestría en Terapia Familiar
446	Santo Domingo Oriental	Maestría en Terapia Familiar
4	Ciabao Oriental (Nagua)	
3	Santo Domingo Oriental	
2	Santiago (sede)	
447	Santiago (sede)	Maestría en Terapia Familiar
448	Cibao Oriental (Nagua)	 Innovación y Gestión Empresarial
449	Santo Domingo Oriental	 Innovación y Gestión Empresarial
3371	Santiago (sede)	Derecho
3366	Santo Domingo Oriental	Derecho
3362	Cibao Oriental (Nagua)	Derecho
444	Santiago (sede)	Historia, con Orientación a la Enseñanza 
443	Santo Domingo Oriental	Historia, con Orientación a la Enseñanza 
442	Cibao Oriental (Nagua)	Historia, con Orientación a la Enseñanza 
450	Santiago (sede)	 Innovación y Gestión Empresarial
451	Cibao Oriental (Nagua)	Dirección y Gestión Tributaria
452	Santo Domingo Oriental	Dirección y Gestión Tributaria
453	Santiago (sede)	Dirección y Gestión Tributaria
454	Cibao Oriental (Nagua)	Ciberseguridad
455	Santo Domingo Oriental	Ciberseguridad
456	Santiago (sede)	Ciberseguridad
457	Cibao Oriental (Nagua)	Ciencias de la Educación (Dr.)
458	Santo Domingo Oriental	Ciencias de la Educación (Dr.)
459	Santiago (sede)	Ciencias de la Educación (Dr.)
24757	Investigaciones culminadas y reportadas	
24756	Investigaciones aprobadas y en proceso	
24755	Investigaciones presentadas	
24730	Cibao Oriental (Nagua)	Agrimensura
24732	Santo Domingo Oriental	Agrimensura
24735	Santiago (sede)	Agrimensura
25083	Santiago (sede)	Historia, con Orientación a la Enseñanza 
25526	Santo Domingo	Servicios Generales/Grado-Pregrado
25525	Santo Domingo	Servicios Generales/Maestria
25524	Santo Domingo	Servicios Generales/Doctorado
25523	Santiago (sede)	Servicios Generales/Grado-Pregrado
25522	Santiago (sede)	Servicios Generales/Maestria
25521	Santiago (sede)	Servicios Generales/Doctorado
25520	Nagua	Auxiliares/Grado-Pregrado
25519	Nagua	Auxiliares/Maestria
24773	Publicaciones	Artículos
24772	Publicaciones	Ponencias/Memorias de eventos científicos
24771	Publicaciones	Secciones de libros
24770	Publicaciones	Libros
24769	Originales aceptados	Artículos
24768	Originales aceptados	Ponencias/Memorias de eventos científicos
24766	Originales aceptados	Libros
24765	Originales presentados para arbitrar	Artículos
24764	Originales presentados para arbitrar	Ponencias/Memorias de eventos científicos
24763	Originales presentados para arbitrar	Secciones de libros
24762	Originales presentados para arbitrar	Libros
25518	Nagua	Auxiliares/Doctorado
25517	Santo Domingo	Auxiliares/Grado-Pregrado
25516	Santo Domingo	Auxiliares/Maestria
25515	Santo Domingo	Auxiliares/Doctorado
24761	Memorias o publicaciones producto de eventos científicos	
24760	Congresos, simposios (llamados abiertos)	
24759	Artículos (Revistas UAPA)	
24758	Libros, colecciones, diccionarios	
24780	Coeficiente de desigualdad educativa	\N
25514	Santiago (sede)	Auxiliares/Grado-Pregrado
25513	Santiago (sede)	Auxiliares/Maestria
25512	Santiago (sede)	Auxiliares/Doctorado
25511	Nagua	Secretarias/Grado-Pregrado
25510	Nagua	Secretarias/Maestria
25509	Nagua	Secretarias/Doctorado
25508	Santo Domingo	Secretarias/Grado-Pregrado
25507	Santo Domingo	Secretarias/Maestria
25506	Santo Domingo	Secretarias/Doctorado
24754	Especialidad / Grado / Pregrado	Nagua
24753	Especialidad / Grado / Pregrado	Santo Domingo
24752	Especialidad / Grado / Pregrado	Santiago (Sede)
24751	Maestría	Nagua
24750	Maestría	Santo Domingo
24749	Maestría	Santiago (Sede)
24748	Doctorado	Nagua
24747	Doctorado	Santo Domingo
24746	Doctorado	Santiago (Sede)
25505	Santiago (sede)	Secretarias/Grado-Pregrado
25504	Santiago (sede)	Secretarias/Maestria
25503	Santiago (sede)	Secretarias/Doctorado
25502	Nagua	Asistentes/Grado-Pregrado
25501	Nagua	Asistentes/Maestria
25500	Nagua	Asistentes/Doctorado
25499	Santo Domingo	Asistentes/Grado-Pregrado
25498	Santo Domingo	Asistentes/Maestria
25497	Santo Domingo	Asistentes/Doctorado
25496	Santiago (sede)	Asistentes/Grado-Pregrado
25495	Santiago (sede)	Asistentes/Maestria
25084	Santiago (sede)	Maestría en Terapia Familiar - MTF
25085	Santiago (sede)	Innovación y Gestión Empresarial
25086	Santiago (sede)	Dirección y Gestión Tributaria
25087	Santiago (sede)	Ciberseguridad - MCS
25088	Santiago (sede)	Ciencias de la Educación (Dr.)-DCE
25089	Santo Domingo Oriental	Gerencia de Recursos Humanos  - MGH
25090	Santo Domingo Oriental	Mercadeo (Postgrado)
25091	Santo Domingo Oriental	Gestión de Centros Educativos  - MGC
25092	Santo Domingo Oriental	Historia, con Orientación a la Enseñanza - MAH
25093	Santo Domingo Oriental	Informática, con Orientación a la Enseñanza  - EIN
25094	Santo Domingo Oriental	Biología, con Orientación a la Enseñanza 
25095	Santo Domingo Oriental	Educación, Mención Lengua Española, Segundo Ciclo 
25096	Santo Domingo Oriental	Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL
25097	Santo Domingo Oriental	Educación, Matemática Física, Segundo Ciclo 
25098	Santo Domingo Oriental	Matemática, con Orientación a la Enseñanza - EMA
25099	Santo Domingo Oriental	Educación, Mención Historia y Geografía Segundo Ciclo 
25100	Santo Domingo Oriental	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM
25101	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
25102	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
25103	Santo Domingo Oriental	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
25104	Santo Domingo Oriental	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
25105	Santo Domingo Oriental	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario
25106	Santo Domingo Oriental	Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC
25107	Santo Domingo Oriental	Mercadeo, mencion Gerencia de mercadeo - MMG
25108	Santo Domingo Oriental	Mercadeo, Mención  Mercadeo Politico
25109	Santo Domingo Oriental	Educación Inicial  - MEI
25110	Santo Domingo Oriental	Psicología Clínica  - MPC
25111	Santo Domingo Oriental	Derecho Civil y Procesal Civil Contemporáneos MCP
25112	Santo Domingo Oriental	Gerencia de Recursos Humanos 
25113	Santo Domingo Oriental	Dirección Financiera - MDF
25114	Santo Domingo Oriental	Legislación de Tierras  - MLT
25115	Santo Domingo Oriental	Derecho Penal y Procesal Penal Contemporáneos  - MPP
25116	Santo Domingo Oriental	Gestión de la Tecnología Educativa - MGT
25117	Santo Domingo Oriental	Gestion de Instituciones Educativas Virtuales
25118	Santo Domingo Oriental	Derecho Constitucional - MDC
25119	Santo Domingo Oriental	Historia, con Orientación a la Enseñanza 
25120	Santo Domingo Oriental	Maestría en Terapia Familiar - MTF
25121	Santo Domingo Oriental	Innovación y Gestión Empresarial
25122	Santo Domingo Oriental	Dirección y Gestión Tributaria
25123	Santo Domingo Oriental	Ciberseguridad - MCS
25124	Santo Domingo Oriental	Ciencias de la Educación (Dr.)-DCE
25125	Cibao Oriental (Nagua)	Gerencia de Recursos Humanos  - MGH
25126	Cibao Oriental (Nagua)	Mercadeo (Postgrado)
25127	Cibao Oriental (Nagua)	Gestión de Centros Educativos  - MGC
25128	Cibao Oriental (Nagua)	Historia, con Orientación a la Enseñanza - MAH
25129	Cibao Oriental (Nagua)	Informática, con Orientación a la Enseñanza  - EIN
25130	Cibao Oriental (Nagua)	Biología, con Orientación a la Enseñanza 
25131	Cibao Oriental (Nagua)	Educación, Mención Lengua Española, Segundo Ciclo 
25132	Cibao Oriental (Nagua)	Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL
25133	Cibao Oriental (Nagua)	Educación, Matemática Física, Segundo Ciclo 
25134	Cibao Oriental (Nagua)	Matemática, con Orientación a la Enseñanza - EMA
25135	Cibao Oriental (Nagua)	Educación, Mención Historia y Geografía Segundo Ciclo 
25136	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM
25137	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario
25138	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario
25139	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario
25140	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario
25141	Cibao Oriental (Nagua)	Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario
25142	Cibao Oriental (Nagua)	Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC
25143	Cibao Oriental (Nagua)	Mercadeo, mencion Gerencia de mercadeo - MMG
25144	Cibao Oriental (Nagua)	Mercadeo, Mención  Mercadeo Politico
25145	Cibao Oriental (Nagua)	Educación Inicial  - MEI
25146	Cibao Oriental (Nagua)	Psicología Clínica  - MPC
25147	Cibao Oriental (Nagua)	Derecho Civil y Procesal Civil Contemporáneos MCP
25148	Cibao Oriental (Nagua)	Gerencia de Recursos Humanos 
25149	Cibao Oriental (Nagua)	Dirección Financiera - MDF
25150	Cibao Oriental (Nagua)	Legislación de Tierras  - MLT
25151	Cibao Oriental (Nagua)	Derecho Penal y Procesal Penal Contemporáneos  - MPP
25152	Cibao Oriental (Nagua)	Gestión de la Tecnología Educativa - MGT
25153	Cibao Oriental (Nagua)	Gestion de Instituciones Educativas Virtuales
25154	Cibao Oriental (Nagua)	Derecho Constitucional - MDC
25155	Cibao Oriental (Nagua)	Historia, con Orientación a la Enseñanza 
25156	Cibao Oriental (Nagua)	Maestría en Terapia Familiar - MTF
25157	Cibao Oriental (Nagua)	Innovación y Gestión Empresarial
25158	Cibao Oriental (Nagua)	Dirección y Gestión Tributaria
25159	Cibao Oriental (Nagua)	Ciberseguridad - MCS
25160	Cibao Oriental (Nagua)	Ciencias de la Educación (Dr.)-DCE
420	Santiago (sede)	Derecho Civil y Procesal Civil Contemporáneos
424	Cibao Oriental (Nagua)	Dirección Financiera 
425	Santo Domingo Oriental	Dirección Financiera 
426	Santiago (sede)	Dirección Financiera 
427	Cibao Oriental (Nagua)	Legislación de Tierras 
428	Santo Domingo Oriental	Legislación de Tierras 
429	Santiago (sede)	Legislación de Tierras 
430	Cibao Oriental (Nagua)	Derecho Penal y Procesal Penal Contemporáneos
431	Santo Domingo Oriental	Derecho Penal y Procesal Penal Contemporáneos
432	Santiago (sede)	Derecho Penal y Procesal Penal Contemporáneos
433	Cibao Oriental (Nagua)	Gestión de la Tecnología Educativa 
24834	Cibao Oriental (Nagua)	Enfermería - ENF
24835	Santo Domingo Oriental	Enfermería - ENF
24836	Santiago (sede)	Enfermería - ENF
25200	Cibao Oriental (Nagua)	Dominicana
25199	Cibao Oriental (Nagua)	Haitiana
25198	Cibao Oriental (Nagua)	Colombiana
25197	Cibao Oriental (Nagua)	Cubana
25196	Cibao Oriental (Nagua)	Venezolana
25195	Cibao Oriental (Nagua)	Estadounidense
25194	Cibao Oriental (Nagua)	Española
25192	Santo Domingo Oriental	Dominicana
25191	Santo Domingo Oriental	Haitiana
25190	Santo Domingo Oriental	Colombiana
25189	Santo Domingo Oriental	Cubana
25188	Santo Domingo Oriental	Venezolana
25187	Santo Domingo Oriental	Estadounidense
25186	Santo Domingo Oriental	Española
25170	Santiago (sede)	Española
25169	Santiago (sede)	Estadounidense
25168	Santiago (sede)	Venezolana
25167	Santiago (sede)	Cubana
25166	Santiago (sede)	Colombiana
25165	Santiago (sede)	Haitiana
25164	Santiago (sede)	Dominicana
25494	Santiago (sede)	Asistentes/Doctorado
25493	Nagua	Analistas/Grado-Pregrado
25492	Nagua	Analistas/Maestria
25491	Nagua	Analistas/Doctorado
25490	Santo Domingo	Analistas/Grado-Pregrado
25489	Santo Domingo	Analistas/Maestria
25488	Santo Domingo	Analistas/Doctorado
25487	Santiago (sede)	Analistas/Grado-Pregrado
25486	Santiago (sede)	Analistas/Maestria
25485	Santiago (sede)	Analistas/Doctorado
25484	Nagua	Especialistas/Grado-Pregrado
25483	Nagua	Especialistas/Maestria
25482	Nagua	Especialistas/Doctorado
25481	Santo Domingo	Especialistas/Grado-Pregrado
25480	Santo Domingo	Especialistas/Maestria
25479	Santo Domingo	Especialistas/Doctorado
25478	Santiago (sede)	Especialistas/Grado-Pregrado
25302	Santo Domingo Oriental	Ciencias jurídicas y políticas
25301	Santiago (sede)	Postgrado
25300	Cibao Oriental (Nagua)	Postgrado
25299	Cibao Oriental (Nagua)	Turismo / idiomas
25298	Cibao Oriental (Nagua)	Ciencias de la salud y psicología
25297	Cibao Oriental (Nagua)	Ingeniería y tecnología
25296	Cibao Oriental (Nagua)	Negocios
25295	Cibao Oriental (Nagua)	Educación y formación general
25294	Cibao Oriental (Nagua)	Ciencias jurídicas y políticas
25292	Santo Domingo Oriental	Turismo / idiomas
25291	Santo Domingo Oriental	Ciencias de la salud y psicología
25290	Santo Domingo Oriental	Ingeniería y tecnología
25289	Santo Domingo Oriental	Negocios
25288	Santo Domingo Oriental	Educación y formación general
25287	Santo Domingo Oriental	Postgrado
25286	Santiago (sede)	Turismo / idiomas
25285	Santiago (sede)	Ciencias de la salud y psicología
25284	Santiago (sede)	Ingeniería y tecnología
25283	Santiago (sede)	Negocios
25282	Santiago (sede)	Educación y formación general
25281	Santiago (sede)	Ciencias jurídicas y políticas
25477	Santiago (sede)	Especialistas/Maestria
25476	Santiago (sede)	Especialistas/Doctorado
25475	Nagua	Coordinadores/Grado-Pregrado
25474	Nagua	Coordinadores/Maestria
25473	Nagua	Coordinadores/Doctorado
25472	Santo Domingo	Coordinadores/Grado-Pregrado
25471	Santo Domingo	Coordinadores/Maestria
25470	Santo Domingo	Coordinadores/Doctorado
25469	Santiago (sede)	Coordinadores/Grado-Pregrado
25468	Santiago (sede)	Coordinadores/Maestria
25467	Santiago (sede)	Coordinadores/Doctorado
25466	Nagua	Directores-Encargados/Grado-Pregrado
25465	Nagua	Directores-Encargados/Maestria
25464	Nagua	Directores-Encargados/Doctorado
25463	Santo Domingo	Directores-Encargados/Grado-Pregrado
25462	Santo Domingo	Directores-Encargados/Maestria
25461	Santo Domingo	Directores-Encargados/Doctorado
25460	Santiago (sede)	Directores-Encargados/Grado-Pregrado
25459	Santiago (sede)	Directores-Encargados/Maestria
25458	Santiago (sede)	Directores-Encargados/Doctorado
25457	Nagua	Vicerrectores/Grado-Pregrado
25456	Nagua	Vicerrectores/Maestria
25455	Nagua	Vicerrectores/Doctorado
25454	Santo Domingo	Vicerrectores/Grado-Pregrado
25453	Santo Domingo	Vicerrectores/Maestria
25452	Santo Domingo	Vicerrectores/Doctorado
25451	Santiago (sede)	Vicerrectores/Grado-Pregrado
25450	Santiago (sede)	Vicerrectores/Maestria
25449	Santiago (sede)	Vicerrectores/Doctorado
25260	Santo Domingo Oriental	Director de Escuela
25259	Cibao Oriental (Nagua)	Director de Escuela
25258	 Santiago (sede)	Director de Escuela
25257	Santo Domingo Oriental	Campus Virtual
25256	Cibao Oriental (Nagua)	Campus Virtual
25255	 Santiago (sede)	Campus Virtual
25254	Santo Domingo Oriental	Entorno General
25253	Cibao Oriental (Nagua)	Entorno General
25252	 Santiago (sede)	Entorno General
25251	Santo Domingo Oriental	Cafetería
25250	Cibao Oriental (Nagua)	Cafetería
25249	 Santiago (sede)	Cafetería
25248	Santo Domingo Oriental	Secretaria Edificio Administrativo
25247	Cibao Oriental (Nagua)	Secretaria Edificio Administrativo
25246	 Santiago (sede)	Secretaria Edificio Administrativo
25245	Santo Domingo Oriental	Biblioteca y Audiovisuales
25244	Cibao Oriental (Nagua)	Biblioteca y Audiovisuales
25243	 Santiago (sede)	Biblioteca y Audiovisuales
25242	Santo Domingo Oriental	Economato
25241	Cibao Oriental (Nagua)	Economato
25240	 Santiago (sede)	Economato
25239	Santo Domingo Oriental	Admisiones
25238	Cibao Oriental (Nagua)	Admisiones
25237	 Santiago (sede)	Admisiones
25236	Santo Domingo Oriental	Caja
25235	Cibao Oriental (Nagua)	Caja
25234	 Santiago (sede)	Caja
25233	Santo Domingo Oriental	Registro
25232	Cibao Oriental (Nagua)	Registro
25231	 Santiago (sede)	Registro
25553	Cibao Oriental (Nagua)	Trabajo familiar
25552	Cibao Oriental (Nagua)	Empleado en sector público
25551	Cibao Oriental (Nagua)	Empleado en sector privado
25550	Cibao Oriental (Nagua)	Dueño/cuenta propia
25549	Santo Domingo Oriental	Trabajo familiar
25548	Santo Domingo Oriental	Empleado en sector público
25547	Santo Domingo Oriental	Empleado en sector privado
25546	Santo Domingo Oriental	Dueño/cuenta propia
25545	Santiago (sede)	Trabajo familiar
25544	Santiago (sede)	Empleado en sector público
25543	Santiago (sede)	Empleado en sector privado
25542	Santiago (sede)	Dueño/cuenta propia
24831	Nagua	Seminarios / Certificacion de coaching
24830	Santo Domingo	Seminarios / Certificacion de coaching
24829	Santiago (sede)	Seminarios / Certificacion de coaching
24828	Nagua	Seminarios / Conferencias
24827	Santo Domingo	Seminarios / Conferencias
24826	Santiago (sede)	Seminarios / Conferencias
24825	Nagua	Seminarios
24824	Nagua	Cursos/ talleres
24823	Nagua	Diplomados
24822	Santo Domingo	Seminarios
24821	Santo Domingo	Cursos/ talleres
24820	Santo Domingo	Diplomados
24819	Santiago (sede)	Seminarios
24818	Santiago (sede)	Cursos/ talleres
24817	Santiago (sede)	Diplomados
166	Cibao Oriental (Nagua)	Derecho
167	Santo Domingo Oriental	Derecho
168	Santiago (sede)	Derecho
169	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Educación Básica 
170	Santo Domingo Oriental	Ciencia de la Educación, Mención Educación Básica 
171	Santiago (sede)	Ciencia de la Educación, Mención Educación Básica 
172	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Educación Inicial 
173	Santo Domingo Oriental	Ciencia de la Educación, Mención Educación Inicial 
174	Santiago (sede)	Ciencia de la Educación, Mención Educación Inicial 
175	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Lengua Española 
176	Santo Domingo Oriental	Ciencia de la Educación, Mención Lengua Española 
177	Santiago (sede)	Ciencia de la Educación, Mención Lengua Española 
178	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Matemática Física 
179	Santo Domingo Oriental	Ciencia de la Educación, Mención Matemática Física 
180	Santiago (sede)	Ciencia de la Educación, Mención Matemática Física 
181	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Ciencias Sociales 
182	Santo Domingo Oriental	Ciencia de la Educación, Mención Ciencias Sociales 
183	Santiago (sede)	Ciencia de la Educación, Mención Ciencias Sociales 
184	Cibao Oriental (Nagua)	Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 
185	Santo Domingo Oriental	Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 
186	Santiago (sede)	Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 
\.


--
-- Data for Name: core_segregacion_indicador; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_segregacion_indicador (id, segregacion_id, indicador_id) FROM stdin;
469	432	284
470	432	285
471	431	284
472	431	285
473	430	284
474	430	285
475	429	284
476	429	285
477	428	284
478	428	285
479	427	284
480	427	285
481	426	284
482	426	285
483	425	284
484	425	285
485	424	284
486	424	285
487	423	284
488	423	285
489	422	284
490	422	285
491	421	284
492	421	285
493	420	284
494	420	285
495	419	284
496	419	285
497	418	284
498	418	285
499	417	284
500	417	285
501	416	284
502	416	285
503	415	284
504	415	285
505	414	284
506	414	285
507	413	284
508	413	285
509	412	284
510	412	285
511	411	284
512	411	285
513	410	284
514	410	285
515	409	284
516	409	285
517	408	284
518	408	285
519	407	284
520	407	285
521	406	284
522	406	285
523	405	284
524	405	285
525	404	284
526	404	285
527	403	284
528	403	285
529	402	284
530	402	285
531	401	284
532	401	285
533	400	284
534	400	285
535	399	284
536	399	285
537	398	284
538	398	285
539	397	284
540	397	285
541	396	284
542	396	285
543	395	284
544	395	285
545	394	284
546	394	285
547	393	284
548	393	285
549	392	284
550	392	285
551	391	284
552	391	285
553	390	284
554	390	285
555	389	284
556	389	285
557	388	284
558	388	285
559	387	284
560	387	285
561	386	284
562	386	285
563	385	284
564	385	285
565	384	284
566	384	285
567	383	284
568	383	285
569	382	284
570	382	285
571	381	284
572	381	285
573	380	284
574	380	285
575	379	284
576	379	285
577	378	284
578	378	285
579	377	284
580	377	285
581	376	284
582	376	285
583	375	284
584	375	285
585	374	284
586	374	285
587	373	284
588	373	285
589	372	284
590	372	285
591	371	284
592	371	285
593	370	284
594	370	285
595	369	284
596	369	285
597	368	284
598	368	285
599	367	284
600	367	285
601	366	284
602	366	285
603	365	284
604	365	285
605	364	284
606	364	285
607	363	284
608	363	285
609	362	284
610	362	285
611	361	284
612	361	285
613	360	284
614	360	285
615	359	284
616	359	285
617	358	284
618	358	285
619	357	284
620	357	285
621	356	284
622	356	285
623	355	284
624	355	285
625	354	284
626	354	285
627	353	284
628	353	285
629	352	284
630	352	285
631	243	284
632	243	285
633	242	284
634	242	285
635	241	284
636	241	285
637	240	284
638	240	285
639	239	284
640	239	285
641	238	284
642	238	285
643	237	284
644	237	285
645	236	284
646	236	285
647	235	284
648	235	285
649	234	284
650	234	285
651	233	284
652	233	285
653	232	284
654	232	285
655	231	284
656	231	285
657	230	284
658	230	285
659	229	284
660	229	285
661	228	284
662	228	285
663	227	284
664	227	285
665	226	284
666	226	285
667	225	284
668	225	285
669	224	284
670	224	285
671	223	284
672	223	285
673	222	284
674	222	285
675	221	284
676	221	285
677	220	284
678	220	285
679	219	284
680	219	285
681	218	284
682	218	285
683	217	284
684	217	285
685	216	284
686	216	285
687	215	284
688	215	285
689	214	284
690	214	285
691	213	284
692	213	285
693	212	284
694	212	285
695	211	284
696	211	285
697	210	284
698	210	285
699	209	284
700	209	285
701	208	284
702	208	285
703	207	284
704	207	285
705	206	284
706	206	285
707	205	284
708	205	285
709	204	284
710	204	285
711	203	284
712	203	285
713	202	284
714	202	285
715	201	284
716	201	285
717	200	284
718	200	285
719	199	284
720	199	285
721	198	284
722	198	285
723	197	284
724	197	285
725	196	284
726	196	285
727	195	284
728	195	285
729	194	284
730	194	285
731	193	284
732	193	285
733	192	284
734	192	285
735	191	284
736	191	285
737	190	284
738	190	285
739	189	284
740	189	285
741	188	284
742	188	285
743	187	284
744	187	285
745	186	284
746	186	285
747	185	284
748	185	285
749	184	284
750	184	285
751	183	284
752	183	285
753	182	284
754	182	285
755	181	284
756	181	285
757	180	284
758	180	285
759	179	284
760	179	285
761	178	284
762	178	285
763	177	284
764	177	285
765	176	284
766	176	285
767	175	284
768	175	285
769	174	284
770	174	285
771	173	284
772	173	285
773	172	284
774	172	285
775	171	284
776	171	285
777	170	284
778	170	285
779	169	284
780	169	285
781	168	284
782	168	285
783	167	284
784	167	285
785	166	284
786	166	285
787	4	352
788	4	281
789	4	282
790	4	283
791	4	350
792	4	351
793	3	352
794	3	281
795	3	282
796	3	283
797	3	350
798	3	351
799	2	352
800	2	281
801	2	282
802	2	283
803	2	350
804	2	351
806	24737	277
816	24779	341
817	24778	341
818	24777	341
819	24776	341
820	24775	341
821	24774	341
826	3	278
827	3	279
828	2	278
829	2	279
839	24754	331
840	24753	331
841	24752	331
842	24751	331
843	24750	331
844	24749	331
845	24748	331
846	24747	331
847	24746	331
851	24757	332
852	24756	332
853	24755	332
866	24773	333
867	24772	333
868	24771	333
869	24770	333
870	24769	333
871	24768	333
872	24767	333
873	24766	333
874	24765	333
875	24764	333
876	24763	333
805	24736	277
807	24738	277
1548	25529	327
1549	25528	327
1550	25527	327
1551	25526	327
1552	25525	327
1553	25524	327
1554	25523	327
1555	25522	327
1556	25521	327
1557	25520	327
1558	25519	327
1559	25518	327
1560	25517	327
1561	25516	327
1562	25515	327
1563	25514	327
1564	25513	327
1565	25512	327
1566	25511	327
1567	25510	327
1568	25509	327
1569	25508	327
1570	25507	327
1571	25506	327
1572	25505	327
1573	25504	327
1574	25503	327
1575	25502	327
1576	25501	327
1577	25500	327
403	24735	284
404	24735	285
405	24732	284
406	24732	285
407	24730	284
408	24730	285
409	3371	284
410	3371	285
411	3366	284
412	3366	285
413	3362	284
414	3362	285
415	459	284
416	459	285
417	458	284
418	458	285
419	457	284
420	457	285
421	456	284
422	456	285
423	455	284
424	455	285
425	454	284
426	454	285
427	453	284
428	453	285
429	452	284
430	452	285
431	451	284
432	451	285
433	450	284
434	450	285
435	449	284
436	449	285
437	448	284
438	448	285
439	447	284
440	447	285
441	446	284
442	446	285
443	445	284
444	445	285
445	444	284
446	444	285
447	443	284
448	443	285
449	442	284
450	442	285
451	441	284
452	441	285
453	440	284
454	440	285
455	439	284
456	439	285
457	438	284
458	438	285
459	437	284
460	437	285
461	436	284
462	436	285
463	435	284
464	435	285
465	434	284
466	434	285
467	433	284
468	433	285
1578	25499	327
1579	25498	327
1580	25497	327
1581	25496	327
1582	25495	327
877	24762	333
1583	25494	327
1584	25493	327
1585	25492	327
1586	25491	327
882	24761	334
883	24760	334
884	24759	334
885	24758	334
886	24780	272
1587	25490	327
1588	25489	327
1589	25488	327
1590	25487	327
1591	25486	327
892	24836	284
893	24835	284
894	24834	284
895	166	278
896	166	279
1592	25485	327
1593	25484	327
1594	25483	327
1595	25482	327
1596	25481	327
1597	25480	327
1598	25479	327
1599	25478	327
1600	25477	327
1601	25476	327
1602	25475	327
1603	25474	327
1604	25473	327
1605	25472	327
1606	25471	327
1607	25470	327
1608	25469	327
1609	25468	327
1610	25467	327
1611	25466	327
1612	25465	327
1613	25464	327
1614	25463	327
1615	25462	327
1616	25461	327
1617	25460	327
1618	25459	327
1619	25458	327
1620	25457	327
1621	25456	327
1622	25455	327
1623	25454	327
1624	25453	327
1625	25452	327
1626	25451	327
1627	25450	327
1628	25449	327
1668	24831	353
1669	24830	353
1670	24829	353
1671	24828	353
1672	24827	353
1673	24826	353
1674	24825	353
1675	24824	353
1676	24823	353
1677	24822	353
1678	24821	353
1679	24820	353
1680	24819	353
1681	24818	353
1682	24817	353
1185	25260	311
1186	25259	311
1187	25258	311
1188	25257	311
1189	25256	311
1190	25255	311
1005	25053	284
1006	25054	284
1007	25055	284
1008	25056	284
1009	25057	284
1010	25058	284
1011	25059	284
1012	25060	284
1013	25061	284
1014	25062	284
1015	25063	284
1016	25064	284
1017	25065	284
1018	25066	284
1019	25067	284
1020	25068	284
1021	25069	284
1022	25070	284
1023	25071	284
1024	25072	284
1025	25073	284
1026	25074	284
1027	25075	284
1028	25076	284
1029	25077	284
1030	25078	284
1031	25079	284
1032	25080	284
1033	25081	284
1034	25082	284
1035	25083	284
1036	25084	284
1037	25085	284
1038	25086	284
1039	25087	284
1040	25088	284
1041	25089	284
1042	25090	284
1043	25091	284
1044	25092	284
1045	25093	284
1046	25094	284
1047	25095	284
1048	25096	284
1049	25097	284
1050	25098	284
1051	25099	284
1052	25100	284
1053	25101	284
1054	25102	284
1055	25103	284
1056	25104	284
1057	25105	284
1058	25106	284
1059	25107	284
1060	25108	284
1061	25109	284
1062	25110	284
1063	25111	284
1064	25112	284
1065	25113	284
1066	25114	284
1067	25115	284
1068	25116	284
1069	25117	284
1070	25118	284
1071	25119	284
1072	25120	284
1073	25121	284
1074	25122	284
1075	25123	284
1076	25124	284
1077	25125	284
1078	25126	284
1079	25127	284
1080	25128	284
1081	25129	284
1082	25130	284
1083	25131	284
1084	25132	284
1085	25133	284
1086	25134	284
1087	25135	284
1088	25136	284
1089	25137	284
1090	25138	284
1091	25139	284
1092	25140	284
1093	25141	284
1094	25142	284
1095	25143	284
1096	25144	284
1097	25145	284
1098	25146	284
1099	25147	284
1100	25148	284
1101	25149	284
1102	25150	284
1103	25151	284
1104	25152	284
1105	25153	284
1106	25154	284
1107	25155	284
1108	25156	284
1109	25157	284
1110	25158	284
1111	25159	284
1112	25160	284
1191	25254	311
1192	25253	311
1193	25252	311
1194	25251	311
1195	25250	311
1196	25249	311
1197	25248	311
1198	25247	311
1199	25246	311
1200	25245	311
1201	25244	311
1202	25243	311
1203	25242	311
1204	25241	311
1205	25240	311
1206	25239	311
1207	25238	311
1208	25237	311
1209	25236	311
1210	25235	311
1211	25234	311
1134	25200	286
1135	25199	286
1136	25198	286
1137	25197	286
1138	25196	286
1139	25195	286
1140	25194	286
1141	25192	286
1142	25191	286
1143	25190	286
1144	25189	286
1145	25188	286
1146	25187	286
1147	25186	286
1148	25170	286
1149	25169	286
1150	25168	286
1151	25167	286
1152	25166	286
1153	25165	286
1154	25164	286
1212	25233	311
1213	25232	311
1214	25231	311
1641	25553	349
1642	25552	349
1643	25551	349
1644	25550	349
1645	25549	349
1646	25548	349
1647	25547	349
1648	25546	349
1649	25545	349
1650	25544	349
1651	25543	349
1652	25542	349
1341	25302	312
1342	25302	313
1343	25302	314
1344	25302	315
1345	25302	316
1346	25302	317
1347	25301	312
1348	25301	313
1349	25301	314
1350	25301	315
1351	25301	316
1352	25301	317
1353	25300	312
1354	25300	313
1355	25300	314
1356	25300	315
1357	25300	316
1358	25300	317
1359	25299	312
1360	25299	313
1361	25299	314
1362	25299	315
1363	25299	316
1364	25299	317
1365	25298	312
1366	25298	313
1367	25298	314
1368	25298	315
1369	25298	316
1370	25298	317
1371	25297	312
1372	25297	313
1373	25297	314
1374	25297	315
1375	25297	316
1376	25297	317
1377	25296	312
1378	25296	313
1379	25296	314
1380	25296	315
1381	25296	316
1382	25296	317
1383	25295	312
1384	25295	313
1385	25295	314
1386	25295	315
1387	25295	316
1388	25295	317
1389	25294	312
1390	25294	313
1391	25294	314
1392	25294	315
1393	25294	316
1394	25294	317
1395	25292	312
1396	25292	313
1397	25292	314
1398	25292	315
1399	25292	316
1400	25292	317
1401	25291	312
1402	25291	313
1403	25291	314
1404	25291	315
1405	25291	316
1406	25291	317
1407	25290	312
1408	25290	313
1409	25290	314
1410	25290	315
1411	25290	316
1412	25290	317
1413	25289	312
1414	25289	313
1415	25289	314
1416	25289	315
1417	25289	316
1418	25289	317
1419	25288	312
1420	25288	313
1421	25288	314
1422	25288	315
1423	25288	316
1424	25288	317
1425	25287	312
1426	25287	313
1427	25287	314
1428	25287	315
1429	25287	316
1430	25287	317
1431	25286	312
1432	25286	313
1433	25286	314
1434	25286	315
1435	25286	316
1436	25286	317
1437	25285	312
1438	25285	313
1439	25285	314
1440	25285	315
1441	25285	316
1442	25285	317
1443	25284	312
1444	25284	313
1445	25284	314
1446	25284	315
1447	25284	316
1448	25284	317
1449	25283	312
1450	25283	313
1451	25283	314
1452	25283	315
1453	25283	316
1454	25283	317
1455	25282	312
1456	25282	313
1457	25282	314
1458	25282	315
1459	25282	316
1460	25282	317
1461	25281	312
1462	25281	313
1463	25281	314
1464	25281	315
1465	25281	316
1466	25281	317
\.


--
-- Data for Name: core_termino; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.core_termino (id, tipo, variable, definicion, algoritmo_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2021-05-03 14:05:50.302665+00	60	C0 Contexto económico y social	1	new through import_export	16	1
2	2021-05-03 14:05:50.318403+00	61	C1 Oferta Académica	1	new through import_export	16	1
3	2021-05-03 14:05:50.33195+00	62	C2 Demanda Universitaria	1	new through import_export	16	1
4	2021-05-03 14:05:50.345578+00	63	C3 Procesos Académicos	1	new through import_export	16	1
5	2021-05-03 14:05:50.358186+00	64	C4 Resultados Académicos	1	new through import_export	16	1
6	2021-05-03 14:05:50.371712+00	65	C5 Satisfacción de los Usuarios	1	new through import_export	16	1
7	2021-05-03 14:05:50.384773+00	66	C6 Recursos Humanos	1	new through import_export	16	1
8	2021-05-03 14:05:50.397792+00	67	C7 Investigación y Publicaciones	1	new through import_export	16	1
9	2021-05-03 14:05:50.41063+00	68	C8 Extension y Responsabilidad Social	1	new through import_export	16	1
10	2021-05-03 14:05:50.423755+00	69	C9 Redes Sociales	1	new through import_export	16	1
11	2021-05-03 14:05:50.437221+00	70	C10 Inserción Laboral	1	new through import_export	16	1
12	2021-05-03 14:05:50.450724+00	71	C11 Patrimonio de la  Universidad	1	new through import_export	16	1
13	2021-05-03 14:05:50.464189+00	72	C12 Educación Continua	1	new through import_export	16	1
14	2021-05-03 14:06:48.996066+00	270	CES.01 Tasa de inflación	1	new through import_export	18	1
15	2021-05-03 14:06:49.01523+00	271	CES.02 Estimaciones y proyecciones de la población total por año calendario	1	new through import_export	18	1
16	2021-05-03 14:06:49.034796+00	272	CES.03 Gasto público en educación como porcentaje del PIB por nivel educativo	1	new through import_export	18	1
17	2021-05-03 14:06:49.053919+00	273	CES.04 Coeficiente de desigualdad educativa	1	new through import_export	18	1
18	2021-05-03 14:06:49.073505+00	274	CES.05 Tasa de analfabetismo de la población de 15 años y más	1	new through import_export	18	1
19	2021-05-03 14:06:49.093523+00	275	CES.06 Tasa bruta de matrícula nivel superior	1	new through import_export	18	1
20	2021-05-03 14:06:49.116837+00	276	CES.07 Índice de paridad de género en tasa bruta de matricula según nivel educativo	1	new through import_export	18	1
21	2021-05-03 14:06:49.136989+00	277	OA.01 Distribución de la oferta académica por recinto	1	new through import_export	18	1
22	2021-05-03 14:06:49.155832+00	278	OA.02 Distribución Oferta Académica a nivel de Grado por recinto	1	new through import_export	18	1
23	2021-05-03 14:06:49.174961+00	279	OA.03 Distribución Oferta Académica a nivel de Post-Grado por recinto	1	new through import_export	18	1
24	2021-05-03 14:06:49.194305+00	280	OA.04 Distribución de la oferta académica por área de conocimiento (Escuela)	1	new through import_export	18	1
25	2021-05-03 14:06:49.215922+00	281	DU.01 Solicitudes de Admisión	1	new through import_export	18	1
26	2021-05-03 14:06:49.237786+00	282	DU.02 Solicitudes de admisión aprobadas	1	new through import_export	18	1
27	2021-05-03 14:06:49.258059+00	283	DU.03 Participantes de nuevo ingreso por recinto	1	new through import_export	18	1
28	2021-05-03 14:06:49.276671+00	284	DU.04 Participantes de nuevo ingreso por carrera	1	new through import_export	18	1
29	2021-05-03 14:06:49.29729+00	285	DU.05 Participantes de nuevo ingreso transferidos	1	new through import_export	18	1
30	2021-05-03 14:06:49.316082+00	286	DU.06 Participantes matriculados de nuevo ingreso según nacionalidad	1	new through import_export	18	1
31	2021-05-03 14:06:49.333239+00	287	DU.07 Posición de las instituciones de educación superior según el mayor nivel de registro de matrículas de nuevo ingreso	1	new through import_export	18	1
32	2021-05-03 14:06:49.350129+00	288	PA.01 Participantes Matriculados	1	new through import_export	18	1
33	2021-05-03 14:06:49.367933+00	289	PA.02 Participantes Egresados	1	new through import_export	18	1
34	2021-05-03 14:06:49.383735+00	290	PA.03 Participantes retirados	1	new through import_export	18	1
35	2021-05-03 14:06:49.399901+00	291	PA.04 Cambios a prueba académica	1	new through import_export	18	1
36	2021-05-03 14:06:49.4167+00	292	PA.05 Cambios de carrera	1	new through import_export	18	1
37	2021-05-03 14:06:49.432754+00	293	PA.06 Participantes por facilitador	1	new through import_export	18	1
38	2021-05-03 14:06:49.448279+00	294	PA.07 Participantes Egresados reinscritos	1	new through import_export	18	1
39	2021-05-03 14:06:49.463481+00	295	PA.08 Participantes activos	1	new through import_export	18	1
40	2021-05-03 14:06:49.478567+00	296	PA.09 Estudiantes egresados trasferidos de otra universidad	1	new through import_export	18	1
41	2021-05-03 14:06:49.494243+00	297	PA.10 Egresados interesados en realizar alguna especialidad o post grado en la UAPA	1	new through import_export	18	1
42	2021-05-03 14:06:49.511634+00	298	PA.11 Egresados en el tiempo mínimo según pensum 	1	new through import_export	18	1
43	2021-05-03 14:06:49.528158+00	299	RA.01 Tasa de abandono	1	new through import_export	18	1
44	2021-05-03 14:06:49.544349+00	300	RA.02 Tasa de rendimiento	1	new through import_export	18	1
45	2021-05-03 14:06:49.560643+00	301	RA.03 Tasa de éxito	1	new through import_export	18	1
46	2021-05-03 14:06:49.577007+00	302	RA.04 Tasa de Graduación	1	new through import_export	18	1
47	2021-05-03 14:06:49.591883+00	303	RA.05 Tasa de eficiencia terminal	1	new through import_export	18	1
48	2021-05-03 14:06:49.607425+00	304	RA.06 Duración media de estudios	1	new through import_export	18	1
49	2021-05-03 14:06:49.623175+00	305	RA.07 Nota media de los participantes graduados	1	new through import_export	18	1
50	2021-05-03 14:06:49.638949+00	306	SU.01 Satisfacción con el desempeño docente	1	new through import_export	18	1
51	2021-05-03 14:06:49.655201+00	307	SU.02 Cumplimiento de las obligaciones docentes	1	new through import_export	18	1
52	2021-05-03 14:06:49.671339+00	308	SU.03 Satisfacción de los participantes con el plan de estudios	1	new through import_export	18	1
53	2021-05-03 14:06:49.687724+00	309	SU.04 Satisfacción de los egresados con el plan de estudios	1	new through import_export	18	1
54	2021-05-03 14:06:49.706513+00	310	SU.05 Satisfacción de los facilitadores con el plan de estudios	1	new through import_export	18	1
55	2021-05-03 14:06:49.726184+00	311	SU.06 Satisfacción del personal administrativo y de servicios con la gestión de los programas académicos	1	new through import_export	18	1
56	2021-05-03 14:06:49.744715+00	312	SU.07 Satisfacción de los participantes extranjeros con los servicios académicos	1	new through import_export	18	1
57	2021-05-03 14:06:49.764838+00	313	SU.08 Satisfacción de los participantes extranjeros con los servicios no académicos	1	new through import_export	18	1
58	2021-05-03 14:06:49.785145+00	314	SU.09 Tendencia de la satisfacción de los participantes en el extranjero	1	new through import_export	18	1
59	2021-05-03 14:06:49.811733+00	315	SU.10 Satisfacción de los participantes en el extranjero por dimensiones	1	new through import_export	18	1
119	2021-05-03 14:08:42.1258+00	447	Santiago (sede)-Maestría en Terapia Familiar	1	new through import_export	21	1
60	2021-05-03 14:06:49.832668+00	316	SU.11 Percepción de satisfacción de los empleados con el clima laboral	1	new through import_export	18	1
61	2021-05-03 14:06:49.852807+00	317	SU.12 Percepción de satisfacción de los empleados con el clima laboral por dimensiones	1	new through import_export	18	1
62	2021-05-03 14:06:49.873099+00	318	SU.13 Porcentaje de satisfacción de los participantes	1	new through import_export	18	1
63	2021-05-03 14:06:49.89302+00	319	SU.14 Comparación del porcentaje de satisfacción por recinto	1	new through import_export	18	1
64	2021-05-03 14:06:49.913377+00	320	SU.15 Comparación del porcentaje de satisfacción de los empleados	1	new through import_export	18	1
65	2021-05-03 14:06:49.93829+00	321	RH.01 Personal docente por horas	1	new through import_export	18	1
66	2021-05-03 14:06:49.953745+00	322	RH.02 Personal docente a tiempo completo	1	new through import_export	18	1
67	2021-05-03 14:06:49.968609+00	323	RH.02.1 Personal docente de medio tiempo	1	new through import_export	18	1
68	2021-05-03 14:06:49.982841+00	324	RH.03 Titulación del personal docente	1	new through import_export	18	1
69	2021-05-03 14:06:49.997378+00	325	RH.04 Personal docente funcionario	1	new through import_export	18	1
70	2021-05-03 14:06:50.01245+00	326	RH.05 Personal administrativo y de servicios a tiempo completo	1	new through import_export	18	1
71	2021-05-03 14:06:50.02719+00	327	RH.06 Personal administrativo y de servicios a medio tiempo	1	new through import_export	18	1
72	2021-05-03 14:06:50.04251+00	328	RH.07 Relación PAS/Docente	1	new through import_export	18	1
73	2021-05-03 14:06:50.058+00	329	RH.08 Distribución porcentual de empleados administrativos por recinto y sexo, según nivel académico más alto	1	new through import_export	18	1
74	2021-05-03 14:06:50.072783+00	330	RH.09 Cantidad de empleados administrativos por nivel académico más alto, según recinto y categoría ocupacional, 2017	1	new through import_export	18	1
75	2021-05-03 14:06:50.087322+00	331	IP.01 Personal Investigador	1	new through import_export	18	1
76	2021-05-03 14:06:50.101723+00	332	IP.02 Investigaciones realizadas	1	new through import_export	18	1
77	2021-05-03 14:06:50.116823+00	333	IP.03 Investigaciones en proceso	1	new through import_export	18	1
78	2021-05-03 14:06:50.135837+00	334	IP.04 Publicaciones realizadas	1	new through import_export	18	1
79	2021-05-03 14:06:50.154752+00	335	IP.05 Publicaciones en proceso	1	new through import_export	18	1
80	2021-05-03 14:06:50.173825+00	336	ERS.01 Programas de extensión	1	new through import_export	18	1
81	2021-05-03 14:06:50.194215+00	337	ERS.02 Actividades de extensión	1	new through import_export	18	1
82	2021-05-03 14:06:50.217215+00	338	ERS.03 Proyectos de responsabilidad social universitaria	1	new through import_export	18	1
83	2021-05-03 14:06:50.24055+00	339	ERS.04 Actividades de responsabilidad social	1	new through import_export	18	1
84	2021-05-03 14:06:50.260257+00	340	RS.01 Redes sociales en que incursiona la UAPA	1	new through import_export	18	1
85	2021-05-03 14:06:50.28187+00	341	RS.02 Tipo de información que se difunde en las redes	1	new through import_export	18	1
86	2021-05-03 14:06:50.304197+00	342	RS.03 Comentarios de los usuarios de las redes sobre institución	1	new through import_export	18	1
87	2021-05-03 14:06:50.325121+00	343	RS.04 Periodicidad en el uso de las redes	1	new through import_export	18	1
88	2021-05-03 14:06:50.34794+00	344	RS.05 Cantidad de seguidores en las redes sociales	1	new through import_export	18	1
89	2021-05-03 14:06:50.37229+00	345	RS.06 Influencia en las redes	1	new through import_export	18	1
90	2021-05-03 14:06:50.394645+00	346	RS.07 Posición de la institución respecto a la competencia	1	new through import_export	18	1
91	2021-05-03 14:06:50.412735+00	347	IL.01 Tasa de inserción laboral	1	new through import_export	18	1
92	2021-05-03 14:06:50.438296+00	348	IL.02 Tasa de egresados que han trabajado alguna vez	1	new through import_export	18	1
93	2021-05-03 14:06:50.452344+00	349	IL.03 Satisfacción de los empleadores con egresados UAPA	1	new through import_export	18	1
94	2021-05-03 14:06:50.467709+00	350	PU.01 Edificaciones	1	new through import_export	18	1
95	2021-05-03 14:06:50.483981+00	351	PU.02 Inventario de equipos y materiales	1	new through import_export	18	1
96	2021-05-03 14:06:50.499537+00	352	PU.03 Infraestructura tecnológica	1	new through import_export	18	1
97	2021-05-03 14:06:50.516526+00	353	EC.01 Distribución de oferta técnica según área de conocimiento	1	new through import_export	18	1
98	2021-05-03 14:06:50.530604+00	354	EC.02 Distribución de la oferta técnica por tipo, según rama de educación continua	1	new through import_export	18	1
99	2021-05-03 14:06:50.54572+00	355	EC.03 Cantidad de estudiantes egresado en habilitación docente y otros tipo de oferta técnica	1	new through import_export	18	1
100	2021-05-03 14:06:50.56363+00	356	EC.04 Costo promedio de educación continua	1	new through import_export	18	1
101	2021-05-03 14:08:41.829758+00	24735	Santiago (sede)-Agrimensura	1	new through import_export	21	1
102	2021-05-03 14:08:41.845823+00	24732	Santo Domingo Oriental-Agrimensura	1	new through import_export	21	1
103	2021-05-03 14:08:41.859636+00	24730	Cibao Oriental (Nagua)-Agrimensura	1	new through import_export	21	1
104	2021-05-03 14:08:41.87357+00	3371	Santiago (sede)-Derecho	1	new through import_export	21	1
105	2021-05-03 14:08:41.887862+00	3366	Santo Domingo Oriental-Derecho	1	new through import_export	21	1
106	2021-05-03 14:08:41.901346+00	3362	Cibao Oriental (Nagua)-Derecho	1	new through import_export	21	1
107	2021-05-03 14:08:41.914647+00	459	Santiago (sede)-Ciencias de la Educación (Dr.)	1	new through import_export	21	1
108	2021-05-03 14:08:41.927608+00	458	Santo Domingo Oriental-Ciencias de la Educación (Dr.)	1	new through import_export	21	1
109	2021-05-03 14:08:41.941122+00	457	Cibao Oriental (Nagua)-Ciencias de la Educación (Dr.)	1	new through import_export	21	1
110	2021-05-03 14:08:41.955148+00	456	Santiago (sede)-Ciberseguridad	1	new through import_export	21	1
111	2021-05-03 14:08:41.970106+00	455	Santo Domingo Oriental-Ciberseguridad	1	new through import_export	21	1
112	2021-05-03 14:08:41.985919+00	454	Cibao Oriental (Nagua)-Ciberseguridad	1	new through import_export	21	1
113	2021-05-03 14:08:42.002627+00	453	Santiago (sede)-Dirección y Gestión Tributaria	1	new through import_export	21	1
114	2021-05-03 14:08:42.023897+00	452	Santo Domingo Oriental-Dirección y Gestión Tributaria	1	new through import_export	21	1
115	2021-05-03 14:08:42.051394+00	451	Cibao Oriental (Nagua)-Dirección y Gestión Tributaria	1	new through import_export	21	1
116	2021-05-03 14:08:42.072157+00	450	Santiago (sede)- Innovación y Gestión Empresarial	1	new through import_export	21	1
117	2021-05-03 14:08:42.090206+00	449	Santo Domingo Oriental- Innovación y Gestión Empresarial	1	new through import_export	21	1
118	2021-05-03 14:08:42.108738+00	448	Cibao Oriental (Nagua)- Innovación y Gestión Empresarial	1	new through import_export	21	1
120	2021-05-03 14:08:42.141739+00	446	Santo Domingo Oriental-Maestría en Terapia Familiar	1	new through import_export	21	1
121	2021-05-03 14:08:42.157705+00	445	Cibao Oriental (Nagua)-Maestría en Terapia Familiar	1	new through import_export	21	1
122	2021-05-03 14:08:42.173736+00	444	Santiago (sede)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
123	2021-05-03 14:08:42.191161+00	443	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
124	2021-05-03 14:08:42.206513+00	442	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
125	2021-05-03 14:08:42.223191+00	441	Santiago (sede)-Derecho Constitucional	1	new through import_export	21	1
126	2021-05-03 14:08:42.240101+00	440	Santo Domingo Oriental-Derecho Constitucional	1	new through import_export	21	1
127	2021-05-03 14:08:42.259172+00	439	Cibao Oriental (Nagua)-Derecho Constitucional	1	new through import_export	21	1
128	2021-05-03 14:08:42.278257+00	438	Santiago (sede)-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
129	2021-05-03 14:08:42.299621+00	437	Santo Domingo Oriental-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
130	2021-05-03 14:08:42.3218+00	436	Cibao Oriental (Nagua)-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
131	2021-05-03 14:08:42.343183+00	435	Santiago (sede)-Gestión de la Tecnología Educativa 	1	new through import_export	21	1
132	2021-05-03 14:08:42.369255+00	434	Santo Domingo Oriental-Gestión de la Tecnología Educativa 	1	new through import_export	21	1
133	2021-05-03 14:08:42.394982+00	433	Cibao Oriental (Nagua)-Gestión de la Tecnología Educativa 	1	new through import_export	21	1
134	2021-05-03 14:08:42.421463+00	432	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos	1	new through import_export	21	1
135	2021-05-03 14:08:42.446467+00	431	Santo Domingo Oriental-Derecho Penal y Procesal Penal Contemporáneos	1	new through import_export	21	1
136	2021-05-03 14:08:42.470363+00	430	Cibao Oriental (Nagua)-Derecho Penal y Procesal Penal Contemporáneos	1	new through import_export	21	1
137	2021-05-03 14:08:42.491055+00	429	Santiago (sede)-Legislación de Tierras 	1	new through import_export	21	1
138	2021-05-03 14:08:42.509707+00	428	Santo Domingo Oriental-Legislación de Tierras 	1	new through import_export	21	1
139	2021-05-03 14:08:42.524746+00	427	Cibao Oriental (Nagua)-Legislación de Tierras 	1	new through import_export	21	1
140	2021-05-03 14:08:42.538461+00	426	Santiago (sede)-Dirección Financiera 	1	new through import_export	21	1
141	2021-05-03 14:08:42.55153+00	425	Santo Domingo Oriental-Dirección Financiera 	1	new through import_export	21	1
142	2021-05-03 14:08:42.565508+00	424	Cibao Oriental (Nagua)-Dirección Financiera 	1	new through import_export	21	1
143	2021-05-03 14:08:42.583974+00	423	Santiago (sede)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
144	2021-05-03 14:08:42.600702+00	422	Santo Domingo Oriental-Gerencia de Recursos Humanos 	1	new through import_export	21	1
145	2021-05-03 14:08:42.61923+00	421	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
146	2021-05-03 14:08:42.63826+00	420	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos	1	new through import_export	21	1
147	2021-05-03 14:08:42.65598+00	419	Santo Domingo Oriental-Derecho Civil y Procesal Civil Contemporáneos	1	new through import_export	21	1
148	2021-05-03 14:08:42.67314+00	418	Cibao Oriental (Nagua)-Derecho Civil y Procesal Civil Contemporáneos	1	new through import_export	21	1
149	2021-05-03 14:08:42.689588+00	417	Santiago (sede)-Psicología Clínica 	1	new through import_export	21	1
150	2021-05-03 14:08:42.704437+00	416	Santo Domingo Oriental-Psicología Clínica 	1	new through import_export	21	1
151	2021-05-03 14:08:42.718138+00	415	Cibao Oriental (Nagua)-Psicología Clínica 	1	new through import_export	21	1
152	2021-05-03 14:08:42.731472+00	414	Santiago (sede)-Educación Inicial 	1	new through import_export	21	1
153	2021-05-03 14:08:42.74532+00	413	Santo Domingo Oriental-Educación Inicial 	1	new through import_export	21	1
154	2021-05-03 14:08:42.759194+00	412	Cibao Oriental (Nagua)-Educación Inicial 	1	new through import_export	21	1
155	2021-05-03 14:08:42.773681+00	411	Santiago (sede)-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
156	2021-05-03 14:08:42.789312+00	410	Santo Domingo Oriental-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
157	2021-05-03 14:08:42.814667+00	409	Cibao Oriental (Nagua)-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
158	2021-05-03 14:08:42.834086+00	408	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo	1	new through import_export	21	1
159	2021-05-03 14:08:42.853137+00	407	Santo Domingo Oriental-Mercadeo, mencion Gerencia de mercadeo	1	new through import_export	21	1
160	2021-05-03 14:08:42.875207+00	406	Cibao Oriental (Nagua)-Mercadeo, mencion Gerencia de mercadeo	1	new through import_export	21	1
161	2021-05-03 14:08:42.896086+00	405	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	1	new through import_export	21	1
162	2021-05-03 14:08:42.915966+00	404	Santo Domingo Oriental-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	1	new through import_export	21	1
163	2021-05-03 14:08:42.936322+00	403	Cibao Oriental (Nagua)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	1	new through import_export	21	1
164	2021-05-03 14:08:42.957749+00	402	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	1	new through import_export	21	1
165	2021-05-03 14:08:42.977617+00	401	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	1	new through import_export	21	1
166	2021-05-03 14:08:42.997743+00	400	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	1	new through import_export	21	1
167	2021-05-03 14:08:43.017002+00	399	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
168	2021-05-03 14:08:43.03088+00	398	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
169	2021-05-03 14:08:43.043668+00	397	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
170	2021-05-03 14:08:43.057233+00	396	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
171	2021-05-03 14:08:43.070542+00	395	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
172	2021-05-03 14:08:43.08613+00	394	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
173	2021-05-03 14:08:43.1001+00	393	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
174	2021-05-03 14:08:43.114437+00	392	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
175	2021-05-03 14:08:43.129612+00	391	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
176	2021-05-03 14:08:43.149436+00	390	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
177	2021-05-03 14:08:43.170704+00	389	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
178	2021-05-03 14:08:43.189705+00	388	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
179	2021-05-03 14:08:43.207914+00	387	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	1	new through import_export	21	1
180	2021-05-03 14:08:43.225135+00	386	Santo Domingo Oriental-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	1	new through import_export	21	1
181	2021-05-03 14:08:43.245576+00	385	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	1	new through import_export	21	1
182	2021-05-03 14:08:43.271178+00	384	Santiago (sede)-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
183	2021-05-03 14:08:43.295775+00	383	Santo Domingo Oriental-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
184	2021-05-03 14:08:43.32465+00	382	Cibao Oriental (Nagua)-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
185	2021-05-03 14:08:43.354255+00	381	Santiago (sede)-Matemática, con Orientación a la Enseñanza 	1	new through import_export	21	1
186	2021-05-03 14:08:43.380353+00	380	Santo Domingo Oriental-Matemática, con Orientación a la Enseñanza 	1	new through import_export	21	1
187	2021-05-03 14:08:43.403461+00	379	Cibao Oriental (Nagua)-Matemática, con Orientación a la Enseñanza 	1	new through import_export	21	1
188	2021-05-03 14:08:43.423767+00	378	Santiago (sede)-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
189	2021-05-03 14:08:43.441735+00	377	Santo Domingo Oriental-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
190	2021-05-03 14:08:43.461026+00	376	Cibao Oriental (Nagua)-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
191	2021-05-03 14:08:43.482151+00	375	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza 	1	new through import_export	21	1
192	2021-05-03 14:08:43.501267+00	374	Santo Domingo Oriental-Lengua Española y Literatura, con Orientación a la Enseñanza 	1	new through import_export	21	1
193	2021-05-03 14:08:43.520771+00	373	Cibao Oriental (Nagua)-Lengua Española y Literatura, con Orientación a la Enseñanza 	1	new through import_export	21	1
194	2021-05-03 14:08:43.539313+00	372	Santiago (sede)-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
195	2021-05-03 14:08:43.557448+00	371	Santo Domingo Oriental-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
196	2021-05-03 14:08:43.577372+00	370	Cibao Oriental (Nagua)-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
197	2021-05-03 14:08:43.600033+00	369	Santiago (sede)-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
198	2021-05-03 14:08:43.619676+00	368	Santo Domingo Oriental-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
199	2021-05-03 14:08:43.640768+00	367	Cibao Oriental (Nagua)-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
200	2021-05-03 14:08:43.659551+00	366	Santiago (sede)-Informática, con Orientación a la Enseñanza 	1	new through import_export	21	1
201	2021-05-03 14:08:43.680038+00	365	Santo Domingo Oriental-Informática, con Orientación a la Enseñanza 	1	new through import_export	21	1
202	2021-05-03 14:08:43.70289+00	364	Cibao Oriental (Nagua)-Informática, con Orientación a la Enseñanza 	1	new through import_export	21	1
203	2021-05-03 14:08:43.72426+00	363	Santiago (sede)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
204	2021-05-03 14:08:43.744643+00	362	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
205	2021-05-03 14:08:43.767073+00	361	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
206	2021-05-03 14:08:43.784989+00	360	Santiago (sede)-Gestión de Centros Educativos 	1	new through import_export	21	1
207	2021-05-03 14:08:43.80212+00	359	Santo Domingo Oriental-Gestión de Centros Educativos 	1	new through import_export	21	1
208	2021-05-03 14:08:43.818257+00	358	Cibao Oriental (Nagua)-Gestión de Centros Educativos 	1	new through import_export	21	1
209	2021-05-03 14:08:43.832708+00	357	Santiago (sede)-Mercadeo 	1	new through import_export	21	1
210	2021-05-03 14:08:43.847842+00	356	Santo Domingo Oriental-Mercadeo 	1	new through import_export	21	1
211	2021-05-03 14:08:43.862445+00	355	Cibao Oriental (Nagua)-Mercadeo 	1	new through import_export	21	1
212	2021-05-03 14:08:43.87677+00	354	Santiago (sede)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
213	2021-05-03 14:08:43.89258+00	353	Santo Domingo Oriental-Gerencia de Recursos Humanos 	1	new through import_export	21	1
214	2021-05-03 14:08:43.908009+00	352	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
215	2021-05-03 14:08:43.923693+00	243	Santiago (sede)-Periodismo digital	1	new through import_export	21	1
216	2021-05-03 14:08:43.940267+00	242	Santo Domingo Oriental-Periodismo digital	1	new through import_export	21	1
217	2021-05-03 14:08:43.958122+00	241	Cibao Oriental (Nagua)-Periodismo digital	1	new through import_export	21	1
218	2021-05-03 14:08:43.976271+00	240	Santiago (sede)-Psicología Industrial 	1	new through import_export	21	1
219	2021-05-03 14:08:43.999336+00	239	Santo Domingo Oriental-Psicología Industrial 	1	new through import_export	21	1
220	2021-05-03 14:08:44.032582+00	238	Cibao Oriental (Nagua)-Psicología Industrial 	1	new through import_export	21	1
221	2021-05-03 14:08:44.0594+00	237	Santiago (sede)-Psicología 	1	new through import_export	21	1
222	2021-05-03 14:08:44.087796+00	236	Santo Domingo Oriental-Psicología 	1	new through import_export	21	1
223	2021-05-03 14:08:44.122595+00	235	Cibao Oriental (Nagua)-Psicología 	1	new through import_export	21	1
224	2021-05-03 14:08:44.148223+00	234	Santiago (sede)-Psicología Educativa 	1	new through import_export	21	1
225	2021-05-03 14:08:44.178421+00	233	Santo Domingo Oriental-Psicología Educativa 	1	new through import_export	21	1
226	2021-05-03 14:08:44.20563+00	232	Cibao Oriental (Nagua)-Psicología Educativa 	1	new through import_export	21	1
227	2021-05-03 14:08:44.230413+00	231	Santiago (sede)-Psicología Clínica 	1	new through import_export	21	1
228	2021-05-03 14:08:44.257412+00	230	Santo Domingo Oriental-Psicología Clínica 	1	new through import_export	21	1
229	2021-05-03 14:08:44.277018+00	229	Cibao Oriental (Nagua)-Psicología Clínica 	1	new through import_export	21	1
230	2021-05-03 14:08:44.294426+00	228	Santiago (sede)-Administración de Empresas Turísticas 	1	new through import_export	21	1
231	2021-05-03 14:08:44.310953+00	227	Santo Domingo Oriental-Administración de Empresas Turísticas 	1	new through import_export	21	1
232	2021-05-03 14:08:44.326366+00	226	Cibao Oriental (Nagua)-Administración de Empresas Turísticas 	1	new through import_export	21	1
233	2021-05-03 14:08:44.341526+00	225	Santiago (sede)-Mercadeo 	1	new through import_export	21	1
234	2021-05-03 14:08:44.356616+00	224	Santo Domingo Oriental-Mercadeo 	1	new through import_export	21	1
235	2021-05-03 14:08:44.37114+00	223	Cibao Oriental (Nagua)-Mercadeo 	1	new through import_export	21	1
236	2021-05-03 14:08:44.386214+00	222	Santiago (sede)-Contabilidad Empresarial 	1	new through import_export	21	1
237	2021-05-03 14:08:44.402658+00	221	Santo Domingo Oriental-Contabilidad Empresarial 	1	new through import_export	21	1
238	2021-05-03 14:08:44.417211+00	220	Cibao Oriental (Nagua)-Contabilidad Empresarial 	1	new through import_export	21	1
239	2021-05-03 14:08:44.432781+00	219	Santiago (sede)-Administración de Empresas 	1	new through import_export	21	1
240	2021-05-03 14:08:44.448659+00	218	Santo Domingo Oriental-Administración de Empresas 	1	new through import_export	21	1
241	2021-05-03 14:08:44.465523+00	217	Cibao Oriental (Nagua)-Administración de Empresas 	1	new through import_export	21	1
242	2021-05-03 14:08:44.48256+00	216	Santiago (sede)-Lenguas Modernas Mención Turismo 	1	new through import_export	21	1
243	2021-05-03 14:08:44.499759+00	215	Santo Domingo Oriental-Lenguas Modernas Mención Turismo 	1	new through import_export	21	1
244	2021-05-03 14:08:44.51687+00	214	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo 	1	new through import_export	21	1
245	2021-05-03 14:08:44.533173+00	213	Santiago (sede)-Ingeniería en Software 	1	new through import_export	21	1
246	2021-05-03 14:08:44.549272+00	212	Santo Domingo Oriental-Ingeniería en Software 	1	new through import_export	21	1
247	2021-05-03 14:08:44.565231+00	211	Cibao Oriental (Nagua)-Ingeniería en Software 	1	new through import_export	21	1
248	2021-05-03 14:08:44.581198+00	210	Santiago (sede)-Informática Gerencial 	1	new through import_export	21	1
249	2021-05-03 14:08:44.596302+00	209	Santo Domingo Oriental-Informática Gerencial 	1	new through import_export	21	1
250	2021-05-03 14:08:44.609806+00	208	Cibao Oriental (Nagua)-Informática Gerencial 	1	new through import_export	21	1
251	2021-05-03 14:08:44.623976+00	207	Santiago (sede)-Educación Inicial	1	new through import_export	21	1
252	2021-05-03 14:08:44.638264+00	206	Santo Domingo Oriental-Educación Inicial	1	new through import_export	21	1
253	2021-05-03 14:08:44.651459+00	205	Cibao Oriental (Nagua)-Educación Inicial	1	new through import_export	21	1
254	2021-05-03 14:08:44.664875+00	204	Santiago (sede)-Educacion Primaria, Primer Ciclo	1	new through import_export	21	1
255	2021-05-03 14:08:44.677947+00	203	Santo Domingo Oriental-Educacion Primaria, Primer Ciclo	1	new through import_export	21	1
256	2021-05-03 14:08:44.69099+00	202	Cibao Oriental (Nagua)-Educacion Primaria, Primer Ciclo	1	new through import_export	21	1
257	2021-05-03 14:08:44.704434+00	201	Santiago (sede)-Ingles Orientado a la Educacion	1	new through import_export	21	1
258	2021-05-03 14:08:44.717563+00	200	Santo Domingo Oriental-Ingles Orientado a la Educacion	1	new through import_export	21	1
259	2021-05-03 14:08:44.730909+00	199	Cibao Oriental (Nagua)-Ingles Orientado a la Educacion	1	new through import_export	21	1
260	2021-05-03 14:08:44.746041+00	198	Santiago (sede)-Ciencias Sociales Orienada a la Educacion Secundaria	1	new through import_export	21	1
261	2021-05-03 14:08:44.759353+00	197	Santo Domingo Oriental-Ciencias Sociales Orienada a la Educacion Secundaria	1	new through import_export	21	1
262	2021-05-03 14:08:44.772925+00	196	Cibao Oriental (Nagua)-Ciencias Sociales Orienada a la Educacion Secundaria	1	new through import_export	21	1
263	2021-05-03 14:08:44.789653+00	195	Santiago (sede)-Matematica  Orientada a la Educacion Secundaria	1	new through import_export	21	1
264	2021-05-03 14:08:44.803373+00	194	Santo Domingo Oriental-Matematica  Orientada a la Educacion Secundaria	1	new through import_export	21	1
265	2021-05-03 14:08:44.816879+00	193	Cibao Oriental (Nagua)-Matematica  Orientada a la Educacion Secundaria	1	new through import_export	21	1
266	2021-05-03 14:08:44.830582+00	192	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria	1	new through import_export	21	1
267	2021-05-03 14:08:44.844914+00	191	Santo Domingo Oriental-Lengua Española y Literatura Orientada a la Educacion Secundaria	1	new through import_export	21	1
268	2021-05-03 14:08:44.85998+00	190	Cibao Oriental (Nagua)-Lengua Española y Literatura Orientada a la Educacion Secundaria	1	new through import_export	21	1
269	2021-05-03 14:08:44.875573+00	189	Santiago (sede)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	1	new through import_export	21	1
270	2021-05-03 14:08:44.89054+00	188	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	1	new through import_export	21	1
271	2021-05-03 14:08:44.904222+00	187	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	1	new through import_export	21	1
272	2021-05-03 14:08:44.917948+00	186	Santiago (sede)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	1	new through import_export	21	1
273	2021-05-03 14:08:44.931933+00	185	Santo Domingo Oriental-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	1	new through import_export	21	1
274	2021-05-03 14:08:44.946338+00	184	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	1	new through import_export	21	1
275	2021-05-03 14:08:44.959849+00	183	Santiago (sede)-Ciencia de la Educación, Mención Ciencias Sociales 	1	new through import_export	21	1
276	2021-05-03 14:08:44.973723+00	182	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias Sociales 	1	new through import_export	21	1
277	2021-05-03 14:08:44.987146+00	181	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias Sociales 	1	new through import_export	21	1
278	2021-05-03 14:08:45.000557+00	180	Santiago (sede)-Ciencia de la Educación, Mención Matemática Física 	1	new through import_export	21	1
279	2021-05-03 14:08:45.01456+00	179	Santo Domingo Oriental-Ciencia de la Educación, Mención Matemática Física 	1	new through import_export	21	1
280	2021-05-03 14:08:45.027932+00	178	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Matemática Física 	1	new through import_export	21	1
281	2021-05-03 14:08:45.041517+00	177	Santiago (sede)-Ciencia de la Educación, Mención Lengua Española 	1	new through import_export	21	1
282	2021-05-03 14:08:45.05548+00	176	Santo Domingo Oriental-Ciencia de la Educación, Mención Lengua Española 	1	new through import_export	21	1
283	2021-05-03 14:08:45.069418+00	175	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Lengua Española 	1	new through import_export	21	1
284	2021-05-03 14:08:45.083253+00	174	Santiago (sede)-Ciencia de la Educación, Mención Educación Inicial 	1	new through import_export	21	1
285	2021-05-03 14:08:45.096692+00	173	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Inicial 	1	new through import_export	21	1
286	2021-05-03 14:08:45.110428+00	172	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Inicial 	1	new through import_export	21	1
287	2021-05-03 14:08:45.125446+00	171	Santiago (sede)-Ciencia de la Educación, Mención Educación Básica 	1	new through import_export	21	1
288	2021-05-03 14:08:45.140639+00	170	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Básica 	1	new through import_export	21	1
289	2021-05-03 14:08:45.155414+00	169	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Básica 	1	new through import_export	21	1
290	2021-05-03 14:08:45.169966+00	168	Santiago (sede)-Derecho	1	new through import_export	21	1
291	2021-05-03 14:08:45.183802+00	167	Santo Domingo Oriental-Derecho	1	new through import_export	21	1
292	2021-05-03 14:08:45.198163+00	166	Cibao Oriental (Nagua)-Derecho	1	new through import_export	21	1
293	2021-05-03 14:08:45.213116+00	4	Ciabao Oriental (Nagua)	1	new through import_export	21	1
294	2021-05-03 14:08:45.227603+00	3	Santo Domingo Oriental	1	new through import_export	21	1
295	2021-05-03 14:08:45.243304+00	2	Santiago (sede)	1	new through import_export	21	1
296	2021-05-03 14:50:12.838748+00	1	2017-Anual	1	[{"added": {}}]	17	1
297	2021-05-03 14:52:26.279115+00	24736	Total oferta académica grado	1	[{"added": {}}]	21	1
298	2021-05-03 14:52:46.34298+00	1	Total oferta académica grado-2017-Anual-22	1	[{"added": {}}]	25	1
299	2021-05-03 15:20:19.916609+00	24737	Total oferta académica postgrado	1	[{"added": {}}]	21	1
300	2021-05-03 15:20:30.354498+00	2	Total oferta académica postgrado-2017-Anual-15	1	[{"added": {}}]	25	1
301	2021-05-03 15:25:02.003584+00	24738	Total oferta académica técnico superior	1	[{"added": {}}]	21	1
302	2021-05-03 15:25:08.806683+00	3	Total oferta académica técnico superior-2017-Anual-1	1	[{"added": {}}]	25	1
303	2021-05-03 16:00:05.911222+00	2	2018-Anual	1	[{"added": {}}]	17	1
304	2021-05-03 16:00:40.664589+00	3	2019-Anual	1	[{"added": {}}]	17	1
305	2021-05-03 16:00:47.699865+00	4	2020-Anual	1	[{"added": {}}]	17	1
306	2021-05-03 16:00:52.584602+00	5	2021-Anual	1	[{"added": {}}]	17	1
307	2021-05-03 16:07:45.724551+00	2042	Total oferta académica técnico superior-2018-Anual-21	1	new through import_export	25	1
308	2021-05-03 16:07:45.744109+00	2043	Total oferta académica postgrado-2018-Anual-13	1	new through import_export	25	1
309	2021-05-03 16:07:45.760903+00	2044	Total oferta académica grado-2018-Anual-1	1	new through import_export	25	1
310	2021-05-03 16:07:45.777309+00	2045	Total oferta académica técnico superior-2019-Anual-21	1	new through import_export	25	1
311	2021-05-03 16:07:45.79606+00	2046	Total oferta académica postgrado-2019-Anual-12	1	new through import_export	25	1
312	2021-05-03 16:07:45.816508+00	2047	Total oferta académica grado-2019-Anual-1	1	new through import_export	25	1
313	2021-05-03 16:07:45.836906+00	2048	Total oferta académica técnico superior-2020-Anual-20	1	new through import_export	25	1
314	2021-05-03 16:07:45.85931+00	2049	Total oferta académica postgrado-2020-Anual-9	1	new through import_export	25	1
315	2021-05-03 16:07:45.876929+00	2050	Total oferta académica grado-2020-Anual-1	1	new through import_export	25	1
316	2021-05-03 16:07:45.896835+00	2051	Total oferta académica técnico superior-2021-Anual-20	1	new through import_export	25	1
317	2021-05-03 16:07:45.913517+00	2052	Total oferta académica postgrado-2021-Anual-5	1	new through import_export	25	1
318	2021-05-03 16:07:45.929362+00	2053	Total oferta académica grado-2021-Anual-1	1	new through import_export	25	1
319	2021-05-03 16:11:13.605908+00	2053	Total oferta académica grado-2021-Anual-1.00	2	[]	25	1
320	2021-05-03 16:11:30.980626+00	24737	Total oferta académica postgrado	2	[]	21	1
321	2021-05-03 16:11:32.582956+00	2052	Total oferta académica postgrado-2021-Anual-5.00	2	[]	25	1
322	2021-05-03 17:48:41.758037+00	24736	Total oferta académica grado	2	[]	21	1
323	2021-05-03 17:48:48.731704+00	2050	Total oferta académica grado-2020-Anual-1	2	[]	25	1
324	2021-05-03 17:49:20.023564+00	2049	Total oferta académica postgrado-2020-Anual-9	2	[]	25	1
325	2021-05-03 17:50:02.165618+00	2049	Total oferta académica postgrado-2020-Anual-9	2	[]	25	1
326	2021-05-03 17:50:31.517783+00	24738	Total oferta académica técnico superior	2	[]	21	1
327	2021-05-03 17:50:41.005919+00	2048	Total oferta académica técnico superior-2020-Anual-20	2	[]	25	1
328	2021-05-03 19:37:43.073801+00	24739	Santiago (sede)-Doctorado	1	[{"added": {}}]	21	1
329	2021-05-03 19:38:15.391751+00	2054	Santiago (sede)-Doctorado-2017-Anual-7	1	[{"added": {}}]	25	1
330	2021-05-03 19:39:15.084366+00	24739	Doctorado-Santiago (sede)	2	[{"changed": {"fields": ["Par\\u00e1metro", "Par\\u00e1metro opcional"]}}]	21	1
331	2021-05-03 19:39:17.79092+00	2054	Doctorado-Santiago (sede)-2017-Anual-7.00	2	[]	25	1
332	2021-05-03 19:40:44.462569+00	24740	Doctorado-Santo Domingo	1	[{"added": {}}]	21	1
333	2021-05-03 19:40:55.153713+00	2055	Doctorado-Santo Domingo-2017-Anual-1	1	[{"added": {}}]	25	1
334	2021-05-08 15:30:43.402685+00	346	RS.07 Posición de la institución respecto a la competencia	2	[{"changed": {"fields": ["Definici\\u00f3n", "Visible", "Lectura del Indicador"]}}]	18	1
335	2021-05-08 16:21:40.035071+00	24779	Desfavorables-Frecuencia porcentual (%)	1	new through import_export	21	1
336	2021-05-08 16:21:40.049432+00	24778	Neutros-Frecuencia porcentual (%)	1	new through import_export	21	1
337	2021-05-08 16:21:40.062733+00	24777	Favorables-Frecuencia porcentual (%)	1	new through import_export	21	1
338	2021-05-08 16:21:40.075013+00	24776	Desfavorables-Frecuencia absoluta	1	new through import_export	21	1
339	2021-05-08 16:21:40.08859+00	24775	Neutros-Frecuencia absoluta	1	new through import_export	21	1
340	2021-05-08 16:21:40.10118+00	24774	Favorables-Frecuencia absoluta	1	new through import_export	21	1
341	2021-05-08 16:22:52.0418+00	412	Desfavorables-Frecuencia porcentual (%)-2019-Anual-6.8	1	new through import_export	25	1
342	2021-05-08 16:22:52.055206+00	411	Desfavorables-Frecuencia absoluta-2019-Anual-179	1	new through import_export	25	1
343	2021-05-08 16:22:52.068656+00	410	Neutros-Frecuencia absoluta-2019-Anual-2339	1	new through import_export	25	1
344	2021-05-08 16:22:52.083229+00	409	Favorables-Frecuencia porcentual (%)-2019-Anual-4.36	1	new through import_export	25	1
345	2021-05-08 16:22:52.096826+00	408	Favorables-Frecuencia absoluta-2019-Anual-115	1	new through import_export	25	1
346	2021-05-08 16:22:52.117368+00	402	Desfavorables-Frecuencia porcentual (%)-2017-Anual-2.06	1	new through import_export	25	1
347	2021-05-08 16:22:52.131118+00	401	Desfavorables-Frecuencia absoluta-2017-Anual-78	1	new through import_export	25	1
348	2021-05-08 16:22:52.144597+00	400	Neutros-Frecuencia absoluta-2017-Anual-3439	1	new through import_export	25	1
349	2021-05-08 16:22:52.158394+00	396	Favorables-Frecuencia porcentual (%)-2017-Anual-6.93	1	new through import_export	25	1
350	2021-05-08 16:22:52.172731+00	395	Favorables-Frecuencia absoluta-2017-Anual-262	1	new through import_export	25	1
351	2021-05-10 14:28:04.522619+00	4	Ciabao Oriental (Nagua)	2	update through import_export	21	1
352	2021-05-10 14:28:04.538225+00	3	Santo Domingo Oriental	2	update through import_export	21	1
353	2021-05-10 14:28:04.552265+00	2	Santiago (sede)	2	update through import_export	21	1
354	2021-05-10 14:29:25.511911+00	363	Ciabao Oriental (Nagua)-2019-Anual-76.00	1	new through import_export	25	1
355	2021-05-10 14:29:25.525821+00	362	Santo Domingo Oriental-2019-Anual-80.00	1	new through import_export	25	1
356	2021-05-10 14:29:25.538887+00	361	Santiago (sede)-2019-Anual-123.00	1	new through import_export	25	1
357	2021-05-10 14:29:25.551758+00	360	Ciabao Oriental (Nagua)-2018-Anual-76.00	1	new through import_export	25	1
358	2021-05-10 14:29:25.564079+00	359	Santo Domingo Oriental-2018-Anual-80.00	1	new through import_export	25	1
359	2021-05-10 14:29:25.576638+00	358	Santiago (sede)-2018-Anual-123.00	1	new through import_export	25	1
360	2021-05-10 14:29:25.590004+00	357	Ciabao Oriental (Nagua)-2017-Anual-81.00	1	new through import_export	25	1
361	2021-05-10 14:29:25.602745+00	356	Santo Domingo Oriental-2017-Anual-80.00	1	new through import_export	25	1
362	2021-05-10 14:29:25.615505+00	355	Santiago (sede)-2017-Anual-117.00	1	new through import_export	25	1
363	2021-05-11 15:50:32.679128+00	2055	Doctorado-Santo Domingo-2017-Anual-1.00	3		25	1
364	2021-05-11 15:50:32.702339+00	2054	Doctorado-Santiago (sede)-2017-Anual-7.00	3		25	1
365	2021-05-11 15:53:55.642371+00	24740	Doctorado-Santo Domingo	3		21	1
366	2021-05-11 15:53:55.657171+00	24739	Doctorado-Santiago (sede)	3		21	1
367	2021-05-11 15:54:42.073234+00	24754	Especialidad / Grado / Pregrado-Nagua	1	new through import_export	21	1
368	2021-05-11 15:54:42.087173+00	24753	Especialidad / Grado / Pregrado-Santo Domingo	1	new through import_export	21	1
369	2021-05-11 15:54:42.102+00	24752	Especialidad / Grado / Pregrado-Santiago (Sede)	1	new through import_export	21	1
370	2021-05-11 15:54:42.115777+00	24751	Maestría-Nagua	1	new through import_export	21	1
371	2021-05-11 15:54:42.129953+00	24750	Maestría-Santo Domingo	1	new through import_export	21	1
372	2021-05-11 15:54:42.144739+00	24749	Maestría-Santiago (Sede)	1	new through import_export	21	1
373	2021-05-11 15:54:42.159327+00	24748	Doctorado-Nagua	1	new through import_export	21	1
374	2021-05-11 15:54:42.172825+00	24747	Doctorado-Santo Domingo	1	new through import_export	21	1
375	2021-05-11 15:54:42.186312+00	24746	Doctorado-Santiago (Sede)	1	new through import_export	21	1
376	2021-05-11 15:55:20.131801+00	24757	Investigaciones culminadas y reportadas	1	new through import_export	21	1
377	2021-05-11 15:55:20.157824+00	24756	Investigaciones aprobadas y en proceso	1	new through import_export	21	1
378	2021-05-11 15:55:20.177164+00	24755	Investigaciones presentadas	1	new through import_export	21	1
379	2021-05-11 15:56:14.922227+00	24773	Publicaciones-Artículos	1	new through import_export	21	1
380	2021-05-11 15:56:14.940681+00	24772	Publicaciones-Ponencias/Memorias de eventos científicos	1	new through import_export	21	1
381	2021-05-11 15:56:14.954215+00	24771	Publicaciones-Secciones de libros	1	new through import_export	21	1
382	2021-05-11 15:56:14.967238+00	24770	Publicaciones-Libros	1	new through import_export	21	1
383	2021-05-11 15:56:14.980297+00	24769	Originales aceptados-Artículos	1	new through import_export	21	1
384	2021-05-11 15:56:14.993267+00	24768	Originales aceptados-Ponencias/Memorias de eventos científicos	1	new through import_export	21	1
385	2021-05-11 15:56:15.006379+00	24767	Originales aceptados-Secciones de libros	1	new through import_export	21	1
386	2021-05-11 15:56:15.019224+00	24766	Originales aceptados-Libros	1	new through import_export	21	1
387	2021-05-11 15:56:15.032304+00	24765	Originales presentados para arbitrar-Artículos	1	new through import_export	21	1
388	2021-05-11 15:56:15.044827+00	24764	Originales presentados para arbitrar-Ponencias/Memorias de eventos científicos	1	new through import_export	21	1
389	2021-05-11 15:56:15.057579+00	24763	Originales presentados para arbitrar-Secciones de libros	1	new through import_export	21	1
390	2021-05-11 15:56:15.070579+00	24762	Originales presentados para arbitrar-Libros	1	new through import_export	21	1
391	2021-05-11 15:56:53.789523+00	24761	Memorias o publicaciones producto de eventos científicos	1	new through import_export	21	1
392	2021-05-11 15:56:53.802526+00	24760	Congresos, simposios (llamados abiertos)	1	new through import_export	21	1
393	2021-05-11 15:56:53.815338+00	24759	Artículos (Revistas UAPA)	1	new through import_export	21	1
394	2021-05-11 15:56:53.827711+00	24758	Libros, colecciones, diccionarios	1	new through import_export	21	1
395	2021-05-17 15:00:16.933649+00	406	AT=100-(TP+TR)	1	new through import_export	15	1
396	2021-05-17 15:00:16.948864+00	380	CDE= (A/A+B)	1	new through import_export	15	1
397	2021-05-17 15:00:16.96182+00	463	CPEC= &sum;Cect/CT	1	new through import_export	15	1
398	2021-05-17 15:00:16.974661+00	411	Dm= &Sigma;AEsG/GrT	1	new through import_export	15	1
399	2021-05-17 15:00:16.987695+00	412	Dm= &Sigma;NG/GrT	1	new through import_export	15	1
400	2021-05-17 15:00:17.001047+00	396	%EG=(EGG/TEG)*100\n%EG=(EGP/TEG)*100	1	new through import_export	15	1
401	2021-05-17 15:00:17.014174+00	460	EMC= ECE/n	1	new through import_export	15	1
402	2021-05-17 15:00:17.027265+00	436	%EmNE=(EmNEi / TEm)*100	1	new through import_export	15	1
403	2021-05-17 15:00:17.040113+00	461	EmToR= EmToR/n	1	new through import_export	15	1
404	2021-05-17 15:00:17.052781+00	391	%ENC=ENC/ENT	1	new through import_export	15	1
405	2021-05-17 15:00:17.065396+00	393	%ENN= ENN/ENT	1	new through import_export	15	1
406	2021-05-17 15:00:17.078198+00	390	%ENR= ENR/ENT	1	new through import_export	15	1
407	2021-05-17 15:00:17.090693+00	397	%ERG=(ERG/TERGR)*100\n%ERPg=(ERPg/TERPgR)*100	1	new through import_export	15	1
408	2021-05-17 15:00:17.103339+00	427	%ES= &Sigma;ES/TEE	1	new through import_export	15	1
409	2021-05-17 15:00:17.117201+00	379	GPEPIB= (GPEi/PIBi) x 100	1	new through import_export	15	1
410	2021-05-17 15:00:17.130186+00	394	Indicador estimado por el MESCyT	1	new through import_export	15	1
411	2021-05-17 15:00:17.143416+00	383	IPG= TBMf/ TBMm	1	new through import_export	15	1
412	2021-05-17 15:00:17.156037+00	452	IR=&sum;NSG/CS	1	new through import_export	15	1
413	2021-05-17 15:00:17.174449+00	431	%Nepd= Nei/Tpd	1	new through import_export	15	1
414	2021-05-17 15:00:17.187194+00	378	Nt+a = Nt + Bt,t+a - Dt,t+a +Mt,t+a	1	new through import_export	15	1
415	2021-05-17 15:00:17.200285+00	446	%PAcrst=PAcrsI/TPAcrs	1	new through import_export	15	1
416	2021-05-17 15:00:17.213272+00	434	%PASmt=(TPASmt/PAS)*100	1	new through import_export	15	1
417	2021-05-17 15:00:17.226097+00	433	%PAStc=(TPAStc/PAS)*100	1	new through import_export	15	1
418	2021-05-17 15:00:17.239139+00	432	PDF=&Sigma;TPDF	1	new through import_export	15	1
419	2021-05-17 15:00:17.252363+00	430	%PDmt=(TPDmt/TPD)*100	1	new through import_export	15	1
420	2021-05-17 15:00:17.265318+00	428	%PDph=(TPDph/TPD)*100	1	new through import_export	15	1
421	2021-05-17 15:00:17.27843+00	429	%PDtc=(TPDtc/TPD)*100	1	new through import_export	15	1
422	2021-05-17 15:00:17.291045+00	456	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
423	2021-05-17 15:00:17.304017+00	424	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
424	2021-05-17 15:00:17.317202+00	423	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
425	2021-05-17 15:00:17.330934+00	422	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
426	2021-05-17 15:00:17.351817+00	421	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
427	2021-05-17 15:00:17.372148+00	420	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
428	2021-05-17 15:00:17.39095+00	419	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
429	2021-05-17 15:00:17.408828+00	418	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
430	2021-05-17 15:00:17.427008+00	417	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
431	2021-05-17 15:00:17.445286+00	416	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
432	2021-05-17 15:00:17.463431+00	415	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
433	2021-05-17 15:00:17.481488+00	414	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
434	2021-05-17 15:00:17.49903+00	413	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
435	2021-05-17 15:00:17.51745+00	402	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
436	2021-05-17 15:00:17.534879+00	399	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
437	2021-05-17 15:00:17.553498+00	392	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
438	2021-05-17 15:00:17.573746+00	389	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
439	2021-05-17 15:00:17.593469+00	388	Pendiente de Informaci&oacute;n	1	new through import_export	15	1
440	2021-05-17 15:00:17.607005+00	404	PERP=ERP/TET	1	new through import_export	15	1
441	2021-05-17 15:00:17.619579+00	403	PET=ETu/TET	1	new through import_export	15	1
442	2021-05-17 15:00:17.632255+00	405	PETP=ETP/TEE	1	new through import_export	15	1
443	2021-05-17 15:00:17.645166+00	450	PURF=&sum;TI/CI	1	new through import_export	15	1
444	2021-05-17 15:00:17.658112+00	435	RPAS/Pdocente	1	new through import_export	15	1
445	2021-05-17 15:00:17.670529+00	400	RPA= TA/TP	1	new through import_export	15	1
446	2021-05-17 15:00:17.68337+00	426	%SEgpe= &Sigma;ESgpe/TEE	1	new through import_export	15	1
447	2021-05-17 15:00:17.696031+00	425	%SEgpe= &Sigma;ESgpe/TEE	1	new through import_export	15	1
448	2021-05-17 15:00:17.708687+00	444	TAcPex=&sum;AcPex	1	new through import_export	15	1
449	2021-05-17 15:00:17.721547+00	381	TA= (TAA15+/PT15+) x 100	1	new through import_export	15	1
450	2021-05-17 15:00:17.734091+00	382	TBM= TNS18-24 / TNS	1	new through import_export	15	1
451	2021-05-17 15:00:17.747172+00	449	TCPurs=&sum;CPurs	1	new through import_export	15	1
452	2021-05-17 15:00:17.759745+00	462	TEED= &sum;EED	1	new through import_export	15	1
453	2021-05-17 15:00:17.772167+00	455	TEEx= EGEA/ET	1	new through import_export	15	1
454	2021-05-17 15:00:17.784226+00	395	TEM= &sum;TEMi	1	new through import_export	15	1
455	2021-05-17 15:00:17.796989+00	437	TEnivYco= &sum;ENivyCO	1	new through import_export	15	1
456	2021-05-17 15:00:17.809734+00	401	TER= &sum;TERi	1	new through import_export	15	1
457	2021-05-17 15:00:17.822287+00	458	TEq= &sum;Eq	1	new through import_export	15	1
458	2021-05-17 15:00:17.834929+00	410	TET= (AETR/TAE)*100	1	new through import_export	15	1
459	2021-05-17 15:00:17.84766+00	408	Tex= CSA/CPA	1	new through import_export	15	1
460	2021-05-17 15:00:17.862598+00	409	TG= (GT/GE)*100	1	new through import_export	15	1
461	2021-05-17 15:00:17.875946+00	377	TIA= [(IPCf- IPCi) / IPCi] x 100	1	new through import_export	15	1
462	2021-05-17 15:00:17.89026+00	448	TIDrs=&sum;IDrs	1	new through import_export	15	1
463	2021-05-17 15:00:17.903293+00	454	TIL= EEA/ET	1	new through import_export	15	1
464	2021-05-17 15:00:17.91741+00	440	TIP=&sum;IP	1	new through import_export	15	1
465	2021-05-17 15:00:17.930777+00	439	TIRt=&sum;IR	1	new through import_export	15	1
466	2021-05-17 15:00:17.944198+00	453	TMgt=&sum;MgRsFt	1	new through import_export	15	1
467	2021-05-17 15:00:17.956778+00	386	TOA= &sum;TOAie	1	new through import_export	15	1
468	2021-05-17 15:00:17.969328+00	387	TOA= &sum;TOAies	1	new through import_export	15	1
469	2021-05-17 15:00:17.98234+00	385	TOA= &sum;TOAie	1	new through import_export	15	1
470	2021-05-17 15:00:17.995302+00	384	TOA= &sum;TOAi	1	new through import_export	15	1
471	2021-05-17 15:00:18.008216+00	443	TPex=&sum;Pex	1	new through import_export	15	1
472	2021-05-17 15:00:18.021116+00	438	TPIt=&sum;PI	1	new through import_export	15	1
473	2021-05-17 15:00:18.033969+00	398	TPPA= &sum;TPPAi	1	new through import_export	15	1
474	2021-05-17 15:00:18.046943+00	442	TPPt=&sum;PP	1	new through import_export	15	1
475	2021-05-17 15:00:18.05965+00	445	TPrst=&sum;Prs	1	new through import_export	15	1
476	2021-05-17 15:00:18.072645+00	441	TPR=&sum;PR	1	new through import_export	15	1
477	2021-05-17 15:00:18.085363+00	407	Trend= EGT/AICT	1	new through import_export	15	1
478	2021-05-17 15:00:18.098397+00	447	TRS=&sum;RS	1	new through import_export	15	1
479	2021-05-17 15:00:18.11094+00	457	TRec= &sum;TRaa	1	new through import_export	15	1
480	2021-05-17 15:00:18.123506+00	451	TSt=&sum;S	1	new through import_export	15	1
481	2021-05-17 15:00:18.135585+00	459	TTec= &sum;Tb	1	new through import_export	15	1
482	2021-05-17 15:16:07.862523+00	24780	Coeficiente de desigualdad educativa	1	[{"added": {}}]	21	1
483	2021-05-17 15:16:28.005231+00	6	2011-Anual	1	[{"added": {}}]	17	1
484	2021-05-17 15:16:34.736912+00	2074	Coeficiente de desigualdad educativa-2011-Anual-0.338	1	[{"added": {}}]	25	1
485	2021-05-18 21:40:12.451567+00	24754	Especialidad / Grado / Pregrado-Nagua	2	update through import_export	21	1
486	2021-05-18 21:40:12.4753+00	24753	Especialidad / Grado / Pregrado-Santo Domingo	2	update through import_export	21	1
487	2021-05-18 21:40:12.494503+00	24752	Especialidad / Grado / Pregrado-Santiago (Sede)	2	update through import_export	21	1
488	2021-05-18 21:40:12.511551+00	24751	Maestría-Nagua	2	update through import_export	21	1
489	2021-05-18 21:40:12.53082+00	24750	Maestría-Santo Domingo	2	update through import_export	21	1
490	2021-05-18 21:40:12.550697+00	24749	Maestría-Santiago (Sede)	2	update through import_export	21	1
491	2021-05-18 21:40:12.569002+00	24748	Doctorado-Nagua	2	update through import_export	21	1
492	2021-05-18 21:40:12.584545+00	24747	Doctorado-Santo Domingo	2	update through import_export	21	1
493	2021-05-18 21:40:12.604774+00	24746	Doctorado-Santiago (Sede)	2	update through import_export	21	1
494	2021-05-18 21:41:17.043976+00	219	Especialidad / Grado / Pregrado-Nagua-2018-Anual-2.00	1	new through import_export	25	1
495	2021-05-18 21:41:17.058579+00	218	Maestría-Nagua-2018-Anual-4.00	1	new through import_export	25	1
496	2021-05-18 21:41:17.071488+00	217	Doctorado-Nagua-2018-Anual-3.00	1	new through import_export	25	1
497	2021-05-18 21:41:17.088516+00	216	Especialidad / Grado / Pregrado-Santo Domingo-2018-Anual-0.00	1	new through import_export	25	1
498	2021-05-18 21:41:17.115083+00	215	Maestría-Santo Domingo-2018-Anual-12.00	1	new through import_export	25	1
499	2021-05-18 21:41:17.134087+00	214	Doctorado-Santo Domingo-2018-Anual-4.00	1	new through import_export	25	1
500	2021-05-18 21:41:17.153535+00	213	Especialidad / Grado / Pregrado-Santiago (Sede)-2018-Anual-0.00	1	new through import_export	25	1
501	2021-05-18 21:41:17.173473+00	212	Maestría-Santiago (Sede)-2018-Anual-21.00	1	new through import_export	25	1
502	2021-05-18 21:41:17.193112+00	211	Doctorado-Santiago (Sede)-2018-Anual-15.00	1	new through import_export	25	1
503	2021-05-18 21:41:17.212018+00	210	Especialidad / Grado / Pregrado-Nagua-2017-Anual-2.00	1	new through import_export	25	1
504	2021-05-18 21:41:17.230872+00	209	Maestría-Nagua-2017-Anual-4.00	1	new through import_export	25	1
505	2021-05-18 21:41:17.248571+00	208	Doctorado-Nagua-2017-Anual-3.00	1	new through import_export	25	1
506	2021-05-18 21:41:17.266375+00	207	Especialidad / Grado / Pregrado-Santo Domingo-2017-Anual-0.00	1	new through import_export	25	1
507	2021-05-18 21:41:17.284821+00	206	Maestría-Santo Domingo-2017-Anual-12.00	1	new through import_export	25	1
508	2021-05-18 21:41:17.303813+00	205	Doctorado-Santo Domingo-2017-Anual-4.00	1	new through import_export	25	1
509	2021-05-18 21:41:17.322736+00	204	Especialidad / Grado / Pregrado-Santiago (Sede)-2017-Anual-0.00	1	new through import_export	25	1
510	2021-05-18 21:41:17.338943+00	203	Maestría-Santiago (Sede)-2017-Anual-13.00	1	new through import_export	25	1
511	2021-05-18 21:41:17.350802+00	202	Doctorado-Santiago (Sede)-2017-Anual-11.00	1	new through import_export	25	1
512	2021-05-18 21:41:17.363344+00	201	Especialidad / Grado / Pregrado-Nagua-2021-Anual-2.00	1	new through import_export	25	1
513	2021-05-18 21:41:17.376117+00	200	Maestría-Nagua-2021-Anual-3.00	1	new through import_export	25	1
514	2021-05-18 21:41:17.389936+00	199	Doctorado-Nagua-2021-Anual-2.00	1	new through import_export	25	1
515	2021-05-18 21:41:17.402845+00	198	Especialidad / Grado / Pregrado-Santo Domingo-2021-Anual-0.00	1	new through import_export	25	1
516	2021-05-18 21:41:17.415569+00	197	Maestría-Santo Domingo-2021-Anual-5.00	1	new through import_export	25	1
517	2021-05-18 21:41:17.428578+00	196	Doctorado-Santo Domingo-2021-Anual-4.00	1	new through import_export	25	1
518	2021-05-18 21:41:17.441621+00	195	Especialidad / Grado / Pregrado-Santiago (Sede)-2021-Anual-0.00	1	new through import_export	25	1
519	2021-05-18 21:41:17.454673+00	194	Maestría-Santiago (Sede)-2021-Anual-12.00	1	new through import_export	25	1
520	2021-05-18 21:41:17.467253+00	193	Doctorado-Santiago (Sede)-2021-Anual-8.00	1	new through import_export	25	1
521	2021-05-18 21:41:17.479898+00	192	Especialidad / Grado / Pregrado-Nagua-2020-Anual-2.00	1	new through import_export	25	1
522	2021-05-18 21:41:17.492783+00	191	Maestría-Nagua-2020-Anual-3.00	1	new through import_export	25	1
523	2021-05-18 21:41:17.507596+00	190	Doctorado-Nagua-2020-Anual-2.00	1	new through import_export	25	1
524	2021-05-18 21:41:17.520056+00	189	Especialidad / Grado / Pregrado-Santo Domingo-2020-Anual-0.00	1	new through import_export	25	1
525	2021-05-18 21:41:17.532931+00	188	Maestría-Santo Domingo-2020-Anual-5.00	1	new through import_export	25	1
526	2021-05-18 21:41:17.545713+00	187	Doctorado-Santo Domingo-2020-Anual-1.00	1	new through import_export	25	1
527	2021-05-18 21:41:17.558839+00	186	Especialidad / Grado / Pregrado-Santiago (Sede)-2020-Anual-0.00	1	new through import_export	25	1
528	2021-05-18 21:41:17.572131+00	185	Maestría-Santiago (Sede)-2020-Anual-12.00	1	new through import_export	25	1
529	2021-05-18 21:41:17.584217+00	184	Doctorado-Santiago (Sede)-2020-Anual-7.00	1	new through import_export	25	1
530	2021-05-25 15:06:04.294214+00	67	C7 Investigación y Publicaciones	2	[{"changed": {"fields": ["Descripci\\u00f3n"]}}]	16	1
531	2021-05-25 16:48:51.714382+00	1	Informe object (1)	1	[{"added": {}}]	26	1
532	2021-05-25 19:16:35.115438+00	1	Informe del 2021	2	[{"changed": {"fields": ["Visible"]}}]	26	1
533	2021-05-25 19:19:15.968221+00	1	Informe del 2021	2	[{"changed": {"fields": ["Visible"]}}]	26	1
534	2021-05-26 13:34:43.098404+00	2	Informe del 2021	1	[{"added": {}}]	26	1
535	2021-05-26 19:49:05.401217+00	3	Informe del 2018	1	[{"added": {}}]	26	1
536	2021-05-26 20:34:48.104975+00	24836	Santiago (sede)-Enfermería - ENF	1	new through import_export	21	1
537	2021-05-26 20:34:48.118357+00	24835	Santo Domingo Oriental-Enfermería - ENF	1	new through import_export	21	1
538	2021-05-26 20:34:48.131304+00	24834	Cibao Oriental (Nagua)-Enfermería - ENF	1	new through import_export	21	1
539	2021-05-26 20:34:48.144397+00	24735	Santiago (sede)-Agrimensura	2	update through import_export	21	1
540	2021-05-26 20:34:48.157617+00	24732	Santo Domingo Oriental-Agrimensura	2	update through import_export	21	1
541	2021-05-26 20:34:48.170586+00	24730	Cibao Oriental (Nagua)-Agrimensura	2	update through import_export	21	1
542	2021-05-26 20:34:48.183154+00	459	Santiago (sede)-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
543	2021-05-26 20:34:48.196219+00	458	Santo Domingo Oriental-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
544	2021-05-26 20:34:48.209109+00	457	Cibao Oriental (Nagua)-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
545	2021-05-26 20:34:48.221934+00	456	Santiago (sede)-Ciberseguridad	2	update through import_export	21	1
546	2021-05-26 20:34:48.235262+00	455	Santo Domingo Oriental-Ciberseguridad	2	update through import_export	21	1
547	2021-05-26 20:34:48.2475+00	454	Cibao Oriental (Nagua)-Ciberseguridad	2	update through import_export	21	1
548	2021-05-26 20:34:48.260474+00	453	Santiago (sede)-Dirección y Gestión Tributaria	2	update through import_export	21	1
549	2021-05-26 20:34:48.273572+00	452	Santo Domingo Oriental-Dirección y Gestión Tributaria	2	update through import_export	21	1
550	2021-05-26 20:34:48.286695+00	451	Cibao Oriental (Nagua)-Dirección y Gestión Tributaria	2	update through import_export	21	1
551	2021-05-26 20:34:48.3008+00	450	Santiago (sede)- Innovación y Gestión Empresarial	2	update through import_export	21	1
552	2021-05-26 20:34:48.313242+00	449	Santo Domingo Oriental- Innovación y Gestión Empresarial	2	update through import_export	21	1
553	2021-05-26 20:34:48.326473+00	448	Cibao Oriental (Nagua)- Innovación y Gestión Empresarial	2	update through import_export	21	1
554	2021-05-26 20:34:48.339632+00	447	Santiago (sede)-Maestría en Terapia Familiar	2	update through import_export	21	1
555	2021-05-26 20:34:48.352394+00	446	Santo Domingo Oriental-Maestría en Terapia Familiar	2	update through import_export	21	1
556	2021-05-26 20:34:48.364842+00	445	Cibao Oriental (Nagua)-Maestría en Terapia Familiar	2	update through import_export	21	1
557	2021-05-26 20:34:48.377519+00	441	Santiago (sede)-Derecho Constitucional	2	update through import_export	21	1
558	2021-05-26 20:34:48.393518+00	440	Santo Domingo Oriental-Derecho Constitucional	2	update through import_export	21	1
559	2021-05-26 20:34:48.413471+00	439	Cibao Oriental (Nagua)-Derecho Constitucional	2	update through import_export	21	1
560	2021-05-26 20:34:48.433394+00	438	Santiago (sede)-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
561	2021-05-26 20:34:48.45345+00	437	Santo Domingo Oriental-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
562	2021-05-26 20:34:48.472654+00	436	Cibao Oriental (Nagua)-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
563	2021-05-26 20:34:48.49159+00	435	Santiago (sede)-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
564	2021-05-26 20:34:48.510856+00	434	Santo Domingo Oriental-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
565	2021-05-26 20:34:48.529672+00	433	Cibao Oriental (Nagua)-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
566	2021-05-26 20:34:48.549313+00	432	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
567	2021-05-26 20:34:48.568457+00	431	Santo Domingo Oriental-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
568	2021-05-26 20:34:48.588617+00	430	Cibao Oriental (Nagua)-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
569	2021-05-26 20:34:48.605743+00	429	Santiago (sede)-Legislación de Tierras 	2	update through import_export	21	1
570	2021-05-26 20:34:48.618983+00	428	Santo Domingo Oriental-Legislación de Tierras 	2	update through import_export	21	1
571	2021-05-26 20:34:48.631029+00	427	Cibao Oriental (Nagua)-Legislación de Tierras 	2	update through import_export	21	1
572	2021-05-26 20:34:48.64381+00	426	Santiago (sede)-Dirección Financiera 	2	update through import_export	21	1
573	2021-05-26 20:34:48.656569+00	425	Santo Domingo Oriental-Dirección Financiera 	2	update through import_export	21	1
574	2021-05-26 20:34:48.669241+00	424	Cibao Oriental (Nagua)-Dirección Financiera 	2	update through import_export	21	1
575	2021-05-26 20:34:48.682006+00	420	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
576	2021-05-26 20:34:48.694682+00	419	Santo Domingo Oriental-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
577	2021-05-26 20:34:48.707175+00	418	Cibao Oriental (Nagua)-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
578	2021-05-26 20:34:48.71979+00	411	Santiago (sede)-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
579	2021-05-26 20:34:48.732008+00	410	Santo Domingo Oriental-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
580	2021-05-26 20:34:48.744743+00	409	Cibao Oriental (Nagua)-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
581	2021-05-26 20:34:48.757305+00	408	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
582	2021-05-26 20:34:48.770003+00	407	Santo Domingo Oriental-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
583	2021-05-26 20:34:48.782106+00	406	Cibao Oriental (Nagua)-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
584	2021-05-26 20:34:48.794884+00	405	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
585	2021-05-26 20:34:48.807784+00	404	Santo Domingo Oriental-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
586	2021-05-26 20:34:48.82063+00	403	Cibao Oriental (Nagua)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
587	2021-05-26 20:34:48.833524+00	402	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
588	2021-05-26 20:34:48.845997+00	401	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
589	2021-05-26 20:34:48.858869+00	400	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
590	2021-05-26 20:34:48.871495+00	399	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
591	2021-05-26 20:34:48.884028+00	398	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
592	2021-05-26 20:34:48.896573+00	397	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
593	2021-05-26 20:34:48.909484+00	396	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
594	2021-05-26 20:34:48.922346+00	395	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
595	2021-05-26 20:34:48.935621+00	394	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
596	2021-05-26 20:34:48.947747+00	393	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
597	2021-05-26 20:34:48.960819+00	392	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
598	2021-05-26 20:34:48.975163+00	391	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
599	2021-05-26 20:34:48.988564+00	390	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
600	2021-05-26 20:34:49.001631+00	389	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
601	2021-05-26 20:34:49.013804+00	388	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
602	2021-05-26 20:34:49.026902+00	387	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
603	2021-05-26 20:34:49.040183+00	386	Santo Domingo Oriental-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
604	2021-05-26 20:34:49.052655+00	385	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
605	2021-05-26 20:34:49.065148+00	384	Santiago (sede)-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
606	2021-05-26 20:34:49.077655+00	383	Santo Domingo Oriental-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
607	2021-05-26 20:34:49.090464+00	382	Cibao Oriental (Nagua)-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
608	2021-05-26 20:34:49.103771+00	381	Santiago (sede)-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
609	2021-05-26 20:34:49.116662+00	380	Santo Domingo Oriental-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
610	2021-05-26 20:34:49.129582+00	379	Cibao Oriental (Nagua)-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
611	2021-05-26 20:34:49.143011+00	378	Santiago (sede)-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
612	2021-05-26 20:34:49.155952+00	377	Santo Domingo Oriental-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
613	2021-05-26 20:34:49.168703+00	376	Cibao Oriental (Nagua)-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
614	2021-05-26 20:34:49.181535+00	375	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
615	2021-05-26 20:34:49.194405+00	374	Santo Domingo Oriental-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
616	2021-05-26 20:34:49.207516+00	373	Cibao Oriental (Nagua)-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
617	2021-05-26 20:34:49.220418+00	372	Santiago (sede)-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
618	2021-05-26 20:34:49.232983+00	371	Santo Domingo Oriental-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
619	2021-05-26 20:34:49.245988+00	370	Cibao Oriental (Nagua)-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
620	2021-05-26 20:34:49.258761+00	369	Santiago (sede)-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
621	2021-05-26 20:34:49.271848+00	368	Santo Domingo Oriental-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
622	2021-05-26 20:34:49.284914+00	367	Cibao Oriental (Nagua)-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
623	2021-05-26 20:34:49.2978+00	366	Santiago (sede)-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
624	2021-05-26 20:34:49.312723+00	365	Santo Domingo Oriental-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
625	2021-05-26 20:34:49.327191+00	364	Cibao Oriental (Nagua)-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
626	2021-05-26 20:34:49.341025+00	363	Santiago (sede)-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
627	2021-05-26 20:34:49.35455+00	362	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
628	2021-05-26 20:34:49.367912+00	361	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
629	2021-05-26 20:34:49.381201+00	360	Santiago (sede)-Gestión de Centros Educativos 	2	update through import_export	21	1
630	2021-05-26 20:34:49.394758+00	359	Santo Domingo Oriental-Gestión de Centros Educativos 	2	update through import_export	21	1
631	2021-05-26 20:34:49.408376+00	358	Cibao Oriental (Nagua)-Gestión de Centros Educativos 	2	update through import_export	21	1
632	2021-05-26 20:34:49.422245+00	354	Santiago (sede)-Gerencia de Recursos Humanos 	2	update through import_export	21	1
633	2021-05-26 20:34:49.435578+00	353	Santo Domingo Oriental-Gerencia de Recursos Humanos 	2	update through import_export	21	1
634	2021-05-26 20:34:49.448252+00	352	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos 	2	update through import_export	21	1
635	2021-05-26 20:34:49.463073+00	243	Santiago (sede)-Periodismo digital	2	update through import_export	21	1
636	2021-05-26 20:34:49.476909+00	242	Santo Domingo Oriental-Periodismo digital	2	update through import_export	21	1
637	2021-05-26 20:34:49.491372+00	241	Cibao Oriental (Nagua)-Periodismo digital	2	update through import_export	21	1
638	2021-05-26 20:34:49.505366+00	240	Santiago (sede)-Psicología Industrial 	2	update through import_export	21	1
639	2021-05-26 20:34:49.519137+00	239	Santo Domingo Oriental-Psicología Industrial 	2	update through import_export	21	1
640	2021-05-26 20:34:49.532979+00	238	Cibao Oriental (Nagua)-Psicología Industrial 	2	update through import_export	21	1
641	2021-05-26 20:34:49.546479+00	237	Santiago (sede)-Psicología 	2	update through import_export	21	1
642	2021-05-26 20:34:49.560482+00	236	Santo Domingo Oriental-Psicología 	2	update through import_export	21	1
643	2021-05-26 20:34:49.57378+00	235	Cibao Oriental (Nagua)-Psicología 	2	update through import_export	21	1
644	2021-05-26 20:34:49.588124+00	234	Santiago (sede)-Psicología Educativa 	2	update through import_export	21	1
645	2021-05-26 20:34:49.60157+00	233	Santo Domingo Oriental-Psicología Educativa 	2	update through import_export	21	1
646	2021-05-26 20:34:49.620684+00	232	Cibao Oriental (Nagua)-Psicología Educativa 	2	update through import_export	21	1
647	2021-05-26 20:34:49.640036+00	231	Santiago (sede)-Psicología Clínica 	2	update through import_export	21	1
648	2021-05-26 20:34:49.65976+00	230	Santo Domingo Oriental-Psicología Clínica 	2	update through import_export	21	1
649	2021-05-26 20:34:49.67891+00	229	Cibao Oriental (Nagua)-Psicología Clínica 	2	update through import_export	21	1
650	2021-05-26 20:34:49.698516+00	228	Santiago (sede)-Administración de Empresas Turísticas 	2	update through import_export	21	1
651	2021-05-26 20:34:49.717875+00	227	Santo Domingo Oriental-Administración de Empresas Turísticas 	2	update through import_export	21	1
652	2021-05-26 20:34:49.738538+00	226	Cibao Oriental (Nagua)-Administración de Empresas Turísticas 	2	update through import_export	21	1
653	2021-05-26 20:34:49.757761+00	225	Santiago (sede)-Mercadeo 	2	update through import_export	21	1
654	2021-05-26 20:34:49.779091+00	224	Santo Domingo Oriental-Mercadeo 	2	update through import_export	21	1
655	2021-05-26 20:34:49.799882+00	223	Cibao Oriental (Nagua)-Mercadeo 	2	update through import_export	21	1
656	2021-05-26 20:34:49.821142+00	222	Santiago (sede)-Contabilidad Empresarial 	2	update through import_export	21	1
657	2021-05-26 20:34:49.836136+00	221	Santo Domingo Oriental-Contabilidad Empresarial 	2	update through import_export	21	1
658	2021-05-26 20:34:49.851055+00	220	Cibao Oriental (Nagua)-Contabilidad Empresarial 	2	update through import_export	21	1
659	2021-05-26 20:34:49.869429+00	219	Santiago (sede)-Administración de Empresas 	2	update through import_export	21	1
660	2021-05-26 20:34:49.887651+00	218	Santo Domingo Oriental-Administración de Empresas 	2	update through import_export	21	1
661	2021-05-26 20:34:49.906107+00	217	Cibao Oriental (Nagua)-Administración de Empresas 	2	update through import_export	21	1
662	2021-05-26 20:34:49.924481+00	216	Santiago (sede)-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
663	2021-05-26 20:34:49.939073+00	215	Santo Domingo Oriental-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
664	2021-05-26 20:34:49.953598+00	214	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
665	2021-05-26 20:34:49.968267+00	213	Santiago (sede)-Ingeniería en Software 	2	update through import_export	21	1
666	2021-05-26 20:34:49.982208+00	212	Santo Domingo Oriental-Ingeniería en Software 	2	update through import_export	21	1
667	2021-05-26 20:34:49.996813+00	211	Cibao Oriental (Nagua)-Ingeniería en Software 	2	update through import_export	21	1
668	2021-05-26 20:34:50.010763+00	210	Santiago (sede)-Informática Gerencial 	2	update through import_export	21	1
669	2021-05-26 20:34:50.024573+00	209	Santo Domingo Oriental-Informática Gerencial 	2	update through import_export	21	1
670	2021-05-26 20:34:50.038646+00	208	Cibao Oriental (Nagua)-Informática Gerencial 	2	update through import_export	21	1
671	2021-05-26 20:34:50.052666+00	207	Santiago (sede)-Educación Inicial	2	update through import_export	21	1
672	2021-05-26 20:34:50.066698+00	206	Santo Domingo Oriental-Educación Inicial	2	update through import_export	21	1
673	2021-05-26 20:34:50.080602+00	205	Cibao Oriental (Nagua)-Educación Inicial	2	update through import_export	21	1
674	2021-05-26 20:34:50.094347+00	204	Santiago (sede)-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
675	2021-05-26 20:34:50.107953+00	203	Santo Domingo Oriental-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
676	2021-05-26 20:34:50.121108+00	202	Cibao Oriental (Nagua)-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
677	2021-05-26 20:34:50.134851+00	201	Santiago (sede)-Ingles Orientado a la Educacion	2	update through import_export	21	1
678	2021-05-26 20:34:50.148527+00	200	Santo Domingo Oriental-Ingles Orientado a la Educacion	2	update through import_export	21	1
679	2021-05-26 20:34:50.162668+00	199	Cibao Oriental (Nagua)-Ingles Orientado a la Educacion	2	update through import_export	21	1
680	2021-05-26 20:34:50.176318+00	198	Santiago (sede)-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
681	2021-05-26 20:34:50.190244+00	197	Santo Domingo Oriental-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
682	2021-05-26 20:34:50.204217+00	196	Cibao Oriental (Nagua)-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
683	2021-05-26 20:34:50.217389+00	195	Santiago (sede)-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
684	2021-05-26 20:34:50.231573+00	194	Santo Domingo Oriental-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
685	2021-05-26 20:34:50.245349+00	193	Cibao Oriental (Nagua)-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
686	2021-05-26 20:34:50.258543+00	192	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
687	2021-05-26 20:34:50.272149+00	191	Santo Domingo Oriental-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
688	2021-05-26 20:34:50.285631+00	190	Cibao Oriental (Nagua)-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
689	2021-05-26 20:34:50.299662+00	189	Santiago (sede)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
690	2021-05-26 20:34:50.313392+00	188	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
691	2021-05-26 20:34:50.327246+00	187	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
692	2021-05-26 20:34:50.341078+00	186	Santiago (sede)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
693	2021-05-26 20:34:50.354621+00	185	Santo Domingo Oriental-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
694	2021-05-26 20:34:50.368585+00	184	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
695	2021-05-26 20:34:50.382825+00	183	Santiago (sede)-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
696	2021-05-26 20:34:50.396713+00	182	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
697	2021-05-26 20:34:50.410647+00	181	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
698	2021-05-26 20:34:50.424682+00	180	Santiago (sede)-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
699	2021-05-26 20:34:50.438617+00	179	Santo Domingo Oriental-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
700	2021-05-26 20:34:50.45259+00	178	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
701	2021-05-26 20:34:50.466194+00	177	Santiago (sede)-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
702	2021-05-26 20:34:50.48022+00	176	Santo Domingo Oriental-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
703	2021-05-26 20:34:50.494867+00	175	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
704	2021-05-26 20:34:50.511152+00	174	Santiago (sede)-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
705	2021-05-26 20:34:50.530215+00	173	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
706	2021-05-26 20:34:50.544386+00	172	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
707	2021-05-26 20:34:50.55864+00	171	Santiago (sede)-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
708	2021-05-26 20:34:50.572208+00	170	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
709	2021-05-26 20:34:50.586116+00	169	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
710	2021-05-26 20:34:50.599135+00	168	Santiago (sede)-Derecho	2	update through import_export	21	1
711	2021-05-26 20:34:50.613053+00	167	Santo Domingo Oriental-Derecho	2	update through import_export	21	1
712	2021-05-26 20:34:50.626867+00	166	Cibao Oriental (Nagua)-Derecho	2	update through import_export	21	1
713	2021-05-26 20:36:19.078715+00	1380	Cibao Oriental (Nagua)-Enfermería - ENF-2019-Anual-101.000	1	new through import_export	25	1
714	2021-05-26 20:36:19.091754+00	1379	Cibao Oriental (Nagua)-Psicología -2019-Anual-64.000	1	new through import_export	25	1
715	2021-05-26 20:36:19.104733+00	1378	Cibao Oriental (Nagua)-Psicología Educativa -2019-Anual-156.000	1	new through import_export	25	1
716	2021-05-26 20:36:19.117268+00	1377	Cibao Oriental (Nagua)-Contabilidad Empresarial -2019-Anual-74.000	1	new through import_export	25	1
717	2021-05-26 20:36:19.129947+00	1376	Cibao Oriental (Nagua)-Administración de Empresas -2019-Anual-41.000	1	new through import_export	25	1
718	2021-05-26 20:36:19.143159+00	1375	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2019-Anual-58.000	1	new through import_export	25	1
719	2021-05-26 20:36:19.155727+00	1374	Cibao Oriental (Nagua)-Informática Gerencial -2019-Anual-39.000	1	new through import_export	25	1
720	2021-05-26 20:36:19.168685+00	1373	Cibao Oriental (Nagua)-Derecho-2019-Anual-59.000	1	new through import_export	25	1
721	2021-05-26 20:36:19.180652+00	1372	Santo Domingo Oriental-Periodismo digital-2019-Anual-10.000	1	new through import_export	25	1
722	2021-05-26 20:36:19.193511+00	1371	Santo Domingo Oriental-Psicología Industrial -2019-Anual-146.000	1	new through import_export	25	1
723	2021-05-26 20:36:19.206454+00	1370	Santo Domingo Oriental-Psicología -2019-Anual-42.000	1	new through import_export	25	1
724	2021-05-26 20:36:19.219164+00	1369	Santo Domingo Oriental-Psicología Educativa -2019-Anual-296.000	1	new through import_export	25	1
725	2021-05-26 20:36:19.231503+00	1368	Santo Domingo Oriental-Psicología Clínica -2019-Anual-114.000	1	new through import_export	25	1
726	2021-05-26 20:36:19.244365+00	1367	Santo Domingo Oriental-Administración de Empresas Turísticas -2019-Anual-1.000	1	new through import_export	25	1
727	2021-05-26 20:36:19.256958+00	1366	Santo Domingo Oriental-Mercadeo -2019-Anual-102.000	1	new through import_export	25	1
728	2021-05-26 20:36:19.270041+00	1365	Santo Domingo Oriental-Contabilidad Empresarial -2019-Anual-212.000	1	new through import_export	25	1
729	2021-05-26 20:36:19.282798+00	1364	Santo Domingo Oriental-Administración de Empresas -2019-Anual-142.000	1	new through import_export	25	1
730	2021-05-26 20:36:19.295878+00	1363	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2019-Anual-99.000	1	new through import_export	25	1
731	2021-05-26 20:36:19.30809+00	1362	Santo Domingo Oriental-Ingeniería en Software -2019-Anual-106.000	1	new through import_export	25	1
732	2021-05-26 20:36:19.321006+00	1361	Santo Domingo Oriental-Informática Gerencial -2019-Anual-39.000	1	new through import_export	25	1
733	2021-05-26 20:36:19.333695+00	1360	Santo Domingo Oriental-Derecho-2019-Anual-334.000	1	new through import_export	25	1
734	2021-05-26 20:36:19.346471+00	1359	Santiago (sede)-Periodismo digital-2019-Anual-8.000	1	new through import_export	25	1
735	2021-05-26 20:36:19.359251+00	1358	Santiago (sede)-Enfermería - ENF-2019-Anual-86.000	1	new through import_export	25	1
736	2021-05-26 20:36:19.371778+00	1357	Santiago (sede)-Psicología Industrial -2019-Anual-73.000	1	new through import_export	25	1
737	2021-05-26 20:36:19.384823+00	1356	Santiago (sede)-Psicología -2019-Anual-79.000	1	new through import_export	25	1
738	2021-05-26 20:36:19.396989+00	1355	Santiago (sede)-Psicología Educativa -2019-Anual-238.000	1	new through import_export	25	1
739	2021-05-26 20:36:19.409722+00	1354	Santiago (sede)-Psicología Clínica -2019-Anual-96.000	1	new through import_export	25	1
740	2021-05-26 20:36:19.422629+00	1353	Santiago (sede)-Administración de Empresas Turísticas -2019-Anual-26.000	1	new through import_export	25	1
741	2021-05-26 20:36:19.435228+00	1352	Santiago (sede)-Mercadeo -2019-Anual-131.000	1	new through import_export	25	1
742	2021-05-26 20:36:19.447857+00	1351	Santiago (sede)-Contabilidad Empresarial -2019-Anual-201.000	1	new through import_export	25	1
743	2021-05-26 20:36:19.461498+00	1350	Santiago (sede)-Administración de Empresas -2019-Anual-162.000	1	new through import_export	25	1
744	2021-05-26 20:36:19.474473+00	1349	Santiago (sede)-Lenguas Modernas Mención Turismo -2019-Anual-94.000	1	new through import_export	25	1
745	2021-05-26 20:36:19.487473+00	1348	Santiago (sede)-Ingeniería en Software -2019-Anual-175.000	1	new through import_export	25	1
746	2021-05-26 20:36:19.500085+00	1347	Santiago (sede)-Informática Gerencial -2019-Anual-25.000	1	new through import_export	25	1
747	2021-05-26 20:36:19.512992+00	1346	Santiago (sede)-Derecho-2019-Anual-211.000	1	new through import_export	25	1
748	2021-05-26 20:36:19.525861+00	1270	Cibao Oriental (Nagua)-Psicología -2018-Anual-78.000	1	new through import_export	25	1
749	2021-05-26 20:36:19.539054+00	1269	Cibao Oriental (Nagua)-Psicología Educativa -2018-Anual-223.000	1	new through import_export	25	1
750	2021-05-26 20:36:19.55213+00	1268	Cibao Oriental (Nagua)-Contabilidad Empresarial -2018-Anual-137.000	1	new through import_export	25	1
751	2021-05-26 20:36:19.564498+00	1267	Cibao Oriental (Nagua)-Administración de Empresas -2018-Anual-66.000	1	new through import_export	25	1
752	2021-05-26 20:36:19.577251+00	1266	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2018-Anual-90.000	1	new through import_export	25	1
753	2021-05-26 20:36:19.59013+00	1265	Cibao Oriental (Nagua)-Informática Gerencial -2018-Anual-31.000	1	new through import_export	25	1
754	2021-05-26 20:36:19.602868+00	1264	Cibao Oriental (Nagua)-Derecho-2018-Anual-83.000	1	new through import_export	25	1
755	2021-05-26 20:36:19.615462+00	1263	Santo Domingo Oriental-Psicología Industrial -2018-Anual-192.000	1	new through import_export	25	1
756	2021-05-26 20:36:19.62827+00	1262	Santo Domingo Oriental-Psicología -2018-Anual-38.000	1	new through import_export	25	1
757	2021-05-26 20:36:19.64084+00	1261	Santo Domingo Oriental-Psicología Educativa -2018-Anual-399.000	1	new through import_export	25	1
758	2021-05-26 20:36:19.653249+00	1260	Santo Domingo Oriental-Psicología Clínica -2018-Anual-192.000	1	new through import_export	25	1
759	2021-05-26 20:36:19.66539+00	1259	Santo Domingo Oriental-Mercadeo -2018-Anual-142.000	1	new through import_export	25	1
760	2021-05-26 20:36:19.678196+00	1258	Santo Domingo Oriental-Contabilidad Empresarial -2018-Anual-352.000	1	new through import_export	25	1
761	2021-05-26 20:36:19.690771+00	1257	Santo Domingo Oriental-Administración de Empresas -2018-Anual-222.000	1	new through import_export	25	1
762	2021-05-26 20:36:19.70393+00	1256	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2018-Anual-76.000	1	new through import_export	25	1
763	2021-05-26 20:36:19.716374+00	1255	Santo Domingo Oriental-Ingeniería en Software -2018-Anual-208.000	1	new through import_export	25	1
764	2021-05-26 20:36:19.729124+00	1254	Santo Domingo Oriental-Informática Gerencial -2018-Anual-23.000	1	new through import_export	25	1
765	2021-05-26 20:36:19.741788+00	1253	Santo Domingo Oriental-Derecho-2018-Anual-482.000	1	new through import_export	25	1
766	2021-05-26 20:36:19.75442+00	1252	Santiago (sede)-Psicología Industrial -2018-Anual-68.000	1	new through import_export	25	1
767	2021-05-26 20:36:19.767442+00	1251	Santiago (sede)-Psicología -2018-Anual-153.000	1	new through import_export	25	1
768	2021-05-26 20:36:19.780421+00	1250	Santiago (sede)-Psicología Educativa -2018-Anual-425.000	1	new through import_export	25	1
769	2021-05-26 20:36:19.793459+00	1249	Santiago (sede)-Psicología Clínica -2018-Anual-180.000	1	new through import_export	25	1
770	2021-05-26 20:36:19.80691+00	1248	Santiago (sede)-Administración de Empresas Turísticas -2018-Anual-25.000	1	new through import_export	25	1
771	2021-05-26 20:36:19.820772+00	1247	Santiago (sede)-Mercadeo -2018-Anual-180.000	1	new through import_export	25	1
772	2021-05-26 20:36:19.834045+00	1246	Santiago (sede)-Contabilidad Empresarial -2018-Anual-341.000	1	new through import_export	25	1
773	2021-05-26 20:36:19.846986+00	1245	Santiago (sede)-Administración de Empresas -2018-Anual-218.000	1	new through import_export	25	1
774	2021-05-26 20:36:19.860399+00	1244	Santiago (sede)-Lenguas Modernas Mención Turismo -2018-Anual-140.000	1	new through import_export	25	1
775	2021-05-26 20:36:19.873704+00	1243	Santiago (sede)-Ingeniería en Software -2018-Anual-259.000	1	new through import_export	25	1
776	2021-05-26 20:36:19.886655+00	1242	Santiago (sede)-Informática Gerencial -2018-Anual-15.000	1	new through import_export	25	1
777	2021-05-26 20:36:19.899211+00	1241	Santiago (sede)-Derecho-2018-Anual-303.000	1	new through import_export	25	1
778	2021-05-26 20:36:19.912034+00	1148	Cibao Oriental (Nagua)-Periodismo digital-2017-Anual-1.000	1	new through import_export	25	1
779	2021-05-26 20:36:19.925086+00	1147	Cibao Oriental (Nagua)-Psicología -2017-Anual-150.000	1	new through import_export	25	1
780	2021-05-26 20:36:19.938698+00	1146	Cibao Oriental (Nagua)-Psicología Educativa -2017-Anual-450.000	1	new through import_export	25	1
781	2021-05-26 20:36:19.956976+00	1145	Cibao Oriental (Nagua)-Contabilidad Empresarial -2017-Anual-176.000	1	new through import_export	25	1
782	2021-05-26 20:36:19.975919+00	1144	Cibao Oriental (Nagua)-Administración de Empresas -2017-Anual-97.000	1	new through import_export	25	1
783	2021-05-26 20:36:19.994974+00	1143	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2017-Anual-128.000	1	new through import_export	25	1
784	2021-05-26 20:36:20.014039+00	1142	Cibao Oriental (Nagua)-Informática Gerencial -2017-Anual-84.000	1	new through import_export	25	1
785	2021-05-26 20:36:20.034168+00	1141	Cibao Oriental (Nagua)-Derecho-2017-Anual-105.000	1	new through import_export	25	1
786	2021-05-26 20:36:20.05395+00	1140	Santo Domingo Oriental-Periodismo digital-2017-Anual-24.000	1	new through import_export	25	1
787	2021-05-26 20:36:20.072875+00	1139	Santo Domingo Oriental-Psicología Industrial -2017-Anual-283.000	1	new through import_export	25	1
788	2021-05-26 20:36:20.092744+00	1138	Santo Domingo Oriental-Psicología -2017-Anual-81.000	1	new through import_export	25	1
789	2021-05-26 20:36:20.111465+00	1137	Santo Domingo Oriental-Psicología Educativa -2017-Anual-757.000	1	new through import_export	25	1
790	2021-05-26 20:36:20.130133+00	1136	Santo Domingo Oriental-Psicología Clínica -2017-Anual-249.000	1	new through import_export	25	1
791	2021-05-26 20:36:20.14778+00	1135	Santo Domingo Oriental-Mercadeo -2017-Anual-220.000	1	new through import_export	25	1
792	2021-05-26 20:36:20.167408+00	1134	Santo Domingo Oriental-Contabilidad Empresarial -2017-Anual-581.000	1	new through import_export	25	1
793	2021-05-26 20:36:20.183927+00	1133	Santo Domingo Oriental-Administración de Empresas -2017-Anual-309.000	1	new through import_export	25	1
794	2021-05-26 20:36:20.19635+00	1132	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2017-Anual-324.000	1	new through import_export	25	1
795	2021-05-26 20:36:20.209071+00	1131	Santo Domingo Oriental-Ingeniería en Software -2017-Anual-248.000	1	new through import_export	25	1
796	2021-05-26 20:36:20.221947+00	1130	Santo Domingo Oriental-Informática Gerencial -2017-Anual-83.000	1	new through import_export	25	1
797	2021-05-26 20:36:20.234637+00	1129	Santo Domingo Oriental-Derecho-2017-Anual-599.000	1	new through import_export	25	1
798	2021-05-26 20:36:20.246899+00	1128	Santiago (sede)-Periodismo digital-2017-Anual-9.000	1	new through import_export	25	1
799	2021-05-26 20:36:20.259887+00	1127	Santiago (sede)-Psicología Industrial -2017-Anual-112.000	1	new through import_export	25	1
800	2021-05-26 20:36:20.272672+00	1126	Santiago (sede)-Psicología -2017-Anual-199.000	1	new through import_export	25	1
801	2021-05-26 20:36:20.286377+00	1125	Santiago (sede)-Psicología Educativa -2017-Anual-753.000	1	new through import_export	25	1
802	2021-05-26 20:36:20.299152+00	1124	Santiago (sede)-Psicología Clínica -2017-Anual-184.000	1	new through import_export	25	1
803	2021-05-26 20:36:20.3131+00	1123	Santiago (sede)-Administración de Empresas Turísticas -2017-Anual-81.000	1	new through import_export	25	1
804	2021-05-26 20:36:20.327084+00	1122	Santiago (sede)-Mercadeo -2017-Anual-296.000	1	new through import_export	25	1
805	2021-05-26 20:36:20.339703+00	1121	Santiago (sede)-Contabilidad Empresarial -2017-Anual-478.000	1	new through import_export	25	1
806	2021-05-26 20:36:20.352263+00	1120	Santiago (sede)-Administración de Empresas -2017-Anual-252.000	1	new through import_export	25	1
807	2021-05-26 20:36:20.364183+00	1119	Santiago (sede)-Lenguas Modernas Mención Turismo -2017-Anual-240.000	1	new through import_export	25	1
808	2021-05-26 20:36:20.377144+00	1118	Santiago (sede)-Ingeniería en Software -2017-Anual-320.000	1	new through import_export	25	1
809	2021-05-26 20:36:20.390068+00	1117	Santiago (sede)-Informática Gerencial -2017-Anual-74.000	1	new through import_export	25	1
810	2021-05-26 20:36:20.403315+00	1116	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria-2017-Anual-17.000	1	new through import_export	25	1
811	2021-05-26 20:36:20.415728+00	1115	Santiago (sede)-Derecho-2017-Anual-458.000	1	new through import_export	25	1
812	2021-05-26 20:36:20.428665+00	1080	Cibao Oriental (Nagua)-Periodismo digital-2021-Anual-2.000	1	new through import_export	25	1
813	2021-05-26 20:36:20.441692+00	1079	Cibao Oriental (Nagua)-Psicología -2021-Anual-136.000	1	new through import_export	25	1
814	2021-05-26 20:36:20.45415+00	1078	Cibao Oriental (Nagua)-Psicología Educativa -2021-Anual-532.000	1	new through import_export	25	1
815	2021-05-26 20:36:20.466887+00	1077	Cibao Oriental (Nagua)-Administración de Empresas Turísticas -2021-Anual-23.000	1	new through import_export	25	1
816	2021-05-26 20:36:20.479418+00	1076	Cibao Oriental (Nagua)-Mercadeo -2021-Anual-27.000	1	new through import_export	25	1
817	2021-05-26 20:36:20.491877+00	1075	Cibao Oriental (Nagua)-Contabilidad Empresarial -2021-Anual-185.000	1	new through import_export	25	1
818	2021-05-26 20:36:20.504921+00	1074	Cibao Oriental (Nagua)-Administración de Empresas -2021-Anual-68.000	1	new through import_export	25	1
819	2021-05-26 20:36:20.517819+00	1073	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2021-Anual-134.000	1	new through import_export	25	1
820	2021-05-26 20:36:20.530227+00	1072	Cibao Oriental (Nagua)-Informática Gerencial -2021-Anual-68.000	1	new through import_export	25	1
821	2021-05-26 20:36:20.543261+00	1071	Cibao Oriental (Nagua)-Derecho-2021-Anual-112.000	1	new through import_export	25	1
822	2021-05-26 20:36:20.555865+00	1070	Santo Domingo Oriental-Periodismo digital-2021-Anual-10.000	1	new through import_export	25	1
823	2021-05-26 20:36:20.569182+00	1069	Santo Domingo Oriental-Psicología Industrial -2021-Anual-303.000	1	new through import_export	25	1
824	2021-05-26 20:36:20.58131+00	1068	Santo Domingo Oriental-Psicología -2021-Anual-88.000	1	new through import_export	25	1
825	2021-05-26 20:36:20.59404+00	1067	Santo Domingo Oriental-Psicología Educativa -2021-Anual-937.000	1	new through import_export	25	1
826	2021-05-26 20:36:20.607005+00	1066	Santo Domingo Oriental-Psicología Clínica -2021-Anual-245.000	1	new through import_export	25	1
827	2021-05-26 20:36:20.619567+00	1065	Santo Domingo Oriental-Mercadeo -2021-Anual-239.000	1	new through import_export	25	1
828	2021-05-26 20:36:20.632004+00	1064	Santo Domingo Oriental-Contabilidad Empresarial -2021-Anual-601.000	1	new through import_export	25	1
829	2021-05-26 20:36:20.644769+00	1063	Santo Domingo Oriental-Administración de Empresas -2021-Anual-324.000	1	new through import_export	25	1
830	2021-05-26 20:36:20.657484+00	1062	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2021-Anual-213.000	1	new through import_export	25	1
831	2021-05-26 20:36:20.670804+00	1061	Santo Domingo Oriental-Ingeniería en Software -2021-Anual-181.000	1	new through import_export	25	1
832	2021-05-26 20:36:20.6833+00	1060	Santo Domingo Oriental-Informática Gerencial -2021-Anual-68.000	1	new through import_export	25	1
833	2021-05-26 20:36:20.696013+00	1059	Santo Domingo Oriental-Derecho-2021-Anual-637.000	1	new through import_export	25	1
834	2021-05-26 20:36:20.709451+00	1058	Santiago (sede)-Periodismo digital-2021-Anual-11.000	1	new through import_export	25	1
835	2021-05-26 20:36:20.722862+00	1057	Santiago (sede)-Psicología Industrial -2021-Anual-142.000	1	new through import_export	25	1
836	2021-05-26 20:36:20.735865+00	1056	Santiago (sede)-Psicología -2021-Anual-232.000	1	new through import_export	25	1
837	2021-05-26 20:36:20.748228+00	1055	Santiago (sede)-Psicología Educativa -2021-Anual-1017.000	1	new through import_export	25	1
838	2021-05-26 20:36:20.761371+00	1054	Santiago (sede)-Psicología Clínica -2021-Anual-188.000	1	new through import_export	25	1
839	2021-05-26 20:36:20.773915+00	1053	Santiago (sede)-Administración de Empresas Turísticas -2021-Anual-78.000	1	new through import_export	25	1
840	2021-05-26 20:36:20.786921+00	1052	Santiago (sede)-Mercadeo -2021-Anual-341.000	1	new through import_export	25	1
841	2021-05-26 20:36:20.79937+00	1051	Santiago (sede)-Contabilidad Empresarial -2021-Anual-535.000	1	new through import_export	25	1
842	2021-05-26 20:36:20.812216+00	1050	Santiago (sede)-Administración de Empresas -2021-Anual-295.000	1	new through import_export	25	1
843	2021-05-26 20:36:20.825027+00	1049	Santiago (sede)-Lenguas Modernas Mención Turismo -2021-Anual-240.000	1	new through import_export	25	1
844	2021-05-26 20:36:20.837825+00	1048	Santiago (sede)-Ingeniería en Software -2021-Anual-351.000	1	new through import_export	25	1
845	2021-05-26 20:36:20.850637+00	1047	Santiago (sede)-Informática Gerencial -2021-Anual-80.000	1	new through import_export	25	1
846	2021-05-26 20:36:20.863158+00	1046	Santiago (sede)-Matematica  Orientada a la Educacion Secundaria-2021-Anual-28.000	1	new through import_export	25	1
847	2021-05-26 20:36:20.875878+00	1045	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria-2021-Anual-12.000	1	new through import_export	25	1
848	2021-05-26 20:36:20.888694+00	1044	Santiago (sede)-Derecho-2021-Anual-451.000	1	new through import_export	25	1
849	2021-05-26 20:36:20.90115+00	1006	Cibao Oriental (Nagua)-Psicología Industrial -2020-Anual-1.000	1	new through import_export	25	1
850	2021-05-26 20:36:20.913507+00	1005	Cibao Oriental (Nagua)-Psicología -2020-Anual-139.000	1	new through import_export	25	1
851	2021-05-26 20:36:20.926328+00	1004	Cibao Oriental (Nagua)-Psicología Educativa -2020-Anual-535.000	1	new through import_export	25	1
852	2021-05-26 20:36:20.938906+00	1003	Cibao Oriental (Nagua)-Administración de Empresas Turísticas -2020-Anual-20.000	1	new through import_export	25	1
853	2021-05-26 20:36:20.951896+00	1002	Cibao Oriental (Nagua)-Mercadeo -2020-Anual-36.000	1	new through import_export	25	1
854	2021-05-26 20:36:20.963988+00	1001	Cibao Oriental (Nagua)-Contabilidad Empresarial -2020-Anual-152.000	1	new through import_export	25	1
855	2021-05-26 20:36:20.976654+00	1000	Cibao Oriental (Nagua)-Administración de Empresas -2020-Anual-71.000	1	new through import_export	25	1
856	2021-05-26 20:36:20.989439+00	999	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2020-Anual-96.000	1	new through import_export	25	1
857	2021-05-26 20:36:21.002063+00	998	Cibao Oriental (Nagua)-Derecho-2020-Anual-111.000	1	new through import_export	25	1
858	2021-05-26 20:36:21.0143+00	997	Santo Domingo Oriental-Psicología Industrial -2020-Anual-330.000	1	new through import_export	25	1
859	2021-05-26 20:36:21.027212+00	996	Santo Domingo Oriental-Psicología -2020-Anual-107.000	1	new through import_export	25	1
860	2021-05-26 20:36:21.039789+00	995	Santo Domingo Oriental-Psicología Educativa -2020-Anual-938.000	1	new through import_export	25	1
861	2021-05-26 20:36:21.052575+00	994	Santo Domingo Oriental-Psicología Clínica -2020-Anual-256.000	1	new through import_export	25	1
862	2021-05-26 20:36:21.064571+00	993	Santo Domingo Oriental-Administración de Empresas Turísticas -2020-Anual-1.000	1	new through import_export	25	1
863	2021-05-26 20:36:21.077166+00	992	Santo Domingo Oriental-Mercadeo -2020-Anual-263.000	1	new through import_export	25	1
864	2021-05-26 20:36:21.089877+00	991	Santo Domingo Oriental-Contabilidad Empresarial -2020-Anual-616.000	1	new through import_export	25	1
865	2021-05-26 20:36:21.103305+00	990	Santo Domingo Oriental-Administración de Empresas -2020-Anual-295.000	1	new through import_export	25	1
866	2021-05-26 20:36:21.11579+00	989	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2020-Anual-176.000	1	new through import_export	25	1
867	2021-05-26 20:36:21.129384+00	988	Santo Domingo Oriental-Ingeniería en Software -2020-Anual-91.000	1	new through import_export	25	1
868	2021-05-26 20:36:21.142034+00	987	Santo Domingo Oriental-Informática Gerencial -2020-Anual-27.000	1	new through import_export	25	1
869	2021-05-26 20:36:21.155107+00	986	Santo Domingo Oriental-Derecho-2020-Anual-643.000	1	new through import_export	25	1
870	2021-05-26 20:36:21.167792+00	985	Santiago (sede)-Psicología Industrial -2020-Anual-136.000	1	new through import_export	25	1
871	2021-05-26 20:36:21.180975+00	984	Santiago (sede)-Psicología -2020-Anual-167.000	1	new through import_export	25	1
872	2021-05-26 20:36:21.200489+00	983	Santiago (sede)-Psicología Educativa -2020-Anual-1023.000	1	new through import_export	25	1
873	2021-05-26 20:36:21.219506+00	982	Santiago (sede)-Psicología Clínica -2020-Anual-183.000	1	new through import_export	25	1
874	2021-05-26 20:36:21.238467+00	981	Santiago (sede)-Administración de Empresas Turísticas -2020-Anual-61.000	1	new through import_export	25	1
875	2021-05-26 20:36:21.258022+00	980	Santiago (sede)-Mercadeo -2020-Anual-294.000	1	new through import_export	25	1
876	2021-05-26 20:36:21.27694+00	979	Santiago (sede)-Contabilidad Empresarial -2020-Anual-462.000	1	new through import_export	25	1
877	2021-05-26 20:36:21.296261+00	978	Santiago (sede)-Administración de Empresas -2020-Anual-258.000	1	new through import_export	25	1
878	2021-05-26 20:36:21.315382+00	977	Santiago (sede)-Lenguas Modernas Mención Turismo -2020-Anual-217.000	1	new through import_export	25	1
879	2021-05-26 20:36:21.335581+00	976	Santiago (sede)-Ingeniería en Software -2020-Anual-304.000	1	new through import_export	25	1
880	2021-05-26 20:36:21.358167+00	975	Santiago (sede)-Informática Gerencial -2020-Anual-75.000	1	new through import_export	25	1
881	2021-05-26 20:36:21.378596+00	974	Santiago (sede)-Educación Inicial-2020-Anual-72.000	1	new through import_export	25	1
882	2021-05-26 20:36:21.397249+00	973	Santiago (sede)-Derecho-2020-Anual-502.000	1	new through import_export	25	1
883	2021-05-26 20:36:21.409583+00	938	Cibao Oriental (Nagua)-Agrimensura-2019-Anual-46.000	1	new through import_export	25	1
884	2021-05-26 20:36:21.422568+00	937	Santo Domingo Oriental-Agrimensura-2019-Anual-70.000	1	new through import_export	25	1
885	2021-05-26 20:36:21.43535+00	936	Santiago (sede)-Agrimensura-2019-Anual-170.000	1	new through import_export	25	1
886	2021-05-26 20:36:21.447826+00	935	Cibao Oriental (Nagua)-Agrimensura-2018-Anual-69.000	1	new through import_export	25	1
887	2021-05-26 20:36:21.460693+00	934	Santo Domingo Oriental-Agrimensura-2018-Anual-102.000	1	new through import_export	25	1
888	2021-05-26 20:36:21.473456+00	933	Santiago (sede)-Agrimensura-2018-Anual-193.000	1	new through import_export	25	1
889	2021-05-26 20:36:21.48647+00	932	Cibao Oriental (Nagua)-Agrimensura-2017-Anual-102.000	1	new through import_export	25	1
890	2021-05-26 20:36:21.498807+00	931	Santiago (sede)-Agrimensura-2017-Anual-305.000	1	new through import_export	25	1
891	2021-05-26 20:36:21.512096+00	930	Cibao Oriental (Nagua)-Agrimensura-2021-Anual-156.000	1	new through import_export	25	1
892	2021-05-26 20:36:21.525049+00	929	Santiago (sede)-Agrimensura-2021-Anual-374.000	1	new through import_export	25	1
893	2021-05-26 20:36:21.537768+00	928	Santiago (sede)-Agrimensura-2020-Anual-344.000	1	new through import_export	25	1
894	2021-05-27 13:29:57.385654+00	1	Informe del 2019	2	[{"changed": {"fields": ["Fecha", "Url"]}}]	26	1
895	2021-05-27 13:30:15.25648+00	3	Informe del 2018	3		26	1
896	2021-05-27 13:30:15.27069+00	2	Informe del 2021	3		26	1
897	2021-05-28 14:25:55.784036+00	166	Cibao Oriental (Nagua)-Derecho	2	update through import_export	21	1
898	2021-05-28 14:25:55.803634+00	167	Santo Domingo Oriental-Derecho	2	update through import_export	21	1
899	2021-05-28 14:25:55.822802+00	168	Santiago (sede)-Derecho	2	update through import_export	21	1
900	2021-05-28 14:25:55.839106+00	169	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
901	2021-05-28 14:25:55.853277+00	170	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
902	2021-05-28 14:25:55.86579+00	171	Santiago (sede)-Ciencia de la Educación, Mención Educación Básica 	2	update through import_export	21	1
903	2021-05-28 14:25:55.878924+00	172	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
904	2021-05-28 14:25:55.891717+00	173	Santo Domingo Oriental-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
905	2021-05-28 14:25:55.905659+00	174	Santiago (sede)-Ciencia de la Educación, Mención Educación Inicial 	2	update through import_export	21	1
906	2021-05-28 14:25:55.918944+00	175	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
907	2021-05-28 14:25:55.931074+00	176	Santo Domingo Oriental-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
908	2021-05-28 14:25:55.944808+00	177	Santiago (sede)-Ciencia de la Educación, Mención Lengua Española 	2	update through import_export	21	1
909	2021-05-28 14:25:55.958221+00	178	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
910	2021-05-28 14:25:55.971399+00	179	Santo Domingo Oriental-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
911	2021-05-28 14:25:55.984396+00	180	Santiago (sede)-Ciencia de la Educación, Mención Matemática Física 	2	update through import_export	21	1
912	2021-05-28 14:25:55.99681+00	181	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
913	2021-05-28 14:25:56.010148+00	182	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
914	2021-05-28 14:25:56.023131+00	183	Santiago (sede)-Ciencia de la Educación, Mención Ciencias Sociales 	2	update through import_export	21	1
915	2021-05-28 14:25:56.036498+00	184	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
916	2021-05-28 14:25:56.04881+00	185	Santo Domingo Oriental-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
917	2021-05-28 14:25:56.062029+00	186	Santiago (sede)-Ciencia de la Educación, Mención Primer Ciclo de la Educación Básica 	2	update through import_export	21	1
918	2021-05-28 14:25:56.075454+00	187	Cibao Oriental (Nagua)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
919	2021-05-28 14:25:56.088412+00	188	Santo Domingo Oriental-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
920	2021-05-28 14:25:56.118006+00	189	Santiago (sede)-Ciencia de la Educación, Mención Ciencias de la Naturaleza 	2	update through import_export	21	1
921	2021-05-28 14:25:56.13155+00	190	Cibao Oriental (Nagua)-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
922	2021-05-28 14:25:56.144793+00	191	Santo Domingo Oriental-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
923	2021-05-28 14:25:56.158001+00	192	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria	2	update through import_export	21	1
924	2021-05-28 14:25:56.171215+00	193	Cibao Oriental (Nagua)-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
925	2021-05-28 14:25:56.185331+00	194	Santo Domingo Oriental-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
926	2021-05-28 14:25:56.198101+00	195	Santiago (sede)-Matematica  Orientada a la Educacion Secundaria	2	update through import_export	21	1
927	2021-05-28 14:25:56.211373+00	196	Cibao Oriental (Nagua)-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
928	2021-05-28 14:25:56.225171+00	197	Santo Domingo Oriental-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
929	2021-05-28 14:25:56.238849+00	198	Santiago (sede)-Ciencias Sociales Orienada a la Educacion Secundaria	2	update through import_export	21	1
930	2021-05-28 14:25:56.251843+00	199	Cibao Oriental (Nagua)-Ingles Orientado a la Educacion	2	update through import_export	21	1
931	2021-05-28 14:25:56.264446+00	200	Santo Domingo Oriental-Ingles Orientado a la Educacion	2	update through import_export	21	1
932	2021-05-28 14:25:56.277432+00	201	Santiago (sede)-Ingles Orientado a la Educacion	2	update through import_export	21	1
933	2021-05-28 14:25:56.298124+00	202	Cibao Oriental (Nagua)-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
934	2021-05-28 14:25:56.318103+00	203	Santo Domingo Oriental-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
935	2021-05-28 14:25:56.33729+00	204	Santiago (sede)-Educacion Primaria, Primer Ciclo	2	update through import_export	21	1
936	2021-05-28 14:25:56.35708+00	205	Cibao Oriental (Nagua)-Educación Inicial	2	update through import_export	21	1
937	2021-05-28 14:25:56.375375+00	206	Santo Domingo Oriental-Educación Inicial	2	update through import_export	21	1
938	2021-05-28 14:25:56.394803+00	207	Santiago (sede)-Educación Inicial	2	update through import_export	21	1
939	2021-05-28 14:25:56.414105+00	208	Cibao Oriental (Nagua)-Informática Gerencial 	2	update through import_export	21	1
940	2021-05-28 14:25:56.43371+00	209	Santo Domingo Oriental-Informática Gerencial 	2	update through import_export	21	1
941	2021-05-28 14:25:56.454026+00	210	Santiago (sede)-Informática Gerencial 	2	update through import_export	21	1
942	2021-05-28 14:25:56.473092+00	211	Cibao Oriental (Nagua)-Ingeniería en Software 	2	update through import_export	21	1
943	2021-05-28 14:25:56.492575+00	212	Santo Domingo Oriental-Ingeniería en Software 	2	update through import_export	21	1
944	2021-05-28 14:25:56.512411+00	213	Santiago (sede)-Ingeniería en Software 	2	update through import_export	21	1
945	2021-05-28 14:25:56.531725+00	214	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
946	2021-05-28 14:25:56.546771+00	215	Santo Domingo Oriental-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
947	2021-05-28 14:25:56.559883+00	216	Santiago (sede)-Lenguas Modernas Mención Turismo 	2	update through import_export	21	1
948	2021-05-28 14:25:56.573873+00	217	Cibao Oriental (Nagua)-Administración de Empresas 	2	update through import_export	21	1
949	2021-05-28 14:25:56.587294+00	218	Santo Domingo Oriental-Administración de Empresas 	2	update through import_export	21	1
950	2021-05-28 14:25:56.600001+00	219	Santiago (sede)-Administración de Empresas 	2	update through import_export	21	1
951	2021-05-28 14:25:56.613084+00	220	Cibao Oriental (Nagua)-Contabilidad Empresarial 	2	update through import_export	21	1
952	2021-05-28 14:25:56.626714+00	221	Santo Domingo Oriental-Contabilidad Empresarial 	2	update through import_export	21	1
953	2021-05-28 14:25:56.63973+00	222	Santiago (sede)-Contabilidad Empresarial 	2	update through import_export	21	1
954	2021-05-28 14:25:56.653297+00	223	Cibao Oriental (Nagua)-Mercadeo 	2	update through import_export	21	1
955	2021-05-28 14:25:56.666483+00	224	Santo Domingo Oriental-Mercadeo 	2	update through import_export	21	1
956	2021-05-28 14:25:56.680574+00	225	Santiago (sede)-Mercadeo 	2	update through import_export	21	1
957	2021-05-28 14:25:56.693544+00	226	Cibao Oriental (Nagua)-Administración de Empresas Turísticas 	2	update through import_export	21	1
958	2021-05-28 14:25:56.706566+00	227	Santo Domingo Oriental-Administración de Empresas Turísticas 	2	update through import_export	21	1
959	2021-05-28 14:25:56.72056+00	228	Santiago (sede)-Administración de Empresas Turísticas 	2	update through import_export	21	1
960	2021-05-28 14:25:56.733538+00	229	Cibao Oriental (Nagua)-Psicología Clínica 	2	update through import_export	21	1
961	2021-05-28 14:25:56.74641+00	230	Santo Domingo Oriental-Psicología Clínica 	2	update through import_export	21	1
962	2021-05-28 14:25:56.759149+00	231	Santiago (sede)-Psicología Clínica 	2	update through import_export	21	1
963	2021-05-28 14:25:56.772039+00	232	Cibao Oriental (Nagua)-Psicología Educativa 	2	update through import_export	21	1
964	2021-05-28 14:25:56.784757+00	233	Santo Domingo Oriental-Psicología Educativa 	2	update through import_export	21	1
965	2021-05-28 14:25:56.798988+00	234	Santiago (sede)-Psicología Educativa 	2	update through import_export	21	1
966	2021-05-28 14:25:56.811952+00	235	Cibao Oriental (Nagua)-Psicología 	2	update through import_export	21	1
967	2021-05-28 14:25:56.825074+00	236	Santo Domingo Oriental-Psicología 	2	update through import_export	21	1
968	2021-05-28 14:25:56.838053+00	237	Santiago (sede)-Psicología 	2	update through import_export	21	1
969	2021-05-28 14:25:56.851837+00	238	Cibao Oriental (Nagua)-Psicología Industrial 	2	update through import_export	21	1
970	2021-05-28 14:25:56.864487+00	239	Santo Domingo Oriental-Psicología Industrial 	2	update through import_export	21	1
971	2021-05-28 14:25:56.877497+00	240	Santiago (sede)-Psicología Industrial 	2	update through import_export	21	1
972	2021-05-28 14:25:56.890533+00	241	Cibao Oriental (Nagua)-Periodismo digital	2	update through import_export	21	1
973	2021-05-28 14:25:56.904828+00	242	Santo Domingo Oriental-Periodismo digital	2	update through import_export	21	1
974	2021-05-28 14:25:56.91753+00	243	Santiago (sede)-Periodismo digital	2	update through import_export	21	1
1075	2021-05-28 14:25:58.33277+00	25054	Santiago (sede)-Mercadeo (Postgrado)	1	new through import_export	21	1
975	2021-05-28 14:25:56.930424+00	352	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos 	2	update through import_export	21	1
976	2021-05-28 14:25:56.943559+00	353	Santo Domingo Oriental-Gerencia de Recursos Humanos 	2	update through import_export	21	1
977	2021-05-28 14:25:56.958433+00	354	Santiago (sede)-Gerencia de Recursos Humanos 	2	update through import_export	21	1
978	2021-05-28 14:25:56.971505+00	358	Cibao Oriental (Nagua)-Gestión de Centros Educativos 	2	update through import_export	21	1
979	2021-05-28 14:25:56.984314+00	359	Santo Domingo Oriental-Gestión de Centros Educativos 	2	update through import_export	21	1
980	2021-05-28 14:25:56.997366+00	360	Santiago (sede)-Gestión de Centros Educativos 	2	update through import_export	21	1
981	2021-05-28 14:25:57.010933+00	361	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
982	2021-05-28 14:25:57.023968+00	362	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
983	2021-05-28 14:25:57.037544+00	363	Santiago (sede)-Historia, con Orientación a la Enseñanza 	2	update through import_export	21	1
984	2021-05-28 14:25:57.050153+00	364	Cibao Oriental (Nagua)-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
985	2021-05-28 14:25:57.063872+00	365	Santo Domingo Oriental-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
986	2021-05-28 14:25:57.077143+00	366	Santiago (sede)-Informática, con Orientación a la Enseñanza 	2	update through import_export	21	1
987	2021-05-28 14:25:57.090193+00	367	Cibao Oriental (Nagua)-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
988	2021-05-28 14:25:57.103564+00	368	Santo Domingo Oriental-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
989	2021-05-28 14:25:57.117301+00	369	Santiago (sede)-Biología, con Orientación a la Enseñanza 	2	update through import_export	21	1
990	2021-05-28 14:25:57.130065+00	370	Cibao Oriental (Nagua)-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
991	2021-05-28 14:25:57.143163+00	371	Santo Domingo Oriental-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
992	2021-05-28 14:25:57.156493+00	372	Santiago (sede)-Educación, Mención Lengua Española, Segundo Ciclo 	2	update through import_export	21	1
993	2021-05-28 14:25:57.170356+00	373	Cibao Oriental (Nagua)-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
994	2021-05-28 14:25:57.183786+00	374	Santo Domingo Oriental-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
995	2021-05-28 14:25:57.196561+00	375	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza 	2	update through import_export	21	1
996	2021-05-28 14:25:57.209695+00	376	Cibao Oriental (Nagua)-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
997	2021-05-28 14:25:57.223217+00	377	Santo Domingo Oriental-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
998	2021-05-28 14:25:57.23614+00	378	Santiago (sede)-Educación, Matemática Física, Segundo Ciclo 	2	update through import_export	21	1
999	2021-05-28 14:25:57.249542+00	379	Cibao Oriental (Nagua)-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
1000	2021-05-28 14:25:57.262356+00	380	Santo Domingo Oriental-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
1001	2021-05-28 14:25:57.275682+00	381	Santiago (sede)-Matemática, con Orientación a la Enseñanza 	2	update through import_export	21	1
1002	2021-05-28 14:25:57.289182+00	382	Cibao Oriental (Nagua)-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
1003	2021-05-28 14:25:57.30208+00	383	Santo Domingo Oriental-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
1004	2021-05-28 14:25:57.315068+00	384	Santiago (sede)-Educación, Mención Historia y Geografía Segundo Ciclo 	2	update through import_export	21	1
1005	2021-05-28 14:25:57.329214+00	385	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
1006	2021-05-28 14:25:57.342482+00	386	Santo Domingo Oriental-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
1007	2021-05-28 14:25:57.356373+00	387	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario	2	update through import_export	21	1
1008	2021-05-28 14:25:57.369309+00	388	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
1009	2021-05-28 14:25:57.383115+00	389	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
1010	2021-05-28 14:25:57.396033+00	390	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	2	update through import_export	21	1
1011	2021-05-28 14:25:57.408858+00	391	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
1012	2021-05-28 14:25:57.420946+00	392	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
1013	2021-05-28 14:25:57.433488+00	393	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	2	update through import_export	21	1
1014	2021-05-28 14:25:57.44689+00	394	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
1015	2021-05-28 14:25:57.459782+00	395	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
1016	2021-05-28 14:25:57.472733+00	396	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	2	update through import_export	21	1
1017	2021-05-28 14:25:57.485632+00	397	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
1018	2021-05-28 14:25:57.499611+00	398	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
1019	2021-05-28 14:25:57.51226+00	399	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	2	update through import_export	21	1
1020	2021-05-28 14:25:57.530697+00	400	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
1076	2021-05-28 14:25:58.345908+00	25055	Santiago (sede)-Gestión de Centros Educativos  - MGC	1	new through import_export	21	1
1021	2021-05-28 14:25:57.551974+00	401	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
1022	2021-05-28 14:25:57.574535+00	402	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario.	2	update through import_export	21	1
1023	2021-05-28 14:25:57.59372+00	403	Cibao Oriental (Nagua)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
1024	2021-05-28 14:25:57.613621+00	404	Santo Domingo Oriental-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
1025	2021-05-28 14:25:57.634045+00	405	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos	2	update through import_export	21	1
1026	2021-05-28 14:25:57.654355+00	406	Cibao Oriental (Nagua)-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
1027	2021-05-28 14:25:57.676183+00	407	Santo Domingo Oriental-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
1028	2021-05-28 14:25:57.695607+00	408	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo	2	update through import_export	21	1
1029	2021-05-28 14:25:57.716589+00	409	Cibao Oriental (Nagua)-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
1030	2021-05-28 14:25:57.737065+00	410	Santo Domingo Oriental-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
1031	2021-05-28 14:25:57.749655+00	411	Santiago (sede)-Mercadeo, Mención  Mercadeo Politico	2	update through import_export	21	1
1032	2021-05-28 14:25:57.76245+00	418	Cibao Oriental (Nagua)-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
1033	2021-05-28 14:25:57.775972+00	419	Santo Domingo Oriental-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
1034	2021-05-28 14:25:57.789019+00	420	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos	2	update through import_export	21	1
1035	2021-05-28 14:25:57.802098+00	424	Cibao Oriental (Nagua)-Dirección Financiera 	2	update through import_export	21	1
1036	2021-05-28 14:25:57.815593+00	425	Santo Domingo Oriental-Dirección Financiera 	2	update through import_export	21	1
1037	2021-05-28 14:25:57.828608+00	426	Santiago (sede)-Dirección Financiera 	2	update through import_export	21	1
1038	2021-05-28 14:25:57.841971+00	427	Cibao Oriental (Nagua)-Legislación de Tierras 	2	update through import_export	21	1
1039	2021-05-28 14:25:57.855151+00	428	Santo Domingo Oriental-Legislación de Tierras 	2	update through import_export	21	1
1040	2021-05-28 14:25:57.867805+00	429	Santiago (sede)-Legislación de Tierras 	2	update through import_export	21	1
1041	2021-05-28 14:25:57.881546+00	430	Cibao Oriental (Nagua)-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
1042	2021-05-28 14:25:57.894525+00	431	Santo Domingo Oriental-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
1043	2021-05-28 14:25:57.907628+00	432	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos	2	update through import_export	21	1
1044	2021-05-28 14:25:57.921115+00	433	Cibao Oriental (Nagua)-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
1045	2021-05-28 14:25:57.934899+00	434	Santo Domingo Oriental-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
1046	2021-05-28 14:25:57.947631+00	435	Santiago (sede)-Gestión de la Tecnología Educativa 	2	update through import_export	21	1
1047	2021-05-28 14:25:57.960788+00	436	Cibao Oriental (Nagua)-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
1048	2021-05-28 14:25:57.973901+00	437	Santo Domingo Oriental-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
1049	2021-05-28 14:25:57.987887+00	438	Santiago (sede)-Gestion de Instituciones Educativas Virtuales	2	update through import_export	21	1
1050	2021-05-28 14:25:58.000718+00	439	Cibao Oriental (Nagua)-Derecho Constitucional	2	update through import_export	21	1
1051	2021-05-28 14:25:58.013654+00	440	Santo Domingo Oriental-Derecho Constitucional	2	update through import_export	21	1
1052	2021-05-28 14:25:58.026568+00	441	Santiago (sede)-Derecho Constitucional	2	update through import_export	21	1
1053	2021-05-28 14:25:58.040715+00	445	Cibao Oriental (Nagua)-Maestría en Terapia Familiar	2	update through import_export	21	1
1054	2021-05-28 14:25:58.054164+00	446	Santo Domingo Oriental-Maestría en Terapia Familiar	2	update through import_export	21	1
1055	2021-05-28 14:25:58.066789+00	447	Santiago (sede)-Maestría en Terapia Familiar	2	update through import_export	21	1
1056	2021-05-28 14:25:58.07991+00	448	Cibao Oriental (Nagua)- Innovación y Gestión Empresarial	2	update through import_export	21	1
1057	2021-05-28 14:25:58.093928+00	449	Santo Domingo Oriental- Innovación y Gestión Empresarial	2	update through import_export	21	1
1058	2021-05-28 14:25:58.106756+00	450	Santiago (sede)- Innovación y Gestión Empresarial	2	update through import_export	21	1
1059	2021-05-28 14:25:58.120433+00	451	Cibao Oriental (Nagua)-Dirección y Gestión Tributaria	2	update through import_export	21	1
1060	2021-05-28 14:25:58.133447+00	452	Santo Domingo Oriental-Dirección y Gestión Tributaria	2	update through import_export	21	1
1061	2021-05-28 14:25:58.146335+00	453	Santiago (sede)-Dirección y Gestión Tributaria	2	update through import_export	21	1
1062	2021-05-28 14:25:58.159798+00	454	Cibao Oriental (Nagua)-Ciberseguridad	2	update through import_export	21	1
1063	2021-05-28 14:25:58.173105+00	455	Santo Domingo Oriental-Ciberseguridad	2	update through import_export	21	1
1064	2021-05-28 14:25:58.186177+00	456	Santiago (sede)-Ciberseguridad	2	update through import_export	21	1
1065	2021-05-28 14:25:58.199216+00	457	Cibao Oriental (Nagua)-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
1066	2021-05-28 14:25:58.212701+00	458	Santo Domingo Oriental-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
1067	2021-05-28 14:25:58.225835+00	459	Santiago (sede)-Ciencias de la Educación (Dr.)	2	update through import_export	21	1
1068	2021-05-28 14:25:58.238915+00	24730	Cibao Oriental (Nagua)-Agrimensura	2	update through import_export	21	1
1069	2021-05-28 14:25:58.251897+00	24732	Santo Domingo Oriental-Agrimensura	2	update through import_export	21	1
1070	2021-05-28 14:25:58.266473+00	24735	Santiago (sede)-Agrimensura	2	update through import_export	21	1
1071	2021-05-28 14:25:58.279163+00	24834	Cibao Oriental (Nagua)-Enfermería - ENF	2	update through import_export	21	1
1072	2021-05-28 14:25:58.29228+00	24835	Santo Domingo Oriental-Enfermería - ENF	2	update through import_export	21	1
1073	2021-05-28 14:25:58.305381+00	24836	Santiago (sede)-Enfermería - ENF	2	update through import_export	21	1
1074	2021-05-28 14:25:58.318853+00	25053	Santiago (sede)-Gerencia de Recursos Humanos  - MGH	1	new through import_export	21	1
1077	2021-05-28 14:25:58.35921+00	25056	Santiago (sede)-Historia, con Orientación a la Enseñanza - MAH	1	new through import_export	21	1
1078	2021-05-28 14:25:58.373219+00	25057	Santiago (sede)-Informática, con Orientación a la Enseñanza  - EIN	1	new through import_export	21	1
1079	2021-05-28 14:25:58.386036+00	25058	Santiago (sede)-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
1080	2021-05-28 14:25:58.399431+00	25059	Santiago (sede)-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
1081	2021-05-28 14:25:58.412157+00	25060	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL	1	new through import_export	21	1
1082	2021-05-28 14:25:58.425832+00	25061	Santiago (sede)-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
1083	2021-05-28 14:25:58.438834+00	25062	Santiago (sede)-Matemática, con Orientación a la Enseñanza - EMA	1	new through import_export	21	1
1084	2021-05-28 14:25:58.451532+00	25063	Santiago (sede)-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
1085	2021-05-28 14:25:58.463827+00	25064	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM	1	new through import_export	21	1
1086	2021-05-28 14:25:58.476874+00	25065	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
1087	2021-05-28 14:25:58.490172+00	25066	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
1088	2021-05-28 14:25:58.502903+00	25067	Santiago (sede)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
1089	2021-05-28 14:25:58.515622+00	25068	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
1090	2021-05-28 14:25:58.531161+00	25069	Santiago (sede)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario	1	new through import_export	21	1
1091	2021-05-28 14:25:58.544263+00	25070	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC	1	new through import_export	21	1
1092	2021-05-28 14:25:58.557369+00	25071	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo - MMG	1	new through import_export	21	1
1093	2021-05-28 14:25:58.57027+00	25072	Santiago (sede)-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
1094	2021-05-28 14:25:58.583724+00	25073	Santiago (sede)-Educación Inicial  - MEI	1	new through import_export	21	1
1095	2021-05-28 14:25:58.596585+00	25074	Santiago (sede)-Psicología Clínica  - MPC	1	new through import_export	21	1
1096	2021-05-28 14:25:58.609776+00	25075	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP	1	new through import_export	21	1
1097	2021-05-28 14:25:58.622939+00	25076	Santiago (sede)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
1098	2021-05-28 14:25:58.635851+00	25077	Santiago (sede)-Dirección Financiera - MDF	1	new through import_export	21	1
1099	2021-05-28 14:25:58.649725+00	25078	Santiago (sede)-Legislación de Tierras  - MLT	1	new through import_export	21	1
1100	2021-05-28 14:25:58.662599+00	25079	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos  - MPP	1	new through import_export	21	1
1101	2021-05-28 14:25:58.675775+00	25080	Santiago (sede)-Gestión de la Tecnología Educativa - MGT	1	new through import_export	21	1
1102	2021-05-28 14:25:58.688944+00	25081	Santiago (sede)-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
1103	2021-05-28 14:25:58.702583+00	25082	Santiago (sede)-Derecho Constitucional - MDC	1	new through import_export	21	1
1104	2021-05-28 14:25:58.715367+00	25083	Santiago (sede)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
1105	2021-05-28 14:25:58.728401+00	25084	Santiago (sede)-Maestría en Terapia Familiar - MTF	1	new through import_export	21	1
1106	2021-05-28 14:25:58.744463+00	25085	Santiago (sede)-Innovación y Gestión Empresarial	1	new through import_export	21	1
1107	2021-05-28 14:25:58.763232+00	25086	Santiago (sede)-Dirección y Gestión Tributaria	1	new through import_export	21	1
1108	2021-05-28 14:25:58.783313+00	25087	Santiago (sede)-Ciberseguridad - MCS	1	new through import_export	21	1
1109	2021-05-28 14:25:58.803535+00	25088	Santiago (sede)-Ciencias de la Educación (Dr.)-DCE	1	new through import_export	21	1
1110	2021-05-28 14:25:58.822132+00	25089	Santo Domingo Oriental-Gerencia de Recursos Humanos  - MGH	1	new through import_export	21	1
1111	2021-05-28 14:25:58.840137+00	25090	Santo Domingo Oriental-Mercadeo (Postgrado)	1	new through import_export	21	1
1112	2021-05-28 14:25:58.860079+00	25091	Santo Domingo Oriental-Gestión de Centros Educativos  - MGC	1	new through import_export	21	1
1113	2021-05-28 14:25:58.8787+00	25092	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza - MAH	1	new through import_export	21	1
1114	2021-05-28 14:25:58.897586+00	25093	Santo Domingo Oriental-Informática, con Orientación a la Enseñanza  - EIN	1	new through import_export	21	1
1115	2021-05-28 14:25:58.918317+00	25094	Santo Domingo Oriental-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
1116	2021-05-28 14:25:58.938018+00	25095	Santo Domingo Oriental-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
1117	2021-05-28 14:25:58.957425+00	25096	Santo Domingo Oriental-Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL	1	new through import_export	21	1
1118	2021-05-28 14:25:58.97391+00	25097	Santo Domingo Oriental-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
1119	2021-05-28 14:25:58.987042+00	25098	Santo Domingo Oriental-Matemática, con Orientación a la Enseñanza - EMA	1	new through import_export	21	1
1120	2021-05-28 14:25:59.000244+00	25099	Santo Domingo Oriental-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
1121	2021-05-28 14:25:59.013082+00	25100	Santo Domingo Oriental-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM	1	new through import_export	21	1
1122	2021-05-28 14:25:59.026987+00	25101	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
1123	2021-05-28 14:25:59.040094+00	25102	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
1124	2021-05-28 14:25:59.054077+00	25103	Santo Domingo Oriental-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
1125	2021-05-28 14:25:59.068107+00	25104	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
1126	2021-05-28 14:25:59.080901+00	25105	Santo Domingo Oriental-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario	1	new through import_export	21	1
1127	2021-05-28 14:25:59.094213+00	25106	Santo Domingo Oriental-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC	1	new through import_export	21	1
1128	2021-05-28 14:25:59.107437+00	25107	Santo Domingo Oriental-Mercadeo, mencion Gerencia de mercadeo - MMG	1	new through import_export	21	1
1129	2021-05-28 14:25:59.120642+00	25108	Santo Domingo Oriental-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
1130	2021-05-28 14:25:59.134469+00	25109	Santo Domingo Oriental-Educación Inicial  - MEI	1	new through import_export	21	1
1131	2021-05-28 14:25:59.147039+00	25110	Santo Domingo Oriental-Psicología Clínica  - MPC	1	new through import_export	21	1
1132	2021-05-28 14:25:59.15962+00	25111	Santo Domingo Oriental-Derecho Civil y Procesal Civil Contemporáneos MCP	1	new through import_export	21	1
1133	2021-05-28 14:25:59.17259+00	25112	Santo Domingo Oriental-Gerencia de Recursos Humanos 	1	new through import_export	21	1
1134	2021-05-28 14:25:59.186409+00	25113	Santo Domingo Oriental-Dirección Financiera - MDF	1	new through import_export	21	1
1135	2021-05-28 14:25:59.199032+00	25114	Santo Domingo Oriental-Legislación de Tierras  - MLT	1	new through import_export	21	1
1136	2021-05-28 14:25:59.212319+00	25115	Santo Domingo Oriental-Derecho Penal y Procesal Penal Contemporáneos  - MPP	1	new through import_export	21	1
1137	2021-05-28 14:25:59.225296+00	25116	Santo Domingo Oriental-Gestión de la Tecnología Educativa - MGT	1	new through import_export	21	1
1138	2021-05-28 14:25:59.239501+00	25117	Santo Domingo Oriental-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
1139	2021-05-28 14:25:59.253168+00	25118	Santo Domingo Oriental-Derecho Constitucional - MDC	1	new through import_export	21	1
1140	2021-05-28 14:25:59.265563+00	25119	Santo Domingo Oriental-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
1141	2021-05-28 14:25:59.278877+00	25120	Santo Domingo Oriental-Maestría en Terapia Familiar - MTF	1	new through import_export	21	1
1142	2021-05-28 14:25:59.292579+00	25121	Santo Domingo Oriental-Innovación y Gestión Empresarial	1	new through import_export	21	1
1143	2021-05-28 14:25:59.305731+00	25122	Santo Domingo Oriental-Dirección y Gestión Tributaria	1	new through import_export	21	1
1144	2021-05-28 14:25:59.319143+00	25123	Santo Domingo Oriental-Ciberseguridad - MCS	1	new through import_export	21	1
1145	2021-05-28 14:25:59.33151+00	25124	Santo Domingo Oriental-Ciencias de la Educación (Dr.)-DCE	1	new through import_export	21	1
1146	2021-05-28 14:25:59.346393+00	25125	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos  - MGH	1	new through import_export	21	1
1147	2021-05-28 14:25:59.359474+00	25126	Cibao Oriental (Nagua)-Mercadeo (Postgrado)	1	new through import_export	21	1
1148	2021-05-28 14:25:59.372748+00	25127	Cibao Oriental (Nagua)-Gestión de Centros Educativos  - MGC	1	new through import_export	21	1
1149	2021-05-28 14:25:59.386189+00	25128	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza - MAH	1	new through import_export	21	1
1150	2021-05-28 14:25:59.399158+00	25129	Cibao Oriental (Nagua)-Informática, con Orientación a la Enseñanza  - EIN	1	new through import_export	21	1
1151	2021-05-28 14:25:59.413235+00	25130	Cibao Oriental (Nagua)-Biología, con Orientación a la Enseñanza 	1	new through import_export	21	1
1152	2021-05-28 14:25:59.426268+00	25131	Cibao Oriental (Nagua)-Educación, Mención Lengua Española, Segundo Ciclo 	1	new through import_export	21	1
1153	2021-05-28 14:25:59.43922+00	25132	Cibao Oriental (Nagua)-Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL	1	new through import_export	21	1
1154	2021-05-28 14:25:59.45256+00	25133	Cibao Oriental (Nagua)-Educación, Matemática Física, Segundo Ciclo 	1	new through import_export	21	1
1155	2021-05-28 14:25:59.46591+00	25134	Cibao Oriental (Nagua)-Matemática, con Orientación a la Enseñanza - EMA	1	new through import_export	21	1
1156	2021-05-28 14:25:59.479224+00	25135	Cibao Oriental (Nagua)-Educación, Mención Historia y Geografía Segundo Ciclo 	1	new through import_export	21	1
1157	2021-05-28 14:25:59.4921+00	25136	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM	1	new through import_export	21	1
1158	2021-05-28 14:25:59.5049+00	25137	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Teatro, Nivel Secundario	1	new through import_export	21	1
1159	2021-05-28 14:25:59.518702+00	25138	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Artes Plásticas, Nivel Secundario	1	new through import_export	21	1
1160	2021-05-28 14:25:59.530864+00	25139	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  para modalidad Educación Musical, Nivel Secundario	1	new through import_export	21	1
1161	2021-05-28 14:25:59.543861+00	25140	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Ingles), para Nivel Secundario	1	new through import_export	21	1
1162	2021-05-28 14:25:59.556554+00	25141	Cibao Oriental (Nagua)-Especialidad en Habilitación Docente:  Lenguas Extranjeras (Frances), para Nivel Secundario	1	new through import_export	21	1
1163	2021-05-28 14:25:59.570788+00	25142	Cibao Oriental (Nagua)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC	1	new through import_export	21	1
1164	2021-05-28 14:25:59.58384+00	25143	Cibao Oriental (Nagua)-Mercadeo, mencion Gerencia de mercadeo - MMG	1	new through import_export	21	1
1165	2021-05-28 14:25:59.596651+00	25144	Cibao Oriental (Nagua)-Mercadeo, Mención  Mercadeo Politico	1	new through import_export	21	1
1166	2021-05-28 14:25:59.609891+00	25145	Cibao Oriental (Nagua)-Educación Inicial  - MEI	1	new through import_export	21	1
1167	2021-05-28 14:25:59.624648+00	25146	Cibao Oriental (Nagua)-Psicología Clínica  - MPC	1	new through import_export	21	1
1168	2021-05-28 14:25:59.638354+00	25147	Cibao Oriental (Nagua)-Derecho Civil y Procesal Civil Contemporáneos MCP	1	new through import_export	21	1
1169	2021-05-28 14:25:59.651175+00	25148	Cibao Oriental (Nagua)-Gerencia de Recursos Humanos 	1	new through import_export	21	1
1170	2021-05-28 14:25:59.664029+00	25149	Cibao Oriental (Nagua)-Dirección Financiera - MDF	1	new through import_export	21	1
1171	2021-05-28 14:25:59.677341+00	25150	Cibao Oriental (Nagua)-Legislación de Tierras  - MLT	1	new through import_export	21	1
1172	2021-05-28 14:25:59.690705+00	25151	Cibao Oriental (Nagua)-Derecho Penal y Procesal Penal Contemporáneos  - MPP	1	new through import_export	21	1
1173	2021-05-28 14:25:59.704487+00	25152	Cibao Oriental (Nagua)-Gestión de la Tecnología Educativa - MGT	1	new through import_export	21	1
1174	2021-05-28 14:25:59.717229+00	25153	Cibao Oriental (Nagua)-Gestion de Instituciones Educativas Virtuales	1	new through import_export	21	1
1175	2021-05-28 14:25:59.730339+00	25154	Cibao Oriental (Nagua)-Derecho Constitucional - MDC	1	new through import_export	21	1
1176	2021-05-28 14:25:59.743757+00	25155	Cibao Oriental (Nagua)-Historia, con Orientación a la Enseñanza 	1	new through import_export	21	1
1177	2021-05-28 14:25:59.756978+00	25156	Cibao Oriental (Nagua)-Maestría en Terapia Familiar - MTF	1	new through import_export	21	1
1178	2021-05-28 14:25:59.770105+00	25157	Cibao Oriental (Nagua)-Innovación y Gestión Empresarial	1	new through import_export	21	1
1179	2021-05-28 14:25:59.782525+00	25158	Cibao Oriental (Nagua)-Dirección y Gestión Tributaria	1	new through import_export	21	1
1180	2021-05-28 14:25:59.796639+00	25159	Cibao Oriental (Nagua)-Ciberseguridad - MCS	1	new through import_export	21	1
1181	2021-05-28 14:25:59.809639+00	25160	Cibao Oriental (Nagua)-Ciencias de la Educación (Dr.)-DCE	1	new through import_export	21	1
1182	2021-05-28 14:29:06.074496+00	1528	Santo Domingo Oriental-Gerencia de Recursos Humanos  - MGH-2019-Anual-218.000	1	new through import_export	25	1
1183	2021-05-28 14:29:06.089304+00	1527	Santiago (sede)-Ciberseguridad - MCS-2019-Anual-23.000	1	new through import_export	25	1
1184	2021-05-28 14:29:06.102628+00	1526	Santiago (sede)-Maestría en Terapia Familiar - MTF-2019-Anual-48.000	1	new through import_export	25	1
1185	2021-05-28 14:29:06.116299+00	1525	Santiago (sede)-Derecho Constitucional - MDC-2019-Anual-16.000	1	new through import_export	25	1
1186	2021-05-28 14:29:06.12933+00	1524	Santiago (sede)-Gestión de la Tecnología Educativa - MGT-2019-Anual-140.000	1	new through import_export	25	1
1187	2021-05-28 14:29:06.148321+00	1523	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos  - MPP-2019-Anual-82.000	1	new through import_export	25	1
1188	2021-05-28 14:29:06.163186+00	1522	Santiago (sede)-Legislación de Tierras  - MLT-2019-Anual-26.000	1	new through import_export	25	1
1189	2021-05-28 14:29:06.176713+00	1521	Santiago (sede)-Dirección Financiera - MDF-2019-Anual-50.000	1	new through import_export	25	1
1190	2021-05-28 14:29:06.18986+00	1520	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP-2019-Anual-42.000	1	new through import_export	25	1
1191	2021-05-28 14:29:06.202927+00	1519	Santiago (sede)-Psicología Clínica  - MPC-2019-Anual-37.000	1	new through import_export	25	1
1192	2021-05-28 14:29:06.216616+00	1518	Santiago (sede)-Educación Inicial  - MEI-2019-Anual-40.000	1	new through import_export	25	1
1193	2021-05-28 14:29:06.229553+00	1517	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo - MMG-2019-Anual-17.000	1	new through import_export	25	1
1194	2021-05-28 14:29:06.244136+00	1516	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM-2019-Anual-33.000	1	new through import_export	25	1
1195	2021-05-28 14:29:06.258656+00	1515	Santiago (sede)-Matemática, con Orientación a la Enseñanza - EMA-2019-Anual-59.000	1	new through import_export	25	1
1196	2021-05-28 14:29:06.272409+00	1514	Santiago (sede)-Informática, con Orientación a la Enseñanza  - EIN-2019-Anual-251.000	1	new through import_export	25	1
1197	2021-05-28 14:29:06.286137+00	1513	Santiago (sede)-Historia, con Orientación a la Enseñanza - MAH-2019-Anual-36.000	1	new through import_export	25	1
1198	2021-05-28 14:29:06.299062+00	1512	Santiago (sede)-Gestión de Centros Educativos  - MGC-2019-Anual-170.000	1	new through import_export	25	1
1199	2021-05-28 14:29:06.312088+00	1511	Santiago (sede)-Gerencia de Recursos Humanos  - MGH-2019-Anual-48.000	1	new through import_export	25	1
1200	2021-05-28 14:29:06.326298+00	1510	Santo Domingo Oriental-Gerencia de Recursos Humanos  - MGH-2018-Anual-278.000	1	new through import_export	25	1
1201	2021-05-28 14:29:06.345764+00	1509	Santiago (sede)-Maestría en Terapia Familiar - MTF-2018-Anual-141.000	1	new through import_export	25	1
1202	2021-05-28 14:29:06.36568+00	1508	Santiago (sede)-Derecho Constitucional - MDC-2018-Anual-43.000	1	new through import_export	25	1
1203	2021-05-28 14:29:06.385682+00	1507	Santiago (sede)-Gestión de la Tecnología Educativa - MGT-2018-Anual-198.000	1	new through import_export	25	1
1204	2021-05-28 14:29:06.406065+00	1506	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos  - MPP-2018-Anual-106.000	1	new through import_export	25	1
1205	2021-05-28 14:29:06.425454+00	1505	Santiago (sede)-Legislación de Tierras  - MLT-2018-Anual-65.000	1	new through import_export	25	1
1206	2021-05-28 14:29:06.444922+00	1504	Santiago (sede)-Dirección Financiera - MDF-2018-Anual-127.000	1	new through import_export	25	1
1207	2021-05-28 14:29:06.464544+00	1503	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP-2018-Anual-35.000	1	new through import_export	25	1
1208	2021-05-28 14:29:06.484903+00	1502	Santiago (sede)-Psicología Clínica  - MPC-2018-Anual-112.000	1	new through import_export	25	1
1209	2021-05-28 14:29:06.504468+00	1501	Santiago (sede)-Educación Inicial  - MEI-2018-Anual-58.000	1	new through import_export	25	1
1210	2021-05-28 14:29:06.524195+00	1500	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC-2018-Anual-79.000	1	new through import_export	25	1
1211	2021-05-28 14:29:06.544543+00	1499	Santiago (sede)-Especialidad en Habilitación Docente: para Matemática, Nivel Secundario - EHM-2018-Anual-44.000	1	new through import_export	25	1
1212	2021-05-28 14:29:06.559867+00	1498	Santiago (sede)-Matemática, con Orientación a la Enseñanza - EMA-2018-Anual-69.000	1	new through import_export	25	1
1213	2021-05-28 14:29:06.572784+00	1497	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL-2018-Anual-40.000	1	new through import_export	25	1
1214	2021-05-28 14:29:06.585581+00	1496	Santiago (sede)-Informática, con Orientación a la Enseñanza  - EIN-2018-Anual-111.000	1	new through import_export	25	1
1215	2021-05-28 14:29:06.600028+00	1495	Santiago (sede)-Historia, con Orientación a la Enseñanza - MAH-2018-Anual-81.000	1	new through import_export	25	1
1216	2021-05-28 14:29:06.612804+00	1494	Santiago (sede)-Gestión de Centros Educativos  - MGC-2018-Anual-239.000	1	new through import_export	25	1
1217	2021-05-28 14:29:06.625603+00	1493	Santiago (sede)-Gerencia de Recursos Humanos  - MGH-2018-Anual-95.000	1	new through import_export	25	1
1218	2021-05-28 14:29:06.638478+00	1492	Santo Domingo Oriental-Gerencia de Recursos Humanos  - MGH-2017-Anual-235.000	1	new through import_export	25	1
1219	2021-05-28 14:29:06.652703+00	1491	Santiago (sede)-Ciencias de la Educación (Dr.)-DCE-2017-Anual-38.000	1	new through import_export	25	1
1220	2021-05-28 14:29:06.665403+00	1490	Santiago (sede)-Maestría en Terapia Familiar - MTF-2017-Anual-1.000	1	new through import_export	25	1
1221	2021-05-28 14:29:06.679412+00	1489	Santiago (sede)-Gestión de la Tecnología Educativa - MGT-2017-Anual-137.000	1	new through import_export	25	1
1222	2021-05-28 14:29:06.692758+00	1488	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos  - MPP-2017-Anual-56.000	1	new through import_export	25	1
1223	2021-05-28 14:29:06.707357+00	1487	Santiago (sede)-Dirección Financiera - MDF-2017-Anual-78.000	1	new through import_export	25	1
1224	2021-05-28 14:29:06.720564+00	1486	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP-2017-Anual-32.000	1	new through import_export	25	1
1225	2021-05-28 14:29:06.734297+00	1485	Santiago (sede)-Psicología Clínica  - MPC-2017-Anual-59.000	1	new through import_export	25	1
1226	2021-05-28 14:29:06.749926+00	1484	Santiago (sede)-Educación Inicial  - MEI-2017-Anual-83.000	1	new through import_export	25	1
1227	2021-05-28 14:29:06.76397+00	1483	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo - MMG-2017-Anual-17.000	1	new through import_export	25	1
1228	2021-05-28 14:29:06.777769+00	1482	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC-2017-Anual-101.000	1	new through import_export	25	1
1229	2021-05-28 14:29:06.791349+00	1481	Santiago (sede)-Lengua Española y Literatura, con Orientación a la Enseñanza  - ELL-2017-Anual-33.000	1	new through import_export	25	1
1230	2021-05-28 14:29:06.804658+00	1480	Santiago (sede)-Informática, con Orientación a la Enseñanza  - EIN-2017-Anual-154.000	1	new through import_export	25	1
1231	2021-05-28 14:29:06.818162+00	1479	Santiago (sede)-Gestión de Centros Educativos  - MGC-2017-Anual-177.000	1	new through import_export	25	1
1232	2021-05-28 14:29:06.8305+00	1478	Santiago (sede)-Gerencia de Recursos Humanos  - MGH-2017-Anual-49.000	1	new through import_export	25	1
1233	2021-05-28 14:29:06.84352+00	1477	Santo Domingo Oriental-Gerencia de Recursos Humanos  - MGH-2021-Anual-376.000	1	new through import_export	25	1
1234	2021-05-28 14:29:06.856707+00	1476	Santiago (sede)-Maestría en Terapia Familiar - MTF-2021-Anual-59.000	1	new through import_export	25	1
1235	2021-05-28 14:29:06.871045+00	1475	Santiago (sede)-Derecho Constitucional - MDC-2021-Anual-29.000	1	new through import_export	25	1
1236	2021-05-28 14:29:06.884469+00	1474	Santiago (sede)-Derecho Penal y Procesal Penal Contemporáneos  - MPP-2021-Anual-50.000	1	new through import_export	25	1
1237	2021-05-28 14:29:06.897037+00	1473	Santiago (sede)-Legislación de Tierras  - MLT-2021-Anual-41.000	1	new through import_export	25	1
1238	2021-05-28 14:29:06.910259+00	1472	Santiago (sede)-Dirección Financiera - MDF-2021-Anual-94.000	1	new through import_export	25	1
1239	2021-05-28 14:29:06.924122+00	1471	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP-2021-Anual-47.000	1	new through import_export	25	1
1240	2021-05-28 14:29:06.938016+00	1470	Santiago (sede)-Psicología Clínica  - MPC-2021-Anual-27.000	1	new through import_export	25	1
1241	2021-05-28 14:29:06.951071+00	1469	Santiago (sede)-Educación Inicial  - MEI-2021-Anual-55.000	1	new through import_export	25	1
1242	2021-05-28 14:29:06.963331+00	1468	Santiago (sede)-Mercadeo, mencion Gerencia de mercadeo - MMG-2021-Anual-18.000	1	new through import_export	25	1
1243	2021-05-28 14:29:06.976448+00	1467	Santiago (sede)-Gestión de Centros Educativos  - MGC-2021-Anual-363.000	1	new through import_export	25	1
1244	2021-05-28 14:29:06.98956+00	1466	Santiago (sede)-Gerencia de Recursos Humanos  - MGH-2021-Anual-225.000	1	new through import_export	25	1
1245	2021-05-28 14:29:07.002958+00	1465	Santiago (sede)-Derecho Constitucional - MDC-2020-Anual-34.000	1	new through import_export	25	1
1246	2021-05-28 14:29:07.015522+00	1464	Santiago (sede)-Gestión de la Tecnología Educativa - MGT-2020-Anual-301.000	1	new through import_export	25	1
1247	2021-05-28 14:29:07.029667+00	1463	Santiago (sede)-Legislación de Tierras  - MLT-2020-Anual-55.000	1	new through import_export	25	1
1248	2021-05-28 14:29:07.042876+00	1462	Santiago (sede)-Dirección Financiera - MDF-2020-Anual-152.000	1	new through import_export	25	1
1249	2021-05-28 14:29:07.056003+00	1461	Santiago (sede)-Derecho Civil y Procesal Civil Contemporáneos MCP-2020-Anual-103.000	1	new through import_export	25	1
1250	2021-05-28 14:29:07.069403+00	1460	Santiago (sede)-Psicología Clínica  - MPC-2020-Anual-19.000	1	new through import_export	25	1
1251	2021-05-28 14:29:07.082008+00	1459	Santiago (sede)-Educación Inicial  - MEI-2020-Anual-123.000	1	new through import_export	25	1
1252	2021-05-28 14:29:07.096279+00	1458	Santiago (sede)-Ciencias de la Educacion, Mencion Gestion de Centros Educativos - EGC-2020-Anual-353.000	1	new through import_export	25	1
1253	2021-05-28 14:29:07.109442+00	1457	Santiago (sede)-Informática, con Orientación a la Enseñanza  - EIN-2020-Anual-25.000	1	new through import_export	25	1
1254	2021-05-28 14:29:07.122725+00	1456	Santiago (sede)-Mercadeo (Postgrado)-2020-Anual-31.000	1	new through import_export	25	1
1255	2021-05-28 14:29:07.136155+00	1455	Santiago (sede)-Gerencia de Recursos Humanos  - MGH-2020-Anual-90.000	1	new through import_export	25	1
1256	2021-05-28 14:29:07.149563+00	1380	Cibao Oriental (Nagua)-Enfermería - ENF-2019-Anual-101.000	2	update through import_export	25	1
1257	2021-05-28 14:29:07.162899+00	1379	Cibao Oriental (Nagua)-Psicología -2019-Anual-64.000	2	update through import_export	25	1
1258	2021-05-28 14:29:07.175783+00	1378	Cibao Oriental (Nagua)-Psicología Educativa -2019-Anual-156.000	2	update through import_export	25	1
1259	2021-05-28 14:29:07.188824+00	1377	Cibao Oriental (Nagua)-Contabilidad Empresarial -2019-Anual-74.000	2	update through import_export	25	1
1260	2021-05-28 14:29:07.202698+00	1376	Cibao Oriental (Nagua)-Administración de Empresas -2019-Anual-41.000	2	update through import_export	25	1
1261	2021-05-28 14:29:07.215571+00	1375	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2019-Anual-58.000	2	update through import_export	25	1
1262	2021-05-28 14:29:07.228975+00	1374	Cibao Oriental (Nagua)-Informática Gerencial -2019-Anual-39.000	2	update through import_export	25	1
1263	2021-05-28 14:29:07.241733+00	1373	Cibao Oriental (Nagua)-Derecho-2019-Anual-59.000	2	update through import_export	25	1
1264	2021-05-28 14:29:07.255709+00	1372	Santo Domingo Oriental-Periodismo digital-2019-Anual-10.000	2	update through import_export	25	1
1265	2021-05-28 14:29:07.269625+00	1371	Santo Domingo Oriental-Psicología Industrial -2019-Anual-146.000	2	update through import_export	25	1
1266	2021-05-28 14:29:07.282827+00	1370	Santo Domingo Oriental-Psicología -2019-Anual-42.000	2	update through import_export	25	1
1267	2021-05-28 14:29:07.295926+00	1369	Santo Domingo Oriental-Psicología Educativa -2019-Anual-296.000	2	update through import_export	25	1
1268	2021-05-28 14:29:07.309471+00	1368	Santo Domingo Oriental-Psicología Clínica -2019-Anual-114.000	2	update through import_export	25	1
1269	2021-05-28 14:29:07.322149+00	1367	Santo Domingo Oriental-Administración de Empresas Turísticas -2019-Anual-1.000	2	update through import_export	25	1
1270	2021-05-28 14:29:07.33454+00	1366	Santo Domingo Oriental-Mercadeo -2019-Anual-102.000	2	update through import_export	25	1
1271	2021-05-28 14:29:07.346692+00	1365	Santo Domingo Oriental-Contabilidad Empresarial -2019-Anual-212.000	2	update through import_export	25	1
1272	2021-05-28 14:29:07.360264+00	1364	Santo Domingo Oriental-Administración de Empresas -2019-Anual-142.000	2	update through import_export	25	1
1273	2021-05-28 14:29:07.373248+00	1363	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2019-Anual-99.000	2	update through import_export	25	1
1274	2021-05-28 14:29:07.386732+00	1362	Santo Domingo Oriental-Ingeniería en Software -2019-Anual-106.000	2	update through import_export	25	1
1275	2021-05-28 14:29:07.399278+00	1361	Santo Domingo Oriental-Informática Gerencial -2019-Anual-39.000	2	update through import_export	25	1
1276	2021-05-28 14:29:07.412929+00	1360	Santo Domingo Oriental-Derecho-2019-Anual-334.000	2	update through import_export	25	1
1277	2021-05-28 14:29:07.426075+00	1359	Santiago (sede)-Periodismo digital-2019-Anual-8.000	2	update through import_export	25	1
1278	2021-05-28 14:29:07.439221+00	1358	Santiago (sede)-Enfermería - ENF-2019-Anual-86.000	2	update through import_export	25	1
1279	2021-05-28 14:29:07.452497+00	1357	Santiago (sede)-Psicología Industrial -2019-Anual-73.000	2	update through import_export	25	1
1280	2021-05-28 14:29:07.466232+00	1356	Santiago (sede)-Psicología -2019-Anual-79.000	2	update through import_export	25	1
1281	2021-05-28 14:29:07.481029+00	1355	Santiago (sede)-Psicología Educativa -2019-Anual-238.000	2	update through import_export	25	1
1282	2021-05-28 14:29:07.49727+00	1354	Santiago (sede)-Psicología Clínica -2019-Anual-96.000	2	update through import_export	25	1
1283	2021-05-28 14:29:07.510576+00	1353	Santiago (sede)-Administración de Empresas Turísticas -2019-Anual-26.000	2	update through import_export	25	1
1284	2021-05-28 14:29:07.524648+00	1352	Santiago (sede)-Mercadeo -2019-Anual-131.000	2	update through import_export	25	1
1285	2021-05-28 14:29:07.538059+00	1351	Santiago (sede)-Contabilidad Empresarial -2019-Anual-201.000	2	update through import_export	25	1
1286	2021-05-28 14:29:07.550973+00	1350	Santiago (sede)-Administración de Empresas -2019-Anual-162.000	2	update through import_export	25	1
1287	2021-05-28 14:29:07.57228+00	1349	Santiago (sede)-Lenguas Modernas Mención Turismo -2019-Anual-94.000	2	update through import_export	25	1
1288	2021-05-28 14:29:07.592108+00	1348	Santiago (sede)-Ingeniería en Software -2019-Anual-175.000	2	update through import_export	25	1
1289	2021-05-28 14:29:07.612943+00	1347	Santiago (sede)-Informática Gerencial -2019-Anual-25.000	2	update through import_export	25	1
1290	2021-05-28 14:29:07.633141+00	1346	Santiago (sede)-Derecho-2019-Anual-211.000	2	update through import_export	25	1
1291	2021-05-28 14:29:07.656129+00	1270	Cibao Oriental (Nagua)-Psicología -2018-Anual-78.000	2	update through import_export	25	1
1292	2021-05-28 14:29:07.676094+00	1269	Cibao Oriental (Nagua)-Psicología Educativa -2018-Anual-223.000	2	update through import_export	25	1
1293	2021-05-28 14:29:07.695999+00	1268	Cibao Oriental (Nagua)-Contabilidad Empresarial -2018-Anual-137.000	2	update through import_export	25	1
1294	2021-05-28 14:29:07.716801+00	1267	Cibao Oriental (Nagua)-Administración de Empresas -2018-Anual-66.000	2	update through import_export	25	1
1295	2021-05-28 14:29:07.742366+00	1266	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2018-Anual-90.000	2	update through import_export	25	1
1296	2021-05-28 14:29:07.76142+00	1265	Cibao Oriental (Nagua)-Informática Gerencial -2018-Anual-31.000	2	update through import_export	25	1
1297	2021-05-28 14:29:07.77929+00	1264	Cibao Oriental (Nagua)-Derecho-2018-Anual-83.000	2	update through import_export	25	1
1298	2021-05-28 14:29:07.793284+00	1263	Santo Domingo Oriental-Psicología Industrial -2018-Anual-192.000	2	update through import_export	25	1
1299	2021-05-28 14:29:07.806177+00	1262	Santo Domingo Oriental-Psicología -2018-Anual-38.000	2	update through import_export	25	1
1300	2021-05-28 14:29:07.819395+00	1261	Santo Domingo Oriental-Psicología Educativa -2018-Anual-399.000	2	update through import_export	25	1
1301	2021-05-28 14:29:07.832615+00	1260	Santo Domingo Oriental-Psicología Clínica -2018-Anual-192.000	2	update through import_export	25	1
1302	2021-05-28 14:29:07.846149+00	1259	Santo Domingo Oriental-Mercadeo -2018-Anual-142.000	2	update through import_export	25	1
1303	2021-05-28 14:29:07.859641+00	1258	Santo Domingo Oriental-Contabilidad Empresarial -2018-Anual-352.000	2	update through import_export	25	1
1304	2021-05-28 14:29:07.872554+00	1257	Santo Domingo Oriental-Administración de Empresas -2018-Anual-222.000	2	update through import_export	25	1
1305	2021-05-28 14:29:07.885965+00	1256	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2018-Anual-76.000	2	update through import_export	25	1
1306	2021-05-28 14:29:07.89987+00	1255	Santo Domingo Oriental-Ingeniería en Software -2018-Anual-208.000	2	update through import_export	25	1
1307	2021-05-28 14:29:07.912717+00	1254	Santo Domingo Oriental-Informática Gerencial -2018-Anual-23.000	2	update through import_export	25	1
1308	2021-05-28 14:29:07.927096+00	1253	Santo Domingo Oriental-Derecho-2018-Anual-482.000	2	update through import_export	25	1
1309	2021-05-28 14:29:07.940729+00	1252	Santiago (sede)-Psicología Industrial -2018-Anual-68.000	2	update through import_export	25	1
1310	2021-05-28 14:29:07.955092+00	1251	Santiago (sede)-Psicología -2018-Anual-153.000	2	update through import_export	25	1
1311	2021-05-28 14:29:07.968819+00	1250	Santiago (sede)-Psicología Educativa -2018-Anual-425.000	2	update through import_export	25	1
1312	2021-05-28 14:29:07.983035+00	1249	Santiago (sede)-Psicología Clínica -2018-Anual-180.000	2	update through import_export	25	1
1313	2021-05-28 14:29:07.998444+00	1248	Santiago (sede)-Administración de Empresas Turísticas -2018-Anual-25.000	2	update through import_export	25	1
1314	2021-05-28 14:29:08.016948+00	1247	Santiago (sede)-Mercadeo -2018-Anual-180.000	2	update through import_export	25	1
1315	2021-05-28 14:29:08.035869+00	1246	Santiago (sede)-Contabilidad Empresarial -2018-Anual-341.000	2	update through import_export	25	1
1316	2021-05-28 14:29:08.051329+00	1245	Santiago (sede)-Administración de Empresas -2018-Anual-218.000	2	update through import_export	25	1
1317	2021-05-28 14:29:08.066605+00	1244	Santiago (sede)-Lenguas Modernas Mención Turismo -2018-Anual-140.000	2	update through import_export	25	1
1318	2021-05-28 14:29:08.080545+00	1243	Santiago (sede)-Ingeniería en Software -2018-Anual-259.000	2	update through import_export	25	1
1319	2021-05-28 14:29:08.094928+00	1242	Santiago (sede)-Informática Gerencial -2018-Anual-15.000	2	update through import_export	25	1
1320	2021-05-28 14:29:08.109774+00	1241	Santiago (sede)-Derecho-2018-Anual-303.000	2	update through import_export	25	1
1321	2021-05-28 14:29:08.124081+00	1148	Cibao Oriental (Nagua)-Periodismo digital-2017-Anual-1.000	2	update through import_export	25	1
1322	2021-05-28 14:29:08.138717+00	1147	Cibao Oriental (Nagua)-Psicología -2017-Anual-150.000	2	update through import_export	25	1
1323	2021-05-28 14:29:08.153439+00	1146	Cibao Oriental (Nagua)-Psicología Educativa -2017-Anual-450.000	2	update through import_export	25	1
1324	2021-05-28 14:29:08.167879+00	1145	Cibao Oriental (Nagua)-Contabilidad Empresarial -2017-Anual-176.000	2	update through import_export	25	1
1325	2021-05-28 14:29:08.182676+00	1144	Cibao Oriental (Nagua)-Administración de Empresas -2017-Anual-97.000	2	update through import_export	25	1
1326	2021-05-28 14:29:08.197144+00	1143	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2017-Anual-128.000	2	update through import_export	25	1
1327	2021-05-28 14:29:08.212259+00	1142	Cibao Oriental (Nagua)-Informática Gerencial -2017-Anual-84.000	2	update through import_export	25	1
1328	2021-05-28 14:29:08.226972+00	1141	Cibao Oriental (Nagua)-Derecho-2017-Anual-105.000	2	update through import_export	25	1
1329	2021-05-28 14:29:08.241676+00	1140	Santo Domingo Oriental-Periodismo digital-2017-Anual-24.000	2	update through import_export	25	1
1330	2021-05-28 14:29:08.256057+00	1139	Santo Domingo Oriental-Psicología Industrial -2017-Anual-283.000	2	update through import_export	25	1
1331	2021-05-28 14:29:08.270211+00	1138	Santo Domingo Oriental-Psicología -2017-Anual-81.000	2	update through import_export	25	1
1332	2021-05-28 14:29:08.285227+00	1137	Santo Domingo Oriental-Psicología Educativa -2017-Anual-757.000	2	update through import_export	25	1
1333	2021-05-28 14:29:08.300123+00	1136	Santo Domingo Oriental-Psicología Clínica -2017-Anual-249.000	2	update through import_export	25	1
1334	2021-05-28 14:29:08.314476+00	1135	Santo Domingo Oriental-Mercadeo -2017-Anual-220.000	2	update through import_export	25	1
1335	2021-05-28 14:29:08.329385+00	1134	Santo Domingo Oriental-Contabilidad Empresarial -2017-Anual-581.000	2	update through import_export	25	1
1336	2021-05-28 14:29:08.344809+00	1133	Santo Domingo Oriental-Administración de Empresas -2017-Anual-309.000	2	update through import_export	25	1
1337	2021-05-28 14:29:08.359437+00	1132	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2017-Anual-324.000	2	update through import_export	25	1
1338	2021-05-28 14:29:08.374027+00	1131	Santo Domingo Oriental-Ingeniería en Software -2017-Anual-248.000	2	update through import_export	25	1
1339	2021-05-28 14:29:08.388458+00	1130	Santo Domingo Oriental-Informática Gerencial -2017-Anual-83.000	2	update through import_export	25	1
1340	2021-05-28 14:29:08.402981+00	1129	Santo Domingo Oriental-Derecho-2017-Anual-599.000	2	update through import_export	25	1
1341	2021-05-28 14:29:08.417755+00	1128	Santiago (sede)-Periodismo digital-2017-Anual-9.000	2	update through import_export	25	1
1342	2021-05-28 14:29:08.43237+00	1127	Santiago (sede)-Psicología Industrial -2017-Anual-112.000	2	update through import_export	25	1
1343	2021-05-28 14:29:08.447275+00	1126	Santiago (sede)-Psicología -2017-Anual-199.000	2	update through import_export	25	1
1344	2021-05-28 14:29:08.461978+00	1125	Santiago (sede)-Psicología Educativa -2017-Anual-753.000	2	update through import_export	25	1
1345	2021-05-28 14:29:08.476443+00	1124	Santiago (sede)-Psicología Clínica -2017-Anual-184.000	2	update through import_export	25	1
1346	2021-05-28 14:29:08.491718+00	1123	Santiago (sede)-Administración de Empresas Turísticas -2017-Anual-81.000	2	update through import_export	25	1
1347	2021-05-28 14:29:08.506198+00	1122	Santiago (sede)-Mercadeo -2017-Anual-296.000	2	update through import_export	25	1
1348	2021-05-28 14:29:08.520099+00	1121	Santiago (sede)-Contabilidad Empresarial -2017-Anual-478.000	2	update through import_export	25	1
1349	2021-05-28 14:29:08.534046+00	1120	Santiago (sede)-Administración de Empresas -2017-Anual-252.000	2	update through import_export	25	1
1350	2021-05-28 14:29:08.548085+00	1119	Santiago (sede)-Lenguas Modernas Mención Turismo -2017-Anual-240.000	2	update through import_export	25	1
1351	2021-05-28 14:29:08.563249+00	1118	Santiago (sede)-Ingeniería en Software -2017-Anual-320.000	2	update through import_export	25	1
1352	2021-05-28 14:29:08.577566+00	1117	Santiago (sede)-Informática Gerencial -2017-Anual-74.000	2	update through import_export	25	1
1353	2021-05-28 14:29:08.592592+00	1116	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria-2017-Anual-17.000	2	update through import_export	25	1
1354	2021-05-28 14:29:08.607212+00	1115	Santiago (sede)-Derecho-2017-Anual-458.000	2	update through import_export	25	1
1355	2021-05-28 14:29:08.621768+00	1080	Cibao Oriental (Nagua)-Periodismo digital-2021-Anual-2.000	2	update through import_export	25	1
1356	2021-05-28 14:29:08.636778+00	1079	Cibao Oriental (Nagua)-Psicología -2021-Anual-136.000	2	update through import_export	25	1
1357	2021-05-28 14:29:08.651511+00	1078	Cibao Oriental (Nagua)-Psicología Educativa -2021-Anual-532.000	2	update through import_export	25	1
1358	2021-05-28 14:29:08.666315+00	1077	Cibao Oriental (Nagua)-Administración de Empresas Turísticas -2021-Anual-23.000	2	update through import_export	25	1
1359	2021-05-28 14:29:08.680883+00	1076	Cibao Oriental (Nagua)-Mercadeo -2021-Anual-27.000	2	update through import_export	25	1
1360	2021-05-28 14:29:08.695659+00	1075	Cibao Oriental (Nagua)-Contabilidad Empresarial -2021-Anual-185.000	2	update through import_export	25	1
1361	2021-05-28 14:29:08.71016+00	1074	Cibao Oriental (Nagua)-Administración de Empresas -2021-Anual-68.000	2	update through import_export	25	1
1362	2021-05-28 14:29:08.724609+00	1073	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2021-Anual-134.000	2	update through import_export	25	1
1363	2021-05-28 14:29:08.73885+00	1072	Cibao Oriental (Nagua)-Informática Gerencial -2021-Anual-68.000	2	update through import_export	25	1
1364	2021-05-28 14:29:08.753182+00	1071	Cibao Oriental (Nagua)-Derecho-2021-Anual-112.000	2	update through import_export	25	1
1365	2021-05-28 14:29:08.767809+00	1070	Santo Domingo Oriental-Periodismo digital-2021-Anual-10.000	2	update through import_export	25	1
1366	2021-05-28 14:29:08.786845+00	1069	Santo Domingo Oriental-Psicología Industrial -2021-Anual-303.000	2	update through import_export	25	1
1367	2021-05-28 14:29:08.808127+00	1068	Santo Domingo Oriental-Psicología -2021-Anual-88.000	2	update through import_export	25	1
1368	2021-05-28 14:29:08.829148+00	1067	Santo Domingo Oriental-Psicología Educativa -2021-Anual-937.000	2	update through import_export	25	1
1369	2021-05-28 14:29:08.850583+00	1066	Santo Domingo Oriental-Psicología Clínica -2021-Anual-245.000	2	update through import_export	25	1
1370	2021-05-28 14:29:08.880164+00	1065	Santo Domingo Oriental-Mercadeo -2021-Anual-239.000	2	update through import_export	25	1
1371	2021-05-28 14:29:08.90577+00	1064	Santo Domingo Oriental-Contabilidad Empresarial -2021-Anual-601.000	2	update through import_export	25	1
1372	2021-05-28 14:29:08.927143+00	1063	Santo Domingo Oriental-Administración de Empresas -2021-Anual-324.000	2	update through import_export	25	1
1373	2021-05-28 14:29:08.951312+00	1062	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2021-Anual-213.000	2	update through import_export	25	1
1374	2021-05-28 14:29:08.971623+00	1061	Santo Domingo Oriental-Ingeniería en Software -2021-Anual-181.000	2	update through import_export	25	1
1375	2021-05-28 14:29:08.99266+00	1060	Santo Domingo Oriental-Informática Gerencial -2021-Anual-68.000	2	update through import_export	25	1
1376	2021-05-28 14:29:09.012413+00	1059	Santo Domingo Oriental-Derecho-2021-Anual-637.000	2	update through import_export	25	1
1377	2021-05-28 14:29:09.026702+00	1058	Santiago (sede)-Periodismo digital-2021-Anual-11.000	2	update through import_export	25	1
1378	2021-05-28 14:29:09.041784+00	1057	Santiago (sede)-Psicología Industrial -2021-Anual-142.000	2	update through import_export	25	1
1379	2021-05-28 14:29:09.056949+00	1056	Santiago (sede)-Psicología -2021-Anual-232.000	2	update through import_export	25	1
1380	2021-05-28 14:29:09.072301+00	1055	Santiago (sede)-Psicología Educativa -2021-Anual-1017.000	2	update through import_export	25	1
1381	2021-05-28 14:29:09.087439+00	1054	Santiago (sede)-Psicología Clínica -2021-Anual-188.000	2	update through import_export	25	1
1382	2021-05-28 14:29:09.10167+00	1053	Santiago (sede)-Administración de Empresas Turísticas -2021-Anual-78.000	2	update through import_export	25	1
1383	2021-05-28 14:29:09.116687+00	1052	Santiago (sede)-Mercadeo -2021-Anual-341.000	2	update through import_export	25	1
1559	2021-05-29 12:23:30.704166+00	25233	Santo Domingo Oriental-Registro	1	new through import_export	21	1
1384	2021-05-28 14:29:09.130852+00	1051	Santiago (sede)-Contabilidad Empresarial -2021-Anual-535.000	2	update through import_export	25	1
1385	2021-05-28 14:29:09.14545+00	1050	Santiago (sede)-Administración de Empresas -2021-Anual-295.000	2	update through import_export	25	1
1386	2021-05-28 14:29:09.160343+00	1049	Santiago (sede)-Lenguas Modernas Mención Turismo -2021-Anual-240.000	2	update through import_export	25	1
1387	2021-05-28 14:29:09.175906+00	1048	Santiago (sede)-Ingeniería en Software -2021-Anual-351.000	2	update through import_export	25	1
1388	2021-05-28 14:29:09.192064+00	1047	Santiago (sede)-Informática Gerencial -2021-Anual-80.000	2	update through import_export	25	1
1389	2021-05-28 14:29:09.207459+00	1046	Santiago (sede)-Matematica  Orientada a la Educacion Secundaria-2021-Anual-28.000	2	update through import_export	25	1
1390	2021-05-28 14:29:09.22224+00	1045	Santiago (sede)-Lengua Española y Literatura Orientada a la Educacion Secundaria-2021-Anual-12.000	2	update through import_export	25	1
1391	2021-05-28 14:29:09.237099+00	1044	Santiago (sede)-Derecho-2021-Anual-451.000	2	update through import_export	25	1
1392	2021-05-28 14:29:09.252206+00	1006	Cibao Oriental (Nagua)-Psicología Industrial -2020-Anual-1.000	2	update through import_export	25	1
1393	2021-05-28 14:29:09.267241+00	1005	Cibao Oriental (Nagua)-Psicología -2020-Anual-139.000	2	update through import_export	25	1
1394	2021-05-28 14:29:09.281856+00	1004	Cibao Oriental (Nagua)-Psicología Educativa -2020-Anual-535.000	2	update through import_export	25	1
1395	2021-05-28 14:29:09.297153+00	1003	Cibao Oriental (Nagua)-Administración de Empresas Turísticas -2020-Anual-20.000	2	update through import_export	25	1
1396	2021-05-28 14:29:09.311965+00	1002	Cibao Oriental (Nagua)-Mercadeo -2020-Anual-36.000	2	update through import_export	25	1
1397	2021-05-28 14:29:09.3261+00	1001	Cibao Oriental (Nagua)-Contabilidad Empresarial -2020-Anual-152.000	2	update through import_export	25	1
1398	2021-05-28 14:29:09.340318+00	1000	Cibao Oriental (Nagua)-Administración de Empresas -2020-Anual-71.000	2	update through import_export	25	1
1399	2021-05-28 14:29:09.35486+00	999	Cibao Oriental (Nagua)-Lenguas Modernas Mención Turismo -2020-Anual-96.000	2	update through import_export	25	1
1400	2021-05-28 14:29:09.369485+00	998	Cibao Oriental (Nagua)-Derecho-2020-Anual-111.000	2	update through import_export	25	1
1401	2021-05-28 14:29:09.383784+00	997	Santo Domingo Oriental-Psicología Industrial -2020-Anual-330.000	2	update through import_export	25	1
1402	2021-05-28 14:29:09.397887+00	996	Santo Domingo Oriental-Psicología -2020-Anual-107.000	2	update through import_export	25	1
1403	2021-05-28 14:29:09.412472+00	995	Santo Domingo Oriental-Psicología Educativa -2020-Anual-938.000	2	update through import_export	25	1
1404	2021-05-28 14:29:09.42672+00	994	Santo Domingo Oriental-Psicología Clínica -2020-Anual-256.000	2	update through import_export	25	1
1405	2021-05-28 14:29:09.441129+00	993	Santo Domingo Oriental-Administración de Empresas Turísticas -2020-Anual-1.000	2	update through import_export	25	1
1406	2021-05-28 14:29:09.455454+00	992	Santo Domingo Oriental-Mercadeo -2020-Anual-263.000	2	update through import_export	25	1
1407	2021-05-28 14:29:09.46986+00	991	Santo Domingo Oriental-Contabilidad Empresarial -2020-Anual-616.000	2	update through import_export	25	1
1408	2021-05-28 14:29:09.485192+00	990	Santo Domingo Oriental-Administración de Empresas -2020-Anual-295.000	2	update through import_export	25	1
1409	2021-05-28 14:29:09.501435+00	989	Santo Domingo Oriental-Lenguas Modernas Mención Turismo -2020-Anual-176.000	2	update through import_export	25	1
1410	2021-05-28 14:29:09.516891+00	988	Santo Domingo Oriental-Ingeniería en Software -2020-Anual-91.000	2	update through import_export	25	1
1411	2021-05-28 14:29:09.531795+00	987	Santo Domingo Oriental-Informática Gerencial -2020-Anual-27.000	2	update through import_export	25	1
1412	2021-05-28 14:29:09.546998+00	986	Santo Domingo Oriental-Derecho-2020-Anual-643.000	2	update through import_export	25	1
1413	2021-05-28 14:29:09.561635+00	985	Santiago (sede)-Psicología Industrial -2020-Anual-136.000	2	update through import_export	25	1
1414	2021-05-28 14:29:09.576228+00	984	Santiago (sede)-Psicología -2020-Anual-167.000	2	update through import_export	25	1
1415	2021-05-28 14:29:09.591295+00	983	Santiago (sede)-Psicología Educativa -2020-Anual-1023.000	2	update through import_export	25	1
1416	2021-05-28 14:29:09.605692+00	982	Santiago (sede)-Psicología Clínica -2020-Anual-183.000	2	update through import_export	25	1
1417	2021-05-28 14:29:09.620684+00	981	Santiago (sede)-Administración de Empresas Turísticas -2020-Anual-61.000	2	update through import_export	25	1
1418	2021-05-28 14:29:09.635232+00	980	Santiago (sede)-Mercadeo -2020-Anual-294.000	2	update through import_export	25	1
1419	2021-05-28 14:29:09.650276+00	979	Santiago (sede)-Contabilidad Empresarial -2020-Anual-462.000	2	update through import_export	25	1
1420	2021-05-28 14:29:09.664676+00	978	Santiago (sede)-Administración de Empresas -2020-Anual-258.000	2	update through import_export	25	1
1421	2021-05-28 14:29:09.679645+00	977	Santiago (sede)-Lenguas Modernas Mención Turismo -2020-Anual-217.000	2	update through import_export	25	1
1422	2021-05-28 14:29:09.693919+00	976	Santiago (sede)-Ingeniería en Software -2020-Anual-304.000	2	update through import_export	25	1
1423	2021-05-28 14:29:09.70971+00	975	Santiago (sede)-Informática Gerencial -2020-Anual-75.000	2	update through import_export	25	1
1424	2021-05-28 14:29:09.724493+00	974	Santiago (sede)-Educación Inicial-2020-Anual-72.000	2	update through import_export	25	1
1425	2021-05-28 14:29:09.739295+00	973	Santiago (sede)-Derecho-2020-Anual-502.000	2	update through import_export	25	1
1426	2021-05-28 14:29:09.75469+00	938	Cibao Oriental (Nagua)-Agrimensura-2019-Anual-46.000	2	update through import_export	25	1
1427	2021-05-28 14:29:09.768492+00	937	Santo Domingo Oriental-Agrimensura-2019-Anual-70.000	2	update through import_export	25	1
1428	2021-05-28 14:29:09.782042+00	936	Santiago (sede)-Agrimensura-2019-Anual-170.000	2	update through import_export	25	1
1429	2021-05-28 14:29:09.795739+00	935	Cibao Oriental (Nagua)-Agrimensura-2018-Anual-69.000	2	update through import_export	25	1
1430	2021-05-28 14:29:09.809077+00	934	Santo Domingo Oriental-Agrimensura-2018-Anual-102.000	2	update through import_export	25	1
1431	2021-05-28 14:29:09.822292+00	933	Santiago (sede)-Agrimensura-2018-Anual-193.000	2	update through import_export	25	1
1432	2021-05-28 14:29:09.836085+00	932	Cibao Oriental (Nagua)-Agrimensura-2017-Anual-102.000	2	update through import_export	25	1
1433	2021-05-28 14:29:09.848725+00	931	Santiago (sede)-Agrimensura-2017-Anual-305.000	2	update through import_export	25	1
1434	2021-05-28 14:29:09.862655+00	930	Cibao Oriental (Nagua)-Agrimensura-2021-Anual-156.000	2	update through import_export	25	1
1435	2021-05-28 14:29:09.875695+00	929	Santiago (sede)-Agrimensura-2021-Anual-374.000	2	update through import_export	25	1
1436	2021-05-28 14:29:09.888857+00	928	Santiago (sede)-Agrimensura-2020-Anual-344.000	2	update through import_export	25	1
1437	2021-05-28 15:38:37.74806+00	232	Cibao Oriental (Nagua)-Psicología Educativa	2	[{"changed": {"fields": ["Par\\u00e1metro opcional"]}}]	21	1
1438	2021-05-28 20:18:03.049285+00	25200	Cibao Oriental (Nagua)-Dominicana	1	new through import_export	21	1
1439	2021-05-28 20:18:03.076755+00	25199	Cibao Oriental (Nagua)-Haitiana	1	new through import_export	21	1
1440	2021-05-28 20:18:03.104117+00	25198	Cibao Oriental (Nagua)-Colombiana	1	new through import_export	21	1
1441	2021-05-28 20:18:03.123583+00	25197	Cibao Oriental (Nagua)-Cubana	1	new through import_export	21	1
1442	2021-05-28 20:18:03.143166+00	25196	Cibao Oriental (Nagua)-Venezolana	1	new through import_export	21	1
1443	2021-05-28 20:18:03.162848+00	25195	Cibao Oriental (Nagua)-Estadounidense	1	new through import_export	21	1
1444	2021-05-28 20:18:03.179556+00	25194	Cibao Oriental (Nagua)-Española	1	new through import_export	21	1
1445	2021-05-28 20:18:03.192312+00	25192	Santo Domingo Oriental-Dominicana	1	new through import_export	21	1
1446	2021-05-28 20:18:03.205164+00	25191	Santo Domingo Oriental-Haitiana	1	new through import_export	21	1
1447	2021-05-28 20:18:03.219034+00	25190	Santo Domingo Oriental-Colombiana	1	new through import_export	21	1
1448	2021-05-28 20:18:03.231284+00	25189	Santo Domingo Oriental-Cubana	1	new through import_export	21	1
1449	2021-05-28 20:18:03.244301+00	25188	Santo Domingo Oriental-Venezolana	1	new through import_export	21	1
1450	2021-05-28 20:18:03.256886+00	25187	Santo Domingo Oriental-Estadounidense	1	new through import_export	21	1
1451	2021-05-28 20:18:03.269905+00	25186	Santo Domingo Oriental-Española	1	new through import_export	21	1
1452	2021-05-28 20:18:03.283098+00	25170	Santiago (sede)-Española	1	new through import_export	21	1
1453	2021-05-28 20:18:03.295734+00	25169	Santiago (sede)-Estadounidense	1	new through import_export	21	1
1454	2021-05-28 20:18:03.308596+00	25168	Santiago (sede)-Venezolana	1	new through import_export	21	1
1455	2021-05-28 20:18:03.321619+00	25167	Santiago (sede)-Cubana	1	new through import_export	21	1
1456	2021-05-28 20:18:03.335209+00	25166	Santiago (sede)-Colombiana	1	new through import_export	21	1
1457	2021-05-28 20:18:03.348174+00	25165	Santiago (sede)-Haitiana	1	new through import_export	21	1
1458	2021-05-28 20:18:03.361238+00	25164	Santiago (sede)-Dominicana	1	new through import_export	21	1
1459	2021-05-28 20:18:56.869479+00	2205	Cibao Oriental (Nagua)-Estadounidense-2019-Anual-1.000	1	new through import_export	25	1
1460	2021-05-28 20:18:56.890453+00	2204	Cibao Oriental (Nagua)-Venezolana-2019-Anual-2.000	1	new through import_export	25	1
1461	2021-05-28 20:18:56.91352+00	2203	Cibao Oriental (Nagua)-Dominicana-2019-Anual-635.000	1	new through import_export	25	1
1462	2021-05-28 20:18:56.930776+00	2202	Santo Domingo Oriental-Estadounidense-2019-Anual-2.000	1	new through import_export	25	1
1463	2021-05-28 20:18:56.944741+00	2201	Santo Domingo Oriental-Venezolana-2019-Anual-8.000	1	new through import_export	25	1
1464	2021-05-28 20:18:56.95849+00	2200	Santo Domingo Oriental-Cubana-2019-Anual-1.000	1	new through import_export	25	1
1465	2021-05-28 20:18:56.972079+00	2199	Santo Domingo Oriental-Haitiana-2019-Anual-4.000	1	new through import_export	25	1
1466	2021-05-28 20:18:56.985719+00	2198	Santo Domingo Oriental-Dominicana-2019-Anual-1909.000	1	new through import_export	25	1
1467	2021-05-28 20:18:56.999139+00	2197	Santiago (sede)-Española-2019-Anual-2.000	1	new through import_export	25	1
1468	2021-05-28 20:18:57.012884+00	2196	Santiago (sede)-Estadounidense-2019-Anual-5.000	1	new through import_export	25	1
1469	2021-05-28 20:18:57.027137+00	2195	Santiago (sede)-Venezolana-2019-Anual-4.000	1	new through import_export	25	1
1470	2021-05-28 20:18:57.04088+00	2194	Santiago (sede)-Cubana-2019-Anual-1.000	1	new through import_export	25	1
1471	2021-05-28 20:18:57.054531+00	2193	Santiago (sede)-Haitiana-2019-Anual-6.000	1	new through import_export	25	1
1472	2021-05-28 20:18:57.068998+00	2192	Santiago (sede)-Dominicana-2019-Anual-2866.000	1	new through import_export	25	1
1473	2021-05-28 20:18:57.0824+00	2191	Cibao Oriental (Nagua)-Estadounidense-2018-Anual-3.000	1	new through import_export	25	1
1474	2021-05-28 20:18:57.096497+00	2190	Cibao Oriental (Nagua)-Cubana-2018-Anual-1.000	1	new through import_export	25	1
1475	2021-05-28 20:18:57.109835+00	2189	Cibao Oriental (Nagua)-Colombiana-2018-Anual-1.000	1	new through import_export	25	1
1476	2021-05-28 20:18:57.124049+00	2188	Cibao Oriental (Nagua)-Haitiana-2018-Anual-2.000	1	new through import_export	25	1
1477	2021-05-28 20:18:57.137354+00	2187	Cibao Oriental (Nagua)-Dominicana-2018-Anual-769.000	1	new through import_export	25	1
1478	2021-05-28 20:18:57.151125+00	2186	Santo Domingo Oriental-Española-2018-Anual-2.000	1	new through import_export	25	1
1479	2021-05-28 20:18:57.164813+00	2185	Santo Domingo Oriental-Estadounidense-2018-Anual-3.000	1	new through import_export	25	1
1480	2021-05-28 20:18:57.178976+00	2184	Santo Domingo Oriental-Venezolana-2018-Anual-6.000	1	new through import_export	25	1
1481	2021-05-28 20:18:57.192815+00	2183	Santo Domingo Oriental-Colombiana-2018-Anual-1.000	1	new through import_export	25	1
1482	2021-05-28 20:18:57.206872+00	2182	Santo Domingo Oriental-Haitiana-2018-Anual-5.000	1	new through import_export	25	1
1483	2021-05-28 20:18:57.220487+00	2181	Santo Domingo Oriental-Dominicana-2018-Anual-2667.000	1	new through import_export	25	1
1484	2021-05-28 20:18:57.2354+00	2180	Santiago (sede)-Estadounidense-2018-Anual-5.000	1	new through import_export	25	1
1485	2021-05-28 20:18:57.249354+00	2179	Santiago (sede)-Venezolana-2018-Anual-12.000	1	new through import_export	25	1
1486	2021-05-28 20:18:57.26335+00	2178	Santiago (sede)-Colombiana-2018-Anual-2.000	1	new through import_export	25	1
1487	2021-05-28 20:18:57.27728+00	2177	Santiago (sede)-Haitiana-2018-Anual-11.000	1	new through import_export	25	1
1488	2021-05-28 20:18:57.291336+00	2176	Santiago (sede)-Dominicana-2018-Anual-4102.000	1	new through import_export	25	1
1489	2021-05-28 20:18:57.305199+00	2175	Cibao Oriental (Nagua)-Española-2017-Anual-1.000	1	new through import_export	25	1
1490	2021-05-28 20:18:57.318794+00	2174	Cibao Oriental (Nagua)-Estadounidense-2017-Anual-1.000	1	new through import_export	25	1
1491	2021-05-28 20:18:57.332995+00	2173	Cibao Oriental (Nagua)-Colombiana-2017-Anual-1.000	1	new through import_export	25	1
1492	2021-05-28 20:18:57.347327+00	2172	Cibao Oriental (Nagua)-Haitiana-2017-Anual-1.000	1	new through import_export	25	1
1493	2021-05-28 20:18:57.361415+00	2171	Cibao Oriental (Nagua)-Dominicana-2017-Anual-1287.000	1	new through import_export	25	1
1494	2021-05-28 20:18:57.37537+00	2170	Santo Domingo Oriental-Española-2017-Anual-1.000	1	new through import_export	25	1
1495	2021-05-28 20:18:57.389345+00	2169	Santo Domingo Oriental-Estadounidense-2017-Anual-10.000	1	new through import_export	25	1
1496	2021-05-28 20:18:57.4035+00	2168	Santo Domingo Oriental-Venezolana-2017-Anual-7.000	1	new through import_export	25	1
1497	2021-05-28 20:18:57.417345+00	2167	Santo Domingo Oriental-Cubana-2017-Anual-1.000	1	new through import_export	25	1
1498	2021-05-28 20:18:57.430862+00	2166	Santo Domingo Oriental-Colombiana-2017-Anual-1.000	1	new through import_export	25	1
1499	2021-05-28 20:18:57.444666+00	2165	Santo Domingo Oriental-Haitiana-2017-Anual-8.000	1	new through import_export	25	1
1500	2021-05-28 20:18:57.458311+00	2164	Santo Domingo Oriental-Dominicana-2017-Anual-3871.000	1	new through import_export	25	1
1501	2021-05-28 20:18:57.471736+00	2163	Santiago (sede)-Española-2017-Anual-2.000	1	new through import_export	25	1
1502	2021-05-28 20:18:57.484493+00	2162	Santiago (sede)-Estadounidense-2017-Anual-13.000	1	new through import_export	25	1
1503	2021-05-28 20:18:57.49814+00	2161	Santiago (sede)-Haitiana-2017-Anual-15.000	1	new through import_export	25	1
1504	2021-05-28 20:18:57.512007+00	2160	Santiago (sede)-Dominicana-2017-Anual-4788.000	1	new through import_export	25	1
1505	2021-05-28 20:18:57.524391+00	2159	Cibao Oriental (Nagua)-Estadounidense-2021-Anual-2.000	1	new through import_export	25	1
1506	2021-05-28 20:18:57.53743+00	2158	Cibao Oriental (Nagua)-Venezolana-2021-Anual-1.000	1	new through import_export	25	1
1507	2021-05-28 20:18:57.550886+00	2157	Cibao Oriental (Nagua)-Haitiana-2021-Anual-6.000	1	new through import_export	25	1
1508	2021-05-28 20:18:57.563965+00	2156	Cibao Oriental (Nagua)-Dominicana-2021-Anual-1427.000	1	new through import_export	25	1
1509	2021-05-28 20:18:57.577643+00	2155	Santo Domingo Oriental-Española-2021-Anual-1.000	1	new through import_export	25	1
1510	2021-05-28 20:18:57.590449+00	2154	Santo Domingo Oriental-Estadounidense-2021-Anual-9.000	1	new through import_export	25	1
1511	2021-05-28 20:18:57.602987+00	2153	Santo Domingo Oriental-Venezolana-2021-Anual-10.000	1	new through import_export	25	1
1512	2021-05-28 20:18:57.616092+00	2152	Santo Domingo Oriental-Colombiana-2021-Anual-1.000	1	new through import_export	25	1
1513	2021-05-28 20:18:57.629868+00	2151	Santo Domingo Oriental-Haitiana-2021-Anual-14.000	1	new through import_export	25	1
1514	2021-05-28 20:18:57.642731+00	2150	Santo Domingo Oriental-Dominicana-2021-Anual-4179.000	1	new through import_export	25	1
1515	2021-05-28 20:18:57.655395+00	2149	Santiago (sede)-Española-2021-Anual-2.000	1	new through import_export	25	1
1516	2021-05-28 20:18:57.668128+00	2148	Santiago (sede)-Estadounidense-2021-Anual-8.000	1	new through import_export	25	1
1517	2021-05-28 20:18:57.681504+00	2147	Santiago (sede)-Venezolana-2021-Anual-5.000	1	new through import_export	25	1
1518	2021-05-28 20:18:57.695454+00	2146	Santiago (sede)-Colombiana-2021-Anual-2.000	1	new through import_export	25	1
1519	2021-05-28 20:18:57.708891+00	2145	Santiago (sede)-Haitiana-2021-Anual-17.000	1	new through import_export	25	1
1520	2021-05-28 20:18:57.722435+00	2144	Santiago (sede)-Dominicana-2021-Anual-5413.000	1	new through import_export	25	1
1521	2021-05-28 20:18:57.736347+00	2143	Cibao Oriental (Nagua)-Haitiana-2020-Anual-2.000	1	new through import_export	25	1
1522	2021-05-28 20:18:57.751233+00	2142	Cibao Oriental (Nagua)-Dominicana-2020-Anual-1159.000	1	new through import_export	25	1
1523	2021-05-28 20:18:57.765398+00	2141	Santo Domingo Oriental-Estadounidense-2020-Anual-1.000	1	new through import_export	25	1
1524	2021-05-28 20:18:57.779031+00	2140	Santo Domingo Oriental-Haitiana-2020-Anual-3.000	1	new through import_export	25	1
1525	2021-05-28 20:18:57.792732+00	2139	Santo Domingo Oriental-Dominicana-2020-Anual-4104.000	1	new through import_export	25	1
1526	2021-05-28 20:18:57.805893+00	2138	Santiago (sede)-Española-2020-Anual-1.000	1	new through import_export	25	1
1527	2021-05-28 20:18:57.819212+00	2137	Santiago (sede)-Estadounidense-2020-Anual-2.000	1	new through import_export	25	1
1528	2021-05-28 20:18:57.832585+00	2136	Santiago (sede)-Venezolana-2020-Anual-2.000	1	new through import_export	25	1
1529	2021-05-28 20:18:57.846544+00	2135	Santiago (sede)-Colombiana-2020-Anual-1.000	1	new through import_export	25	1
1530	2021-05-28 20:18:57.859818+00	2134	Santiago (sede)-Haitiana-2020-Anual-7.000	1	new through import_export	25	1
1531	2021-05-28 20:18:57.873228+00	2133	Santiago (sede)-Dominicana-2020-Anual-5363.000	1	new through import_export	25	1
1532	2021-05-29 12:23:30.239811+00	25260	Santo Domingo Oriental-Director de Escuela	1	new through import_export	21	1
1533	2021-05-29 12:23:30.260049+00	25259	Cibao Oriental (Nagua)-Director de Escuela	1	new through import_export	21	1
1534	2021-05-29 12:23:30.27447+00	25258	 Santiago (sede)-Director de Escuela	1	new through import_export	21	1
1535	2021-05-29 12:23:30.288134+00	25257	Santo Domingo Oriental-Campus Virtual	1	new through import_export	21	1
1536	2021-05-29 12:23:30.301233+00	25256	Cibao Oriental (Nagua)-Campus Virtual	1	new through import_export	21	1
1537	2021-05-29 12:23:30.314649+00	25255	 Santiago (sede)-Campus Virtual	1	new through import_export	21	1
1538	2021-05-29 12:23:30.327528+00	25254	Santo Domingo Oriental-Entorno General	1	new through import_export	21	1
1539	2021-05-29 12:23:30.342768+00	25253	Cibao Oriental (Nagua)-Entorno General	1	new through import_export	21	1
1540	2021-05-29 12:23:30.36377+00	25252	 Santiago (sede)-Entorno General	1	new through import_export	21	1
1541	2021-05-29 12:23:30.385435+00	25251	Santo Domingo Oriental-Cafetería	1	new through import_export	21	1
1542	2021-05-29 12:23:30.406803+00	25250	Cibao Oriental (Nagua)-Cafetería	1	new through import_export	21	1
1543	2021-05-29 12:23:30.428581+00	25249	 Santiago (sede)-Cafetería	1	new through import_export	21	1
1544	2021-05-29 12:23:30.449814+00	25248	Santo Domingo Oriental-Secretaria Edificio Administrativo	1	new through import_export	21	1
1545	2021-05-29 12:23:30.471036+00	25247	Cibao Oriental (Nagua)-Secretaria Edificio Administrativo	1	new through import_export	21	1
1546	2021-05-29 12:23:30.491539+00	25246	 Santiago (sede)-Secretaria Edificio Administrativo	1	new through import_export	21	1
1547	2021-05-29 12:23:30.511393+00	25245	Santo Domingo Oriental-Biblioteca y Audiovisuales	1	new through import_export	21	1
1548	2021-05-29 12:23:30.532725+00	25244	Cibao Oriental (Nagua)-Biblioteca y Audiovisuales	1	new through import_export	21	1
1549	2021-05-29 12:23:30.560155+00	25243	 Santiago (sede)-Biblioteca y Audiovisuales	1	new through import_export	21	1
1550	2021-05-29 12:23:30.579289+00	25242	Santo Domingo Oriental-Economato	1	new through import_export	21	1
1551	2021-05-29 12:23:30.598471+00	25241	Cibao Oriental (Nagua)-Economato	1	new through import_export	21	1
1552	2021-05-29 12:23:30.612538+00	25240	 Santiago (sede)-Economato	1	new through import_export	21	1
1553	2021-05-29 12:23:30.626494+00	25239	Santo Domingo Oriental-Admisiones	1	new through import_export	21	1
1554	2021-05-29 12:23:30.639989+00	25238	Cibao Oriental (Nagua)-Admisiones	1	new through import_export	21	1
1555	2021-05-29 12:23:30.653201+00	25237	 Santiago (sede)-Admisiones	1	new through import_export	21	1
1556	2021-05-29 12:23:30.666104+00	25236	Santo Domingo Oriental-Caja	1	new through import_export	21	1
1557	2021-05-29 12:23:30.679156+00	25235	Cibao Oriental (Nagua)-Caja	1	new through import_export	21	1
1558	2021-05-29 12:23:30.691667+00	25234	 Santiago (sede)-Caja	1	new through import_export	21	1
1560	2021-05-29 12:23:30.722594+00	25232	Cibao Oriental (Nagua)-Registro	1	new through import_export	21	1
1561	2021-05-29 12:23:30.735499+00	25231	 Santiago (sede)-Registro	1	new through import_export	21	1
1562	2021-05-29 12:26:33.691785+00	2565	Cibao Oriental (Nagua)-Director de Escuela-2017-Anual-90.000	1	new through import_export	25	1
1563	2021-05-29 12:26:33.704698+00	2564	Cibao Oriental (Nagua)-Campus Virtual-2017-Anual-96.000	1	new through import_export	25	1
1564	2021-05-29 12:26:33.718246+00	2563	Cibao Oriental (Nagua)-Entorno General-2017-Anual-80.000	1	new through import_export	25	1
1565	2021-05-29 12:26:33.730869+00	2562	Cibao Oriental (Nagua)-Cafetería-2017-Anual-92.000	1	new through import_export	25	1
1566	2021-05-29 12:26:33.743543+00	2561	Cibao Oriental (Nagua)-Secretaria Edificio Administrativo-2017-Anual-85.000	1	new through import_export	25	1
1567	2021-05-29 12:26:33.756692+00	2560	Cibao Oriental (Nagua)-Biblioteca y Audiovisuales-2017-Anual-89.000	1	new through import_export	25	1
1568	2021-05-29 12:26:33.769275+00	2559	Cibao Oriental (Nagua)-Economato-2017-Anual-86.000	1	new through import_export	25	1
1569	2021-05-29 12:26:33.782583+00	2558	Cibao Oriental (Nagua)-Admisiones-2017-Anual-93.000	1	new through import_export	25	1
1570	2021-05-29 12:26:33.79544+00	2557	Cibao Oriental (Nagua)-Caja-2017-Anual-94.000	1	new through import_export	25	1
1571	2021-05-29 12:26:33.80818+00	2556	Cibao Oriental (Nagua)-Registro-2017-Anual-89.000	1	new through import_export	25	1
1572	2021-05-29 12:26:33.820811+00	2555	Santo Domingo Oriental-Director de Escuela-2017-Anual-85.000	1	new through import_export	25	1
1573	2021-05-29 12:26:33.833627+00	2554	Santo Domingo Oriental-Campus Virtual-2017-Anual-96.000	1	new through import_export	25	1
1574	2021-05-29 12:26:33.846981+00	2553	Santo Domingo Oriental-Entorno General-2017-Anual-88.000	1	new through import_export	25	1
1575	2021-05-29 12:26:33.860239+00	2552	Santo Domingo Oriental-Cafetería-2017-Anual-92.000	1	new through import_export	25	1
1576	2021-05-29 12:26:33.872922+00	2551	Santo Domingo Oriental-Secretaria Edificio Administrativo-2017-Anual-91.000	1	new through import_export	25	1
1577	2021-05-29 12:26:33.885291+00	2550	Santo Domingo Oriental-Biblioteca y Audiovisuales-2017-Anual-92.000	1	new through import_export	25	1
1578	2021-05-29 12:26:33.898746+00	2549	Santo Domingo Oriental-Economato-2017-Anual-89.000	1	new through import_export	25	1
1579	2021-05-29 12:26:33.911787+00	2548	Santo Domingo Oriental-Admisiones-2017-Anual-93.000	1	new through import_export	25	1
1580	2021-05-29 12:26:33.924502+00	2547	Santo Domingo Oriental-Caja-2017-Anual-89.000	1	new through import_export	25	1
1581	2021-05-29 12:26:33.937044+00	2546	Santo Domingo Oriental-Registro-2017-Anual-82.000	1	new through import_export	25	1
1582	2021-05-29 12:26:33.949809+00	2545	 Santiago (sede)-Director de Escuela-2017-Anual-91.000	1	new through import_export	25	1
1583	2021-05-29 12:26:33.962415+00	2544	 Santiago (sede)-Campus Virtual-2017-Anual-95.000	1	new through import_export	25	1
1584	2021-05-29 12:26:33.975303+00	2543	 Santiago (sede)-Entorno General-2017-Anual-74.000	1	new through import_export	25	1
1585	2021-05-29 12:26:33.987688+00	2542	 Santiago (sede)-Cafetería-2017-Anual-96.000	1	new through import_export	25	1
1586	2021-05-29 12:26:34.000453+00	2541	 Santiago (sede)-Secretaria Edificio Administrativo-2017-Anual-94.000	1	new through import_export	25	1
1587	2021-05-29 12:26:34.01326+00	2540	 Santiago (sede)-Biblioteca y Audiovisuales-2017-Anual-96.000	1	new through import_export	25	1
1588	2021-05-29 12:26:34.025926+00	2539	 Santiago (sede)-Economato-2017-Anual-90.000	1	new through import_export	25	1
1589	2021-05-29 12:26:34.038616+00	2538	 Santiago (sede)-Admisiones-2017-Anual-97.000	1	new through import_export	25	1
1590	2021-05-29 12:26:34.051739+00	2537	 Santiago (sede)-Caja-2017-Anual-97.000	1	new through import_export	25	1
1591	2021-05-29 12:26:34.064655+00	2536	 Santiago (sede)-Registro-2017-Anual-90.000	1	new through import_export	25	1
1592	2021-05-29 12:26:34.077255+00	2535	Cibao Oriental (Nagua)-Director de Escuela-2021-Anual-88.000	1	new through import_export	25	1
1593	2021-05-29 12:26:34.089897+00	2534	Cibao Oriental (Nagua)-Campus Virtual-2021-Anual-78.000	1	new through import_export	25	1
1594	2021-05-29 12:26:34.102464+00	2533	Cibao Oriental (Nagua)-Entorno General-2021-Anual-79.000	1	new through import_export	25	1
1595	2021-05-29 12:26:34.115247+00	2532	Cibao Oriental (Nagua)-Cafetería-2021-Anual-74.000	1	new through import_export	25	1
1596	2021-05-29 12:26:34.127779+00	2531	Cibao Oriental (Nagua)-Secretaria Edificio Administrativo-2021-Anual-91.000	1	new through import_export	25	1
1597	2021-05-29 12:26:34.140766+00	2530	Cibao Oriental (Nagua)-Biblioteca y Audiovisuales-2021-Anual-87.000	1	new through import_export	25	1
1598	2021-05-29 12:26:34.153222+00	2529	Cibao Oriental (Nagua)-Economato-2021-Anual-91.000	1	new through import_export	25	1
1599	2021-05-29 12:26:34.166058+00	2528	Cibao Oriental (Nagua)-Admisiones-2021-Anual-91.000	1	new through import_export	25	1
1600	2021-05-29 12:26:34.178678+00	2527	Cibao Oriental (Nagua)-Caja-2021-Anual-88.000	1	new through import_export	25	1
1601	2021-05-29 12:26:34.191429+00	2526	Cibao Oriental (Nagua)-Registro-2021-Anual-86.000	1	new through import_export	25	1
1602	2021-05-29 12:26:34.203927+00	2525	Santo Domingo Oriental-Director de Escuela-2021-Anual-89.000	1	new through import_export	25	1
1603	2021-05-29 12:26:34.216642+00	2524	Santo Domingo Oriental-Campus Virtual-2021-Anual-82.000	1	new through import_export	25	1
1604	2021-05-29 12:26:34.228852+00	2523	Santo Domingo Oriental-Entorno General-2021-Anual-78.000	1	new through import_export	25	1
1605	2021-05-29 12:26:34.240993+00	2522	Santo Domingo Oriental-Cafetería-2021-Anual-87.000	1	new through import_export	25	1
1606	2021-05-29 12:26:34.253446+00	2521	Santo Domingo Oriental-Secretaria Edificio Administrativo-2021-Anual-88.000	1	new through import_export	25	1
1607	2021-05-29 12:26:34.266028+00	2520	Santo Domingo Oriental-Biblioteca y Audiovisuales-2021-Anual-89.000	1	new through import_export	25	1
1608	2021-05-29 12:26:34.278599+00	2519	Santo Domingo Oriental-Economato-2021-Anual-91.000	1	new through import_export	25	1
1609	2021-05-29 12:26:34.291516+00	2518	Santo Domingo Oriental-Admisiones-2021-Anual-89.000	1	new through import_export	25	1
1610	2021-05-29 12:26:34.303795+00	2517	Santo Domingo Oriental-Caja-2021-Anual-80.000	1	new through import_export	25	1
1611	2021-05-29 12:26:34.316532+00	2516	Santo Domingo Oriental-Registro-2021-Anual-76.000	1	new through import_export	25	1
1612	2021-05-29 12:26:34.329045+00	2515	 Santiago (sede)-Director de Escuela-2021-Anual-93.000	1	new through import_export	25	1
1613	2021-05-29 12:26:34.341563+00	2514	 Santiago (sede)-Campus Virtual-2021-Anual-83.000	1	new through import_export	25	1
1614	2021-05-29 12:26:34.35393+00	2513	 Santiago (sede)-Entorno General-2021-Anual-86.000	1	new through import_export	25	1
1615	2021-05-29 12:26:34.366876+00	2512	 Santiago (sede)-Cafetería-2021-Anual-82.000	1	new through import_export	25	1
1616	2021-05-29 12:26:34.379719+00	2511	 Santiago (sede)-Secretaria Edificio Administrativo-2021-Anual-95.000	1	new through import_export	25	1
1617	2021-05-29 12:26:34.392337+00	2510	 Santiago (sede)-Biblioteca y Audiovisuales-2021-Anual-94.000	1	new through import_export	25	1
1618	2021-05-29 12:26:34.404593+00	2509	 Santiago (sede)-Economato-2021-Anual-95.000	1	new through import_export	25	1
1619	2021-05-29 12:26:34.417464+00	2508	 Santiago (sede)-Admisiones-2021-Anual-95.000	1	new through import_export	25	1
1620	2021-05-29 12:26:34.430076+00	2507	 Santiago (sede)-Caja-2021-Anual-93.000	1	new through import_export	25	1
1621	2021-05-29 12:26:34.443064+00	2506	 Santiago (sede)-Registro-2021-Anual-89.000	1	new through import_export	25	1
1622	2021-05-29 12:26:34.454894+00	2505	Cibao Oriental (Nagua)-Director de Escuela-2020-Anual-93.000	1	new through import_export	25	1
1623	2021-05-29 12:26:34.467328+00	2504	Cibao Oriental (Nagua)-Campus Virtual-2020-Anual-83.000	1	new through import_export	25	1
1624	2021-05-29 12:26:34.480572+00	2503	Cibao Oriental (Nagua)-Entorno General-2020-Anual-81.000	1	new through import_export	25	1
1625	2021-05-29 12:26:34.49401+00	2502	Cibao Oriental (Nagua)-Cafetería-2020-Anual-79.000	1	new through import_export	25	1
1626	2021-05-29 12:26:34.507515+00	2501	Cibao Oriental (Nagua)-Secretaria Edificio Administrativo-2020-Anual-93.000	1	new through import_export	25	1
1627	2021-05-29 12:26:34.520073+00	2500	Cibao Oriental (Nagua)-Biblioteca y Audiovisuales-2020-Anual-90.000	1	new through import_export	25	1
1628	2021-05-29 12:26:34.534378+00	2499	Cibao Oriental (Nagua)-Economato-2020-Anual-89.000	1	new through import_export	25	1
1629	2021-05-29 12:26:34.549777+00	2498	Cibao Oriental (Nagua)-Admisiones-2020-Anual-93.000	1	new through import_export	25	1
1630	2021-05-29 12:26:34.569876+00	2497	Cibao Oriental (Nagua)-Caja-2020-Anual-90.000	1	new through import_export	25	1
1631	2021-05-29 12:26:34.590068+00	2496	Cibao Oriental (Nagua)-Registro-2020-Anual-89.000	1	new through import_export	25	1
1632	2021-05-29 12:26:34.609583+00	2495	Santo Domingo Oriental-Director de Escuela-2020-Anual-85.000	1	new through import_export	25	1
1633	2021-05-29 12:26:34.629047+00	2494	Santo Domingo Oriental-Campus Virtual-2020-Anual-74.000	1	new through import_export	25	1
1634	2021-05-29 12:26:34.648942+00	2493	Santo Domingo Oriental-Entorno General-2020-Anual-72.000	1	new through import_export	25	1
1635	2021-05-29 12:26:34.6689+00	2492	Santo Domingo Oriental-Cafetería-2020-Anual-81.000	1	new through import_export	25	1
1636	2021-05-29 12:26:34.690843+00	2491	Santo Domingo Oriental-Secretaria Edificio Administrativo-2020-Anual-85.000	1	new through import_export	25	1
1637	2021-05-29 12:26:34.712301+00	2490	Santo Domingo Oriental-Biblioteca y Audiovisuales-2020-Anual-82.000	1	new through import_export	25	1
1638	2021-05-29 12:26:34.733011+00	2489	Santo Domingo Oriental-Economato-2020-Anual-86.000	1	new through import_export	25	1
1639	2021-05-29 12:26:34.753161+00	2488	Santo Domingo Oriental-Admisiones-2020-Anual-83.000	1	new through import_export	25	1
1640	2021-05-29 12:26:34.773057+00	2487	Santo Domingo Oriental-Caja-2020-Anual-70.000	1	new through import_export	25	1
1641	2021-05-29 12:26:34.787852+00	2486	Santo Domingo Oriental-Registro-2020-Anual-71.000	1	new through import_export	25	1
1642	2021-05-29 12:26:34.8015+00	2485	 Santiago (sede)-Director de Escuela-2020-Anual-94.000	1	new through import_export	25	1
1643	2021-05-29 12:26:34.814832+00	2484	 Santiago (sede)-Campus Virtual-2020-Anual-89.000	1	new through import_export	25	1
1644	2021-05-29 12:26:34.828585+00	2483	 Santiago (sede)-Entorno General-2020-Anual-85.000	1	new through import_export	25	1
1645	2021-05-29 12:26:34.841523+00	2482	 Santiago (sede)-Cafetería-2020-Anual-79.000	1	new through import_export	25	1
1646	2021-05-29 12:26:34.85436+00	2481	 Santiago (sede)-Secretaria Edificio Administrativo-2020-Anual-95.000	1	new through import_export	25	1
1647	2021-05-29 12:26:34.867782+00	2480	 Santiago (sede)-Biblioteca y Audiovisuales-2020-Anual-95.000	1	new through import_export	25	1
1648	2021-05-29 12:26:34.882458+00	2479	 Santiago (sede)-Economato-2020-Anual-93.000	1	new through import_export	25	1
1649	2021-05-29 12:26:34.8961+00	2478	 Santiago (sede)-Admisiones-2020-Anual-94.000	1	new through import_export	25	1
1650	2021-05-29 12:26:34.909598+00	2477	 Santiago (sede)-Caja-2020-Anual-90.000	1	new through import_export	25	1
1651	2021-05-29 12:26:34.923161+00	2476	 Santiago (sede)-Registro-2020-Anual-86.000	1	new through import_export	25	1
1652	2021-05-29 15:39:36.129888+00	25302	Santo Domingo Oriental-Ciencias jurídicas y políticas	1	new through import_export	21	1
1653	2021-05-29 15:39:36.144813+00	25301	Santiago (sede)-Postgrado	1	new through import_export	21	1
1654	2021-05-29 15:39:36.164207+00	25300	Cibao Oriental (Nagua)-Postgrado	1	new through import_export	21	1
1655	2021-05-29 15:39:36.179126+00	25299	Cibao Oriental (Nagua)-Turismo / idiomas	1	new through import_export	21	1
1656	2021-05-29 15:39:36.191751+00	25298	Cibao Oriental (Nagua)-Ciencias de la salud y psicología	1	new through import_export	21	1
1657	2021-05-29 15:39:36.205673+00	25297	Cibao Oriental (Nagua)-Ingeniería y tecnología	1	new through import_export	21	1
1658	2021-05-29 15:39:36.21862+00	25296	Cibao Oriental (Nagua)-Negocios	1	new through import_export	21	1
1659	2021-05-29 15:39:36.230912+00	25295	Cibao Oriental (Nagua)-Educación y formación general	1	new through import_export	21	1
1660	2021-05-29 15:39:36.243291+00	25294	Cibao Oriental (Nagua)-Ciencias jurídicas y políticas	1	new through import_export	21	1
1661	2021-05-29 15:39:36.256427+00	25292	Santo Domingo Oriental-Turismo / idiomas	1	new through import_export	21	1
1662	2021-05-29 15:39:36.269722+00	25291	Santo Domingo Oriental-Ciencias de la salud y psicología	1	new through import_export	21	1
1663	2021-05-29 15:39:36.282728+00	25290	Santo Domingo Oriental-Ingeniería y tecnología	1	new through import_export	21	1
1664	2021-05-29 15:39:36.295858+00	25289	Santo Domingo Oriental-Negocios	1	new through import_export	21	1
1665	2021-05-29 15:39:36.308878+00	25288	Santo Domingo Oriental-Educación y formación general	1	new through import_export	21	1
1666	2021-05-29 15:39:36.321586+00	25287	Santo Domingo Oriental-Postgrado	1	new through import_export	21	1
1667	2021-05-29 15:39:36.334606+00	25286	Santiago (sede)-Turismo / idiomas	1	new through import_export	21	1
1668	2021-05-29 15:39:36.347536+00	25285	Santiago (sede)-Ciencias de la salud y psicología	1	new through import_export	21	1
1669	2021-05-29 15:39:36.360846+00	25284	Santiago (sede)-Ingeniería y tecnología	1	new through import_export	21	1
1670	2021-05-29 15:39:36.374932+00	25283	Santiago (sede)-Negocios	1	new through import_export	21	1
1671	2021-05-29 15:39:36.387837+00	25282	Santiago (sede)-Educación y formación general	1	new through import_export	21	1
1672	2021-05-29 15:39:36.404568+00	25281	Santiago (sede)-Ciencias jurídicas y políticas	1	new through import_export	21	1
1673	2021-05-29 15:40:33.394335+00	3240	Cibao Oriental (Nagua)-Postgrado-2019-Anual-94.000	1	new through import_export	25	1
1674	2021-05-29 15:40:33.430817+00	3239	Cibao Oriental (Nagua)-Turismo / idiomas-2019-Anual-96.000	1	new through import_export	25	1
1675	2021-05-29 15:40:33.468765+00	3238	Cibao Oriental (Nagua)-Ciencias de la salud y psicología-2019-Anual-96.000	1	new through import_export	25	1
1676	2021-05-29 15:40:33.556371+00	3237	Cibao Oriental (Nagua)-Ingeniería y tecnología-2019-Anual-100.000	1	new through import_export	25	1
1677	2021-05-29 15:40:33.615842+00	3236	Cibao Oriental (Nagua)-Negocios-2019-Anual-97.000	1	new through import_export	25	1
1678	2021-05-29 15:40:33.758046+00	3235	Cibao Oriental (Nagua)-Educación y formación general-2019-Anual-96.000	1	new through import_export	25	1
1679	2021-05-29 15:40:34.373897+00	3234	Cibao Oriental (Nagua)-Ciencias jurídicas y políticas-2019-Anual-93.000	1	new through import_export	25	1
1680	2021-05-29 15:40:34.402698+00	3233	Santo Domingo Oriental-Postgrado-2019-Anual-94.000	1	new through import_export	25	1
1681	2021-05-29 15:40:34.425031+00	3232	Santo Domingo Oriental-Turismo / idiomas-2019-Anual-98.000	1	new through import_export	25	1
1682	2021-05-29 15:40:34.447838+00	3231	Santo Domingo Oriental-Ciencias de la salud y psicología-2019-Anual-87.000	1	new through import_export	25	1
1683	2021-05-29 15:40:34.536786+00	3230	Santo Domingo Oriental-Ingeniería y tecnología-2019-Anual-89.000	1	new through import_export	25	1
1684	2021-05-29 15:40:34.564277+00	3229	Santo Domingo Oriental-Negocios-2019-Anual-88.000	1	new through import_export	25	1
1685	2021-05-29 15:40:34.587083+00	3228	Santo Domingo Oriental-Educación y formación general-2019-Anual-92.000	1	new through import_export	25	1
1686	2021-05-29 15:40:34.618589+00	3227	Santo Domingo Oriental-Ciencias jurídicas y políticas-2019-Anual-88.000	1	new through import_export	25	1
1687	2021-05-29 15:40:34.638544+00	3226	Santiago (sede)-Postgrado-2019-Anual-92.000	1	new through import_export	25	1
1688	2021-05-29 15:40:34.658226+00	3225	Santiago (sede)-Turismo / idiomas-2019-Anual-90.000	1	new through import_export	25	1
1689	2021-05-29 15:40:34.672284+00	3224	Santiago (sede)-Ciencias de la salud y psicología-2019-Anual-88.000	1	new through import_export	25	1
1690	2021-05-29 15:40:34.69251+00	3223	Santiago (sede)-Ingeniería y tecnología-2019-Anual-85.000	1	new through import_export	25	1
1691	2021-05-29 15:40:34.709012+00	3222	Santiago (sede)-Negocios-2019-Anual-90.000	1	new through import_export	25	1
1692	2021-05-29 15:40:34.726718+00	3221	Santiago (sede)-Educación y formación general-2019-Anual-92.000	1	new through import_export	25	1
1693	2021-05-29 15:40:34.743338+00	3220	Santiago (sede)-Ciencias jurídicas y políticas-2019-Anual-89.000	1	new through import_export	25	1
1694	2021-05-29 15:40:34.759806+00	3219	Cibao Oriental (Nagua)-Postgrado-2018-Anual-93.000	1	new through import_export	25	1
1695	2021-05-29 15:40:34.776962+00	3218	Cibao Oriental (Nagua)-Turismo / idiomas-2018-Anual-93.000	1	new through import_export	25	1
1696	2021-05-29 15:40:34.796325+00	3217	Cibao Oriental (Nagua)-Ciencias de la salud y psicología-2018-Anual-94.000	1	new through import_export	25	1
1697	2021-05-29 15:40:34.814598+00	3216	Cibao Oriental (Nagua)-Ingeniería y tecnología-2018-Anual-90.000	1	new through import_export	25	1
1698	2021-05-29 15:40:34.827782+00	3215	Cibao Oriental (Nagua)-Negocios-2018-Anual-91.000	1	new through import_export	25	1
1699	2021-05-29 15:40:34.841373+00	3214	Cibao Oriental (Nagua)-Educación y formación general-2018-Anual-93.000	1	new through import_export	25	1
1700	2021-05-29 15:40:34.857047+00	3213	Cibao Oriental (Nagua)-Ciencias jurídicas y políticas-2018-Anual-92.000	1	new through import_export	25	1
1701	2021-05-29 15:40:34.879387+00	3212	Santo Domingo Oriental-Postgrado-2018-Anual-92.000	1	new through import_export	25	1
1702	2021-05-29 15:40:34.89522+00	3211	Santo Domingo Oriental-Turismo / idiomas-2018-Anual-93.000	1	new through import_export	25	1
1703	2021-05-29 15:40:34.911629+00	3210	Santo Domingo Oriental-Ciencias de la salud y psicología-2018-Anual-92.000	1	new through import_export	25	1
1704	2021-05-29 15:40:34.928368+00	3209	Santo Domingo Oriental-Ingeniería y tecnología-2018-Anual-88.000	1	new through import_export	25	1
1705	2021-05-29 15:40:34.942394+00	3208	Santo Domingo Oriental-Negocios-2018-Anual-89.000	1	new through import_export	25	1
1706	2021-05-29 15:40:34.955864+00	3207	Santo Domingo Oriental-Educación y formación general-2018-Anual-88.000	1	new through import_export	25	1
1707	2021-05-29 15:40:34.97219+00	3206	Santo Domingo Oriental-Ciencias jurídicas y políticas-2018-Anual-89.000	1	new through import_export	25	1
1708	2021-05-29 15:40:34.986448+00	3205	Santiago (sede)-Postgrado-2018-Anual-93.000	1	new through import_export	25	1
1709	2021-05-29 15:40:35.000973+00	3204	Santiago (sede)-Turismo / idiomas-2018-Anual-88.000	1	new through import_export	25	1
1710	2021-05-29 15:40:35.017489+00	3203	Santiago (sede)-Ciencias de la salud y psicología-2018-Anual-88.000	1	new through import_export	25	1
1711	2021-05-29 15:40:35.037387+00	3202	Santiago (sede)-Ingeniería y tecnología-2018-Anual-88.000	1	new through import_export	25	1
1712	2021-05-29 15:40:35.056983+00	3201	Santiago (sede)-Negocios-2018-Anual-86.000	1	new through import_export	25	1
1713	2021-05-29 15:40:35.074229+00	3200	Santiago (sede)-Educación y formación general-2018-Anual-91.000	1	new through import_export	25	1
1714	2021-05-29 15:40:35.089899+00	3199	Santiago (sede)-Ciencias jurídicas y políticas-2018-Anual-91.000	1	new through import_export	25	1
1715	2021-05-29 15:40:35.106088+00	3198	Cibao Oriental (Nagua)-Ingeniería y tecnología-2017-Anual-97.000	1	new through import_export	25	1
1716	2021-05-29 15:40:35.122333+00	3197	Cibao Oriental (Nagua)-Educación y formación general-2017-Anual-89.000	1	new through import_export	25	1
1717	2021-05-29 15:40:35.138485+00	3196	Cibao Oriental (Nagua)-Ciencias jurídicas y políticas-2017-Anual-96.000	1	new through import_export	25	1
1718	2021-05-29 15:40:35.156408+00	3195	Santo Domingo Oriental-Postgrado-2017-Anual-91.000	1	new through import_export	25	1
1719	2021-05-29 15:40:35.173248+00	3194	Santo Domingo Oriental-Turismo / idiomas-2017-Anual-86.000	1	new through import_export	25	1
1720	2021-05-29 15:40:35.192565+00	3193	Santo Domingo Oriental-Ciencias de la salud y psicología-2017-Anual-83.000	1	new through import_export	25	1
1721	2021-05-29 15:40:35.209967+00	3192	Santo Domingo Oriental-Ingeniería y tecnología-2017-Anual-82.000	1	new through import_export	25	1
1722	2021-05-29 15:40:35.22702+00	3191	Santo Domingo Oriental-Negocios-2017-Anual-83.000	1	new through import_export	25	1
1723	2021-05-29 15:40:35.24364+00	3190	Santo Domingo Oriental-Educación y formación general-2017-Anual-90.000	1	new through import_export	25	1
1724	2021-05-29 15:40:35.259675+00	3189	Santo Domingo Oriental-Ciencias jurídicas y políticas-2017-Anual-87.000	1	new through import_export	25	1
1725	2021-05-29 15:40:35.275508+00	3188	Santiago (sede)-Postgrado-2017-Anual-86.000	1	new through import_export	25	1
1726	2021-05-29 15:40:35.290141+00	3187	Santiago (sede)-Turismo / idiomas-2017-Anual-90.000	1	new through import_export	25	1
1727	2021-05-29 15:40:35.305387+00	3186	Santiago (sede)-Ciencias de la salud y psicología-2017-Anual-88.000	1	new through import_export	25	1
1728	2021-05-29 15:40:35.319482+00	3185	Santiago (sede)-Ingeniería y tecnología-2017-Anual-83.000	1	new through import_export	25	1
1729	2021-05-29 15:40:35.338945+00	3184	Santiago (sede)-Negocios-2017-Anual-87.000	1	new through import_export	25	1
1730	2021-05-29 15:40:35.354359+00	3183	Santiago (sede)-Educación y formación general-2017-Anual-91.000	1	new through import_export	25	1
1731	2021-05-29 15:40:35.368443+00	3182	Santiago (sede)-Ciencias jurídicas y políticas-2017-Anual-95.000	1	new through import_export	25	1
1732	2021-05-29 15:40:35.382666+00	3181	Cibao Oriental (Nagua)-Postgrado-2021-Anual-89.000	1	new through import_export	25	1
1733	2021-05-29 15:40:35.397435+00	3180	Cibao Oriental (Nagua)-Turismo / idiomas-2021-Anual-77.000	1	new through import_export	25	1
1734	2021-05-29 15:40:35.412126+00	3179	Cibao Oriental (Nagua)-Ciencias de la salud y psicología-2021-Anual-83.000	1	new through import_export	25	1
1735	2021-05-29 15:40:35.426543+00	3178	Cibao Oriental (Nagua)-Ingeniería y tecnología-2021-Anual-81.000	1	new through import_export	25	1
1736	2021-05-29 15:40:35.440362+00	3177	Cibao Oriental (Nagua)-Negocios-2021-Anual-83.000	1	new through import_export	25	1
1737	2021-05-29 15:40:35.455872+00	3176	Cibao Oriental (Nagua)-Educación y formación general-2021-Anual-82.000	1	new through import_export	25	1
1738	2021-05-29 15:40:35.470708+00	3175	Cibao Oriental (Nagua)-Ciencias jurídicas y políticas-2021-Anual-86.000	1	new through import_export	25	1
1739	2021-05-29 15:40:35.485472+00	3174	Santo Domingo Oriental-Postgrado-2021-Anual-93.000	1	new through import_export	25	1
1740	2021-05-29 15:40:35.500019+00	3173	Santo Domingo Oriental-Turismo / idiomas-2021-Anual-70.000	1	new through import_export	25	1
1741	2021-05-29 15:40:35.514242+00	3172	Santo Domingo Oriental-Ciencias de la salud y psicología-2021-Anual-82.000	1	new through import_export	25	1
1742	2021-05-29 15:40:35.52865+00	3171	Santo Domingo Oriental-Ingeniería y tecnología-2021-Anual-82.000	1	new through import_export	25	1
1743	2021-05-29 15:40:35.543007+00	3170	Santo Domingo Oriental-Negocios-2021-Anual-81.000	1	new through import_export	25	1
1744	2021-05-29 15:40:35.556614+00	3169	Santo Domingo Oriental-Educación y formación general-2021-Anual-84.000	1	new through import_export	25	1
1745	2021-05-29 15:40:35.57095+00	3168	Santo Domingo Oriental-Ciencias jurídicas y políticas-2021-Anual-81.000	1	new through import_export	25	1
1746	2021-05-29 15:40:35.58545+00	3167	Santiago (sede)-Postgrado-2021-Anual-88.000	1	new through import_export	25	1
1747	2021-05-29 15:40:35.599754+00	3166	Santiago (sede)-Turismo / idiomas-2021-Anual-83.000	1	new through import_export	25	1
1748	2021-05-29 15:40:35.61369+00	3165	Santiago (sede)-Ciencias de la salud y psicología-2021-Anual-85.000	1	new through import_export	25	1
1749	2021-05-29 15:40:35.63322+00	3164	Santiago (sede)-Ingeniería y tecnología-2021-Anual-83.000	1	new through import_export	25	1
1750	2021-05-29 15:40:35.652897+00	3163	Santiago (sede)-Negocios-2021-Anual-84.000	1	new through import_export	25	1
1751	2021-05-29 15:40:35.672847+00	3162	Santiago (sede)-Educación y formación general-2021-Anual-86.000	1	new through import_export	25	1
1752	2021-05-29 15:40:35.70021+00	3161	Santiago (sede)-Ciencias jurídicas y políticas-2021-Anual-81.000	1	new through import_export	25	1
1753	2021-05-31 14:10:04.540829+00	25529	Nagua-Servicios Generales/Grado-Pregrado	1	new through import_export	21	1
1754	2021-05-31 14:10:04.554524+00	25528	Nagua-Servicios Generales/Maestria	1	new through import_export	21	1
1755	2021-05-31 14:10:04.568036+00	25527	Nagua-Servicios Generales/Doctorado	1	new through import_export	21	1
1756	2021-05-31 14:10:04.581539+00	25526	Santo Domingo-Servicios Generales/Grado-Pregrado	1	new through import_export	21	1
1757	2021-05-31 14:10:04.594287+00	25525	Santo Domingo-Servicios Generales/Maestria	1	new through import_export	21	1
1758	2021-05-31 14:10:04.607921+00	25524	Santo Domingo-Servicios Generales/Doctorado	1	new through import_export	21	1
1759	2021-05-31 14:10:04.620466+00	25523	Santiago (sede)-Servicios Generales/Grado-Pregrado	1	new through import_export	21	1
1760	2021-05-31 14:10:04.634379+00	25522	Santiago (sede)-Servicios Generales/Maestria	1	new through import_export	21	1
1761	2021-05-31 14:10:04.647659+00	25521	Santiago (sede)-Servicios Generales/Doctorado	1	new through import_export	21	1
1762	2021-05-31 14:10:04.665284+00	25520	Nagua-Auxiliares/Grado-Pregrado	1	new through import_export	21	1
1763	2021-05-31 14:10:04.678446+00	25519	Nagua-Auxiliares/Maestria	1	new through import_export	21	1
1764	2021-05-31 14:10:04.691579+00	25518	Nagua-Auxiliares/Doctorado	1	new through import_export	21	1
1765	2021-05-31 14:10:04.704373+00	25517	Santo Domingo-Auxiliares/Grado-Pregrado	1	new through import_export	21	1
1766	2021-05-31 14:10:04.71737+00	25516	Santo Domingo-Auxiliares/Maestria	1	new through import_export	21	1
1767	2021-05-31 14:10:04.730378+00	25515	Santo Domingo-Auxiliares/Doctorado	1	new through import_export	21	1
1768	2021-05-31 14:10:04.74435+00	25514	Santiago (sede)-Auxiliares/Grado-Pregrado	1	new through import_export	21	1
1769	2021-05-31 14:10:04.757051+00	25513	Santiago (sede)-Auxiliares/Maestria	1	new through import_export	21	1
1770	2021-05-31 14:10:04.770443+00	25512	Santiago (sede)-Auxiliares/Doctorado	1	new through import_export	21	1
1771	2021-05-31 14:10:04.783426+00	25511	Nagua-Secretarias/Grado-Pregrado	1	new through import_export	21	1
1772	2021-05-31 14:10:04.797311+00	25510	Nagua-Secretarias/Maestria	1	new through import_export	21	1
1773	2021-05-31 14:10:04.810401+00	25509	Nagua-Secretarias/Doctorado	1	new through import_export	21	1
1774	2021-05-31 14:10:04.823003+00	25508	Santo Domingo-Secretarias/Grado-Pregrado	1	new through import_export	21	1
1775	2021-05-31 14:10:04.835705+00	25507	Santo Domingo-Secretarias/Maestria	1	new through import_export	21	1
1776	2021-05-31 14:10:04.849904+00	25506	Santo Domingo-Secretarias/Doctorado	1	new through import_export	21	1
1777	2021-05-31 14:10:04.862542+00	25505	Santiago (sede)-Secretarias/Grado-Pregrado	1	new through import_export	21	1
1778	2021-05-31 14:10:04.875113+00	25504	Santiago (sede)-Secretarias/Maestria	1	new through import_export	21	1
1779	2021-05-31 14:10:04.894986+00	25503	Santiago (sede)-Secretarias/Doctorado	1	new through import_export	21	1
1780	2021-05-31 14:10:04.919336+00	25502	Nagua-Asistentes/Grado-Pregrado	1	new through import_export	21	1
1781	2021-05-31 14:10:04.937678+00	25501	Nagua-Asistentes/Maestria	1	new through import_export	21	1
1782	2021-05-31 14:10:04.961108+00	25500	Nagua-Asistentes/Doctorado	1	new through import_export	21	1
1783	2021-05-31 14:10:04.982608+00	25499	Santo Domingo-Asistentes/Grado-Pregrado	1	new through import_export	21	1
1784	2021-05-31 14:10:05.00219+00	25498	Santo Domingo-Asistentes/Maestria	1	new through import_export	21	1
1785	2021-05-31 14:10:05.024608+00	25497	Santo Domingo-Asistentes/Doctorado	1	new through import_export	21	1
1786	2021-05-31 14:10:05.044215+00	25496	Santiago (sede)-Asistentes/Grado-Pregrado	1	new through import_export	21	1
1787	2021-05-31 14:10:05.062604+00	25495	Santiago (sede)-Asistentes/Maestria	1	new through import_export	21	1
1788	2021-05-31 14:10:05.088408+00	25494	Santiago (sede)-Asistentes/Doctorado	1	new through import_export	21	1
1789	2021-05-31 14:10:05.102619+00	25493	Nagua-Analistas/Grado-Pregrado	1	new through import_export	21	1
1790	2021-05-31 14:10:05.117648+00	25492	Nagua-Analistas/Maestria	1	new through import_export	21	1
1791	2021-05-31 14:10:05.131979+00	25491	Nagua-Analistas/Doctorado	1	new through import_export	21	1
1792	2021-05-31 14:10:05.144666+00	25490	Santo Domingo-Analistas/Grado-Pregrado	1	new through import_export	21	1
1793	2021-05-31 14:10:05.158429+00	25489	Santo Domingo-Analistas/Maestria	1	new through import_export	21	1
1794	2021-05-31 14:10:05.171359+00	25488	Santo Domingo-Analistas/Doctorado	1	new through import_export	21	1
1795	2021-05-31 14:10:05.185629+00	25487	Santiago (sede)-Analistas/Grado-Pregrado	1	new through import_export	21	1
1796	2021-05-31 14:10:05.199136+00	25486	Santiago (sede)-Analistas/Maestria	1	new through import_export	21	1
1797	2021-05-31 14:10:05.212059+00	25485	Santiago (sede)-Analistas/Doctorado	1	new through import_export	21	1
1798	2021-05-31 14:10:05.224793+00	25484	Nagua-Especialistas/Grado-Pregrado	1	new through import_export	21	1
1799	2021-05-31 14:10:05.238855+00	25483	Nagua-Especialistas/Maestria	1	new through import_export	21	1
1800	2021-05-31 14:10:05.253586+00	25482	Nagua-Especialistas/Doctorado	1	new through import_export	21	1
1801	2021-05-31 14:10:05.266744+00	25481	Santo Domingo-Especialistas/Grado-Pregrado	1	new through import_export	21	1
1802	2021-05-31 14:10:05.280397+00	25480	Santo Domingo-Especialistas/Maestria	1	new through import_export	21	1
1803	2021-05-31 14:10:05.294122+00	25479	Santo Domingo-Especialistas/Doctorado	1	new through import_export	21	1
1804	2021-05-31 14:10:05.307527+00	25478	Santiago (sede)-Especialistas/Grado-Pregrado	1	new through import_export	21	1
1805	2021-05-31 14:10:05.320257+00	25477	Santiago (sede)-Especialistas/Maestria	1	new through import_export	21	1
1806	2021-05-31 14:10:05.333115+00	25476	Santiago (sede)-Especialistas/Doctorado	1	new through import_export	21	1
1807	2021-05-31 14:10:05.346149+00	25475	Nagua-Coordinadores/Grado-Pregrado	1	new through import_export	21	1
1808	2021-05-31 14:10:05.359669+00	25474	Nagua-Coordinadores/Maestria	1	new through import_export	21	1
1809	2021-05-31 14:10:05.372513+00	25473	Nagua-Coordinadores/Doctorado	1	new through import_export	21	1
1810	2021-05-31 14:10:05.386608+00	25472	Santo Domingo-Coordinadores/Grado-Pregrado	1	new through import_export	21	1
1811	2021-05-31 14:10:05.39952+00	25471	Santo Domingo-Coordinadores/Maestria	1	new through import_export	21	1
1812	2021-05-31 14:10:05.412983+00	25470	Santo Domingo-Coordinadores/Doctorado	1	new through import_export	21	1
1813	2021-05-31 14:10:05.425719+00	25469	Santiago (sede)-Coordinadores/Grado-Pregrado	1	new through import_export	21	1
1814	2021-05-31 14:10:05.438186+00	25468	Santiago (sede)-Coordinadores/Maestria	1	new through import_export	21	1
1815	2021-05-31 14:10:05.451385+00	25467	Santiago (sede)-Coordinadores/Doctorado	1	new through import_export	21	1
1816	2021-05-31 14:10:05.465552+00	25466	Nagua-Directores-Encargados/Grado-Pregrado	1	new through import_export	21	1
1817	2021-05-31 14:10:05.478702+00	25465	Nagua-Directores-Encargados/Maestria	1	new through import_export	21	1
1818	2021-05-31 14:10:05.493393+00	25464	Nagua-Directores-Encargados/Doctorado	1	new through import_export	21	1
1819	2021-05-31 14:10:05.508099+00	25463	Santo Domingo-Directores-Encargados/Grado-Pregrado	1	new through import_export	21	1
1820	2021-05-31 14:10:05.521081+00	25462	Santo Domingo-Directores-Encargados/Maestria	1	new through import_export	21	1
1821	2021-05-31 14:10:05.534514+00	25461	Santo Domingo-Directores-Encargados/Doctorado	1	new through import_export	21	1
1822	2021-05-31 14:10:05.547503+00	25460	Santiago (sede)-Directores-Encargados/Grado-Pregrado	1	new through import_export	21	1
1823	2021-05-31 14:10:05.55958+00	25459	Santiago (sede)-Directores-Encargados/Maestria	1	new through import_export	21	1
1824	2021-05-31 14:10:05.572694+00	25458	Santiago (sede)-Directores-Encargados/Doctorado	1	new through import_export	21	1
1825	2021-05-31 14:10:05.585488+00	25457	Nagua-Vicerrectores/Grado-Pregrado	1	new through import_export	21	1
1826	2021-05-31 14:10:05.59818+00	25456	Nagua-Vicerrectores/Maestria	1	new through import_export	21	1
1827	2021-05-31 14:10:05.610709+00	25455	Nagua-Vicerrectores/Doctorado	1	new through import_export	21	1
1828	2021-05-31 14:10:05.625393+00	25454	Santo Domingo-Vicerrectores/Grado-Pregrado	1	new through import_export	21	1
1829	2021-05-31 14:10:05.637856+00	25453	Santo Domingo-Vicerrectores/Maestria	1	new through import_export	21	1
1830	2021-05-31 14:10:05.651039+00	25452	Santo Domingo-Vicerrectores/Doctorado	1	new through import_export	21	1
1831	2021-05-31 14:10:05.663867+00	25451	Santiago (sede)-Vicerrectores/Grado-Pregrado	1	new through import_export	21	1
1832	2021-05-31 14:10:05.676481+00	25450	Santiago (sede)-Vicerrectores/Maestria	1	new through import_export	21	1
1833	2021-05-31 14:10:05.690373+00	25449	Santiago (sede)-Vicerrectores/Doctorado	1	new through import_export	21	1
1834	2021-05-31 14:11:29.394192+00	4814	Nagua-Servicios Generales/Grado-Pregrado-2018-Anual-14.000	1	new through import_export	25	1
1835	2021-05-31 14:11:29.40721+00	4813	Santo Domingo-Servicios Generales/Grado-Pregrado-2018-Anual-20.000	1	new through import_export	25	1
1836	2021-05-31 14:11:29.419813+00	4812	Santiago (sede)-Servicios Generales/Grado-Pregrado-2018-Anual-46.000	1	new through import_export	25	1
1837	2021-05-31 14:11:29.432989+00	4811	Nagua-Auxiliares/Grado-Pregrado-2018-Anual-13.000	1	new through import_export	25	1
1838	2021-05-31 14:11:29.445857+00	4810	Santo Domingo-Auxiliares/Grado-Pregrado-2018-Anual-28.000	1	new through import_export	25	1
1839	2021-05-31 14:11:29.458567+00	4809	Santiago (sede)-Auxiliares/Grado-Pregrado-2018-Anual-49.000	1	new through import_export	25	1
1840	2021-05-31 14:11:29.471042+00	4808	Nagua-Secretarias/Grado-Pregrado-2018-Anual-11.000	1	new through import_export	25	1
1841	2021-05-31 14:11:29.484321+00	4807	Santo Domingo-Secretarias/Grado-Pregrado-2018-Anual-13.000	1	new through import_export	25	1
1842	2021-05-31 14:11:29.496933+00	4806	Santiago (sede)-Secretarias/Grado-Pregrado-2018-Anual-18.000	1	new through import_export	25	1
1843	2021-05-31 14:11:29.509831+00	4805	Santo Domingo-Asistentes/Grado-Pregrado-2018-Anual-4.000	1	new through import_export	25	1
1844	2021-05-31 14:11:29.522603+00	4804	Santiago (sede)-Asistentes/Grado-Pregrado-2018-Anual-8.000	1	new through import_export	25	1
1845	2021-05-31 14:11:29.535023+00	4803	Santiago (sede)-Asistentes/Maestria-2018-Anual-4.000	1	new through import_export	25	1
1846	2021-05-31 14:11:29.548138+00	4802	Nagua-Analistas/Grado-Pregrado-2018-Anual-1.000	1	new through import_export	25	1
1847	2021-05-31 14:11:29.560705+00	4801	Santiago (sede)-Analistas/Grado-Pregrado-2018-Anual-2.000	1	new through import_export	25	1
1848	2021-05-31 14:11:29.573412+00	4800	Santiago (sede)-Analistas/Maestria-2018-Anual-2.000	1	new through import_export	25	1
1849	2021-05-31 14:11:29.586229+00	4799	Santo Domingo-Especialistas/Grado-Pregrado-2018-Anual-2.000	1	new through import_export	25	1
1850	2021-05-31 14:11:29.598871+00	4798	Santo Domingo-Especialistas/Maestria-2018-Anual-1.000	1	new through import_export	25	1
1851	2021-05-31 14:11:29.611993+00	4797	Santiago (sede)-Especialistas/Grado-Pregrado-2018-Anual-5.000	1	new through import_export	25	1
1852	2021-05-31 14:11:29.624252+00	4796	Santiago (sede)-Especialistas/Maestria-2018-Anual-30.000	1	new through import_export	25	1
1853	2021-05-31 14:11:29.63653+00	4795	Santiago (sede)-Especialistas/Doctorado-2018-Anual-4.000	1	new through import_export	25	1
1854	2021-05-31 14:11:29.649498+00	4794	Santo Domingo-Coordinadores/Maestria-2018-Anual-2.000	1	new through import_export	25	1
1855	2021-05-31 14:11:29.663384+00	4793	Santiago (sede)-Coordinadores/Grado-Pregrado-2018-Anual-3.000	1	new through import_export	25	1
1856	2021-05-31 14:11:29.676406+00	4792	Santiago (sede)-Coordinadores/Maestria-2018-Anual-7.000	1	new through import_export	25	1
1857	2021-05-31 14:11:29.689876+00	4791	Santiago (sede)-Coordinadores/Doctorado-2018-Anual-3.000	1	new through import_export	25	1
1858	2021-05-31 14:11:29.702828+00	4790	Nagua-Directores-Encargados/Grado-Pregrado-2018-Anual-12.000	1	new through import_export	25	1
1859	2021-05-31 14:11:29.715813+00	4789	Nagua-Directores-Encargados/Maestria-2018-Anual-12.000	1	new through import_export	25	1
1860	2021-05-31 14:11:29.728453+00	4788	Nagua-Directores-Encargados/Doctorado-2018-Anual-1.000	1	new through import_export	25	1
1861	2021-05-31 14:11:29.741104+00	4787	Santo Domingo-Directores-Encargados/Grado-Pregrado-2018-Anual-14.000	1	new through import_export	25	1
1862	2021-05-31 14:11:29.753432+00	4786	Santo Domingo-Directores-Encargados/Maestria-2018-Anual-20.000	1	new through import_export	25	1
1863	2021-05-31 14:11:29.766344+00	4785	Santiago (sede)-Directores-Encargados/Grado-Pregrado-2018-Anual-22.000	1	new through import_export	25	1
1864	2021-05-31 14:11:29.778937+00	4784	Santiago (sede)-Directores-Encargados/Maestria-2018-Anual-48.000	1	new through import_export	25	1
1865	2021-05-31 14:11:29.791918+00	4783	Santiago (sede)-Directores-Encargados/Doctorado-2018-Anual-5.000	1	new through import_export	25	1
1866	2021-05-31 14:11:29.804502+00	4782	Santiago (sede)-Vicerrectores/Grado-Pregrado-2018-Anual-2.000	1	new through import_export	25	1
1867	2021-05-31 14:11:29.817728+00	4781	Santiago (sede)-Vicerrectores/Maestria-2018-Anual-3.000	1	new through import_export	25	1
1868	2021-05-31 14:11:29.831054+00	4780	Santiago (sede)-Vicerrectores/Doctorado-2018-Anual-4.000	1	new through import_export	25	1
1869	2021-05-31 14:11:29.843557+00	4779	Nagua-Servicios Generales/Grado-Pregrado-2017-Anual-20.000	1	new through import_export	25	1
1870	2021-05-31 14:11:29.856889+00	4778	Santo Domingo-Servicios Generales/Grado-Pregrado-2017-Anual-34.000	1	new through import_export	25	1
1871	2021-05-31 14:11:29.869593+00	4777	Santiago (sede)-Servicios Generales/Grado-Pregrado-2017-Anual-55.000	1	new through import_export	25	1
1872	2021-05-31 14:11:29.882451+00	4776	Nagua-Auxiliares/Grado-Pregrado-2017-Anual-24.000	1	new through import_export	25	1
1873	2021-05-31 14:11:29.895769+00	4775	Santo Domingo-Auxiliares/Grado-Pregrado-2017-Anual-51.000	1	new through import_export	25	1
1874	2021-05-31 14:11:29.908498+00	4774	Santiago (sede)-Auxiliares/Grado-Pregrado-2017-Anual-69.000	1	new through import_export	25	1
1875	2021-05-31 14:11:29.920998+00	4773	Nagua-Secretarias/Grado-Pregrado-2017-Anual-20.000	1	new through import_export	25	1
1876	2021-05-31 14:11:29.934759+00	4772	Santo Domingo-Secretarias/Grado-Pregrado-2017-Anual-20.000	1	new through import_export	25	1
1877	2021-05-31 14:11:29.948046+00	4771	Santiago (sede)-Secretarias/Grado-Pregrado-2017-Anual-21.000	1	new through import_export	25	1
1878	2021-05-31 14:11:29.96116+00	4770	Nagua-Asistentes/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1879	2021-05-31 14:11:29.973738+00	4769	Santo Domingo-Asistentes/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1880	2021-05-31 14:11:29.986169+00	4768	Santiago (sede)-Asistentes/Grado-Pregrado-2017-Anual-15.000	1	new through import_export	25	1
1881	2021-05-31 14:11:29.999537+00	4767	Santiago (sede)-Asistentes/Maestria-2017-Anual-1.000	1	new through import_export	25	1
1882	2021-05-31 14:11:30.012366+00	4766	Nagua-Analistas/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1883	2021-05-31 14:11:30.025042+00	4765	Santiago (sede)-Analistas/Grado-Pregrado-2017-Anual-6.000	1	new through import_export	25	1
1884	2021-05-31 14:11:30.037821+00	4764	Santiago (sede)-Analistas/Maestria-2017-Anual-2.000	1	new through import_export	25	1
1885	2021-05-31 14:11:30.050353+00	4763	Nagua-Especialistas/Maestria-2017-Anual-3.000	1	new through import_export	25	1
1886	2021-05-31 14:11:30.063024+00	4762	Santo Domingo-Especialistas/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1887	2021-05-31 14:11:30.075882+00	4761	Santo Domingo-Especialistas/Maestria-2017-Anual-3.000	1	new through import_export	25	1
1888	2021-05-31 14:11:30.089283+00	4760	Santiago (sede)-Especialistas/Grado-Pregrado-2017-Anual-8.000	1	new through import_export	25	1
1889	2021-05-31 14:11:30.101641+00	4759	Santiago (sede)-Especialistas/Maestria-2017-Anual-20.000	1	new through import_export	25	1
1890	2021-05-31 14:11:30.114805+00	4758	Santiago (sede)-Especialistas/Doctorado-2017-Anual-4.000	1	new through import_export	25	1
1891	2021-05-31 14:11:30.12759+00	4757	Nagua-Coordinadores/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1892	2021-05-31 14:11:30.140455+00	4756	Santo Domingo-Coordinadores/Grado-Pregrado-2017-Anual-1.000	1	new through import_export	25	1
1893	2021-05-31 14:11:30.15331+00	4755	Santiago (sede)-Coordinadores/Grado-Pregrado-2017-Anual-13.000	1	new through import_export	25	1
1894	2021-05-31 14:11:30.166118+00	4754	Santiago (sede)-Coordinadores/Maestria-2017-Anual-4.000	1	new through import_export	25	1
1895	2021-05-31 14:11:30.179003+00	4753	Santiago (sede)-Coordinadores/Doctorado-2017-Anual-1.000	1	new through import_export	25	1
1896	2021-05-31 14:11:30.192417+00	4752	Nagua-Directores-Encargados/Grado-Pregrado-2017-Anual-14.000	1	new through import_export	25	1
1897	2021-05-31 14:11:30.217728+00	4751	Nagua-Directores-Encargados/Maestria-2017-Anual-11.000	1	new through import_export	25	1
1898	2021-05-31 14:11:30.237869+00	4750	Nagua-Directores-Encargados/Doctorado-2017-Anual-1.000	1	new through import_export	25	1
1899	2021-05-31 14:11:30.259684+00	4749	Santo Domingo-Directores-Encargados/Grado-Pregrado-2017-Anual-21.000	1	new through import_export	25	1
1900	2021-05-31 14:11:30.287179+00	4748	Santo Domingo-Directores-Encargados/Maestria-2017-Anual-11.000	1	new through import_export	25	1
1901	2021-05-31 14:11:30.31072+00	4747	Santo Domingo-Directores-Encargados/Doctorado-2017-Anual-1.000	1	new through import_export	25	1
1902	2021-05-31 14:11:30.340443+00	4746	Santiago (sede)-Directores-Encargados/Grado-Pregrado-2017-Anual-26.000	1	new through import_export	25	1
1903	2021-05-31 14:11:30.360573+00	4745	Santiago (sede)-Directores-Encargados/Maestria-2017-Anual-49.000	1	new through import_export	25	1
1904	2021-05-31 14:11:30.382216+00	4744	Santiago (sede)-Directores-Encargados/Doctorado-2017-Anual-7.000	1	new through import_export	25	1
1905	2021-05-31 14:11:30.404106+00	4743	Santiago (sede)-Vicerrectores/Grado-Pregrado-2017-Anual-2.000	1	new through import_export	25	1
1906	2021-05-31 14:11:30.424464+00	4742	Santiago (sede)-Vicerrectores/Maestria-2017-Anual-3.000	1	new through import_export	25	1
1907	2021-05-31 14:11:30.445715+00	4741	Santiago (sede)-Vicerrectores/Doctorado-2017-Anual-4.000	1	new through import_export	25	1
1908	2021-05-31 14:11:30.46125+00	4740	Nagua-Servicios Generales/Grado-Pregrado-2021-Anual-19.000	1	new through import_export	25	1
1909	2021-05-31 14:11:30.47539+00	4739	Santo Domingo-Servicios Generales/Grado-Pregrado-2021-Anual-29.000	1	new through import_export	25	1
1910	2021-05-31 14:11:30.489346+00	4738	Santiago (sede)-Servicios Generales/Grado-Pregrado-2021-Anual-43.000	1	new through import_export	25	1
1911	2021-05-31 14:11:30.502612+00	4737	Nagua-Auxiliares/Grado-Pregrado-2021-Anual-26.000	1	new through import_export	25	1
1912	2021-05-31 14:11:30.515494+00	4736	Santo Domingo-Auxiliares/Grado-Pregrado-2021-Anual-48.000	1	new through import_export	25	1
1913	2021-05-31 14:11:30.529909+00	4735	Santiago (sede)-Auxiliares/Grado-Pregrado-2021-Anual-88.000	1	new through import_export	25	1
1914	2021-05-31 14:11:30.54351+00	4734	Nagua-Secretarias/Grado-Pregrado-2021-Anual-11.000	1	new through import_export	25	1
1915	2021-05-31 14:11:30.557327+00	4733	Santo Domingo-Secretarias/Grado-Pregrado-2021-Anual-12.000	1	new through import_export	25	1
1916	2021-05-31 14:11:30.570301+00	4732	Santiago (sede)-Secretarias/Grado-Pregrado-2021-Anual-15.000	1	new through import_export	25	1
1917	2021-05-31 14:11:30.583404+00	4731	Nagua-Asistentes/Maestria-2021-Anual-1.000	1	new through import_export	25	1
1918	2021-05-31 14:11:30.59638+00	4730	Santo Domingo-Asistentes/Grado-Pregrado-2021-Anual-5.000	1	new through import_export	25	1
1919	2021-05-31 14:11:30.609166+00	4729	Santiago (sede)-Asistentes/Grado-Pregrado-2021-Anual-13.000	1	new through import_export	25	1
1920	2021-05-31 14:11:30.622084+00	4728	Santiago (sede)-Asistentes/Maestria-2021-Anual-2.000	1	new through import_export	25	1
1921	2021-05-31 14:11:30.635188+00	4727	Nagua-Analistas/Grado-Pregrado-2021-Anual-1.000	1	new through import_export	25	1
1922	2021-05-31 14:11:30.648137+00	4726	Santiago (sede)-Analistas/Grado-Pregrado-2021-Anual-5.000	1	new through import_export	25	1
1923	2021-05-31 14:11:30.660968+00	4725	Santiago (sede)-Analistas/Maestria-2021-Anual-2.000	1	new through import_export	25	1
1924	2021-05-31 14:11:30.673472+00	4724	Nagua-Especialistas/Grado-Pregrado-2021-Anual-3.000	1	new through import_export	25	1
1925	2021-05-31 14:11:30.685915+00	4723	Santo Domingo-Especialistas/Grado-Pregrado-2021-Anual-1.000	1	new through import_export	25	1
1926	2021-05-31 14:11:30.698958+00	4722	Santo Domingo-Especialistas/Maestria-2021-Anual-2.000	1	new through import_export	25	1
1927	2021-05-31 14:11:30.71168+00	4721	Santiago (sede)-Especialistas/Grado-Pregrado-2021-Anual-10.000	1	new through import_export	25	1
1928	2021-05-31 14:11:30.724585+00	4720	Santiago (sede)-Especialistas/Maestria-2021-Anual-21.000	1	new through import_export	25	1
1929	2021-05-31 14:11:30.73674+00	4719	Santiago (sede)-Especialistas/Doctorado-2021-Anual-3.000	1	new through import_export	25	1
1930	2021-05-31 14:11:30.749087+00	4718	Santiago (sede)-Coordinadores/Grado-Pregrado-2021-Anual-8.000	1	new through import_export	25	1
1931	2021-05-31 14:11:30.761725+00	4717	Nagua-Directores-Encargados/Grado-Pregrado-2021-Anual-13.000	1	new through import_export	25	1
1932	2021-05-31 14:11:30.774601+00	4716	Nagua-Directores-Encargados/Maestria-2021-Anual-12.000	1	new through import_export	25	1
1933	2021-05-31 14:11:30.787145+00	4715	Nagua-Directores-Encargados/Doctorado-2021-Anual-1.000	1	new through import_export	25	1
1934	2021-05-31 14:11:30.799928+00	4714	Santo Domingo-Directores-Encargados/Grado-Pregrado-2021-Anual-25.000	1	new through import_export	25	1
1935	2021-05-31 14:11:30.813019+00	4713	Santo Domingo-Directores-Encargados/Maestria-2021-Anual-14.000	1	new through import_export	25	1
1936	2021-05-31 14:11:30.825447+00	4712	Santiago (sede)-Directores-Encargados/Grado-Pregrado-2021-Anual-26.000	1	new through import_export	25	1
1937	2021-05-31 14:11:30.837981+00	4711	Santiago (sede)-Directores-Encargados/Maestria-2021-Anual-43.000	1	new through import_export	25	1
1938	2021-05-31 14:11:30.851301+00	4710	Santiago (sede)-Directores-Encargados/Doctorado-2021-Anual-8.000	1	new through import_export	25	1
1939	2021-05-31 14:11:30.864393+00	4709	Santiago (sede)-Vicerrectores/Grado-Pregrado-2021-Anual-2.000	1	new through import_export	25	1
1940	2021-05-31 14:11:30.877275+00	4708	Santiago (sede)-Vicerrectores/Maestria-2021-Anual-2.000	1	new through import_export	25	1
1941	2021-05-31 14:11:30.890017+00	4707	Santiago (sede)-Vicerrectores/Doctorado-2021-Anual-4.000	1	new through import_export	25	1
1942	2021-05-31 14:11:30.90274+00	4706	Nagua-Servicios Generales/Grado-Pregrado-2020-Anual-17.000	1	new through import_export	25	1
1943	2021-05-31 14:11:30.915663+00	4705	Santo Domingo-Servicios Generales/Grado-Pregrado-2020-Anual-26.000	1	new through import_export	25	1
1944	2021-05-31 14:11:30.928279+00	4704	Santiago (sede)-Servicios Generales/Grado-Pregrado-2020-Anual-64.000	1	new through import_export	25	1
1945	2021-05-31 14:11:30.941201+00	4703	Nagua-Auxiliares/Grado-Pregrado-2020-Anual-21.000	1	new through import_export	25	1
1946	2021-05-31 14:11:30.953773+00	4702	Santo Domingo-Auxiliares/Grado-Pregrado-2020-Anual-48.000	1	new through import_export	25	1
1947	2021-05-31 14:11:30.966492+00	4701	Santiago (sede)-Auxiliares/Grado-Pregrado-2020-Anual-57.000	1	new through import_export	25	1
1948	2021-05-31 14:11:30.979381+00	4700	Nagua-Secretarias/Grado-Pregrado-2020-Anual-9.000	1	new through import_export	25	1
1949	2021-05-31 14:11:30.992148+00	4699	Santo Domingo-Secretarias/Grado-Pregrado-2020-Anual-14.000	1	new through import_export	25	1
1950	2021-05-31 14:11:31.004679+00	4698	Santo Domingo-Secretarias/Maestria-2020-Anual-1.000	1	new through import_export	25	1
1951	2021-05-31 14:11:31.017754+00	4697	Santiago (sede)-Secretarias/Grado-Pregrado-2020-Anual-18.000	1	new through import_export	25	1
1952	2021-05-31 14:11:31.030723+00	4696	Santiago (sede)-Secretarias/Maestria-2020-Anual-1.000	1	new through import_export	25	1
1953	2021-05-31 14:11:31.043809+00	4695	Nagua-Asistentes/Grado-Pregrado-2020-Anual-2.000	1	new through import_export	25	1
1954	2021-05-31 14:11:31.056332+00	4694	Santo Domingo-Asistentes/Grado-Pregrado-2020-Anual-2.000	1	new through import_export	25	1
1955	2021-05-31 14:11:31.068769+00	4693	Santiago (sede)-Asistentes/Grado-Pregrado-2020-Anual-19.000	1	new through import_export	25	1
1956	2021-05-31 14:11:31.081271+00	4692	Santiago (sede)-Asistentes/Maestria-2020-Anual-2.000	1	new through import_export	25	1
1957	2021-05-31 14:11:31.093861+00	4691	Nagua-Analistas/Grado-Pregrado-2020-Anual-1.000	1	new through import_export	25	1
1958	2021-05-31 14:11:31.106277+00	4690	Santiago (sede)-Analistas/Grado-Pregrado-2020-Anual-4.000	1	new through import_export	25	1
1959	2021-05-31 14:11:31.11876+00	4689	Santiago (sede)-Analistas/Maestria-2020-Anual-2.000	1	new through import_export	25	1
1960	2021-05-31 14:11:31.131752+00	4688	Nagua-Especialistas/Grado-Pregrado-2020-Anual-3.000	1	new through import_export	25	1
1961	2021-05-31 14:11:31.144422+00	4687	Santo Domingo-Especialistas/Grado-Pregrado-2020-Anual-1.000	1	new through import_export	25	1
1962	2021-05-31 14:11:31.158542+00	4686	Santo Domingo-Especialistas/Maestria-2020-Anual-2.000	1	new through import_export	25	1
1963	2021-05-31 14:11:31.17144+00	4685	Santiago (sede)-Especialistas/Grado-Pregrado-2020-Anual-12.000	1	new through import_export	25	1
1964	2021-05-31 14:11:31.184378+00	4684	Santiago (sede)-Especialistas/Maestria-2020-Anual-28.000	1	new through import_export	25	1
1965	2021-05-31 14:11:31.197825+00	4683	Santiago (sede)-Especialistas/Doctorado-2020-Anual-2.000	1	new through import_export	25	1
1966	2021-05-31 14:11:31.210371+00	4682	Nagua-Coordinadores/Maestria-2020-Anual-4.000	1	new through import_export	25	1
1967	2021-05-31 14:11:31.223257+00	4681	Nagua-Coordinadores/Doctorado-2020-Anual-1.000	1	new through import_export	25	1
1968	2021-05-31 14:11:31.236046+00	4680	Santo Domingo-Coordinadores/Maestria-2020-Anual-2.000	1	new through import_export	25	1
1969	2021-05-31 14:11:31.248986+00	4679	Santiago (sede)-Coordinadores/Maestria-2020-Anual-4.000	1	new through import_export	25	1
1970	2021-05-31 14:11:31.262155+00	4678	Santiago (sede)-Coordinadores/Doctorado-2020-Anual-2.000	1	new through import_export	25	1
1971	2021-05-31 14:11:31.274961+00	4677	Nagua-Directores-Encargados/Grado-Pregrado-2020-Anual-9.000	1	new through import_export	25	1
1972	2021-05-31 14:11:31.28732+00	4676	Nagua-Directores-Encargados/Maestria-2020-Anual-8.000	1	new through import_export	25	1
1973	2021-05-31 14:11:31.300346+00	4675	Santo Domingo-Directores-Encargados/Grado-Pregrado-2020-Anual-12.000	1	new through import_export	25	1
1974	2021-05-31 14:11:31.313149+00	4674	Santo Domingo-Directores-Encargados/Maestria-2020-Anual-17.000	1	new through import_export	25	1
1975	2021-05-31 14:11:31.325948+00	4673	Santiago (sede)-Directores-Encargados/Grado-Pregrado-2020-Anual-18.000	1	new through import_export	25	1
1976	2021-05-31 14:11:31.33869+00	4672	Santiago (sede)-Directores-Encargados/Maestria-2020-Anual-31.000	1	new through import_export	25	1
1977	2021-05-31 14:11:31.351409+00	4671	Santiago (sede)-Directores-Encargados/Doctorado-2020-Anual-4.000	1	new through import_export	25	1
1978	2021-05-31 14:11:31.365197+00	4670	Santiago (sede)-Vicerrectores/Maestria-2020-Anual-4.000	1	new through import_export	25	1
1979	2021-05-31 14:11:31.377767+00	4669	Santiago (sede)-Vicerrectores/Doctorado-2020-Anual-4.000	1	new through import_export	25	1
1980	2021-05-31 15:14:50.934783+00	4814	Nagua-Servicios Generales/Grado-Pregrado-2018-Anual-14	2	[]	25	1
1981	2021-05-31 15:15:35.796698+00	4814	Nagua-Servicios Generales/Grado-Pregrado-2018-Anual-14	2	[]	25	1
1982	2021-05-31 17:16:52.229721+00	25553	Cibao Oriental (Nagua)-Trabajo familiar	1	new through import_export	21	1
1983	2021-05-31 17:16:52.243157+00	25552	Cibao Oriental (Nagua)-Empleado en sector público	1	new through import_export	21	1
1984	2021-05-31 17:16:52.255858+00	25551	Cibao Oriental (Nagua)-Empleado en sector privado	1	new through import_export	21	1
1985	2021-05-31 17:16:52.269526+00	25550	Cibao Oriental (Nagua)-Dueño/cuenta propia	1	new through import_export	21	1
1986	2021-05-31 17:16:52.282568+00	25549	Santo Domingo Oriental-Trabajo familiar	1	new through import_export	21	1
1987	2021-05-31 17:16:52.295947+00	25548	Santo Domingo Oriental-Empleado en sector público	1	new through import_export	21	1
1988	2021-05-31 17:16:52.308803+00	25547	Santo Domingo Oriental-Empleado en sector privado	1	new through import_export	21	1
1989	2021-05-31 17:16:52.321689+00	25546	Santo Domingo Oriental-Dueño/cuenta propia	1	new through import_export	21	1
1990	2021-05-31 17:16:52.335139+00	25545	Santiago (sede)-Trabajo familiar	1	new through import_export	21	1
1991	2021-05-31 17:16:52.348233+00	25544	Santiago (sede)-Empleado en sector público	1	new through import_export	21	1
1992	2021-05-31 17:16:52.361412+00	25543	Santiago (sede)-Empleado en sector privado	1	new through import_export	21	1
1993	2021-05-31 17:16:52.374555+00	25542	Santiago (sede)-Dueño/cuenta propia	1	new through import_export	21	1
1994	2021-05-31 17:17:47.072177+00	5002	Cibao Oriental (Nagua)-Empleado en sector público-2019-Anual-33.300	1	new through import_export	25	1
1995	2021-05-31 17:17:47.085283+00	5001	Cibao Oriental (Nagua)-Empleado en sector privado-2019-Anual-66.700	1	new through import_export	25	1
1996	2021-05-31 17:17:47.097852+00	5000	Santo Domingo Oriental-Trabajo familiar-2019-Anual-20.000	1	new through import_export	25	1
1997	2021-05-31 17:17:47.110202+00	4999	Santo Domingo Oriental-Empleado en sector público-2019-Anual-20.000	1	new through import_export	25	1
1998	2021-05-31 17:17:47.122865+00	4998	Santo Domingo Oriental-Empleado en sector privado-2019-Anual-40.000	1	new through import_export	25	1
1999	2021-05-31 17:17:47.135908+00	4997	Santo Domingo Oriental-Dueño/cuenta propia-2019-Anual-20.000	1	new through import_export	25	1
2000	2021-05-31 17:17:47.148714+00	4996	Santiago (sede)-Trabajo familiar-2019-Anual-16.000	1	new through import_export	25	1
2001	2021-05-31 17:17:47.161627+00	4995	Santiago (sede)-Empleado en sector público-2019-Anual-8.000	1	new through import_export	25	1
2002	2021-05-31 17:17:47.178624+00	4994	Santiago (sede)-Empleado en sector privado-2019-Anual-56.000	1	new through import_export	25	1
2003	2021-05-31 17:17:47.191844+00	4993	Santiago (sede)-Dueño/cuenta propia-2019-Anual-20.000	1	new through import_export	25	1
2004	2021-05-31 17:17:47.204428+00	4992	Cibao Oriental (Nagua)-Trabajo familiar-2018-Anual-9.100	1	new through import_export	25	1
2005	2021-05-31 17:17:47.217378+00	4991	Cibao Oriental (Nagua)-Empleado en sector público-2018-Anual-40.900	1	new through import_export	25	1
2006	2021-05-31 17:17:47.230359+00	4990	Cibao Oriental (Nagua)-Empleado en sector privado-2018-Anual-18.200	1	new through import_export	25	1
2007	2021-05-31 17:17:47.242861+00	4989	Cibao Oriental (Nagua)-Dueño/cuenta propia-2018-Anual-31.800	1	new through import_export	25	1
2008	2021-05-31 17:17:47.25541+00	4988	Santo Domingo Oriental-Trabajo familiar-2018-Anual-7.800	1	new through import_export	25	1
2009	2021-05-31 17:17:47.268492+00	4987	Santo Domingo Oriental-Empleado en sector público-2018-Anual-45.600	1	new through import_export	25	1
2010	2021-05-31 17:17:47.281329+00	4986	Santo Domingo Oriental-Empleado en sector privado-2018-Anual-22.200	1	new through import_export	25	1
2011	2021-05-31 17:17:47.294315+00	4985	Santo Domingo Oriental-Dueño/cuenta propia-2018-Anual-24.400	1	new through import_export	25	1
2012	2021-05-31 17:17:47.306894+00	4984	Santiago (sede)-Trabajo familiar-2018-Anual-14.200	1	new through import_export	25	1
2013	2021-05-31 17:17:47.319687+00	4983	Santiago (sede)-Empleado en sector público-2018-Anual-30.600	1	new through import_export	25	1
2014	2021-05-31 17:17:47.332603+00	4982	Santiago (sede)-Empleado en sector privado-2018-Anual-39.600	1	new through import_export	25	1
2015	2021-05-31 17:17:47.34541+00	4981	Santiago (sede)-Dueño/cuenta propia-2018-Anual-15.700	1	new through import_export	25	1
2016	2021-05-31 17:17:47.358714+00	4980	Cibao Oriental (Nagua)-Empleado en sector público-2017-Anual-66.700	1	new through import_export	25	1
2017	2021-05-31 17:17:47.371178+00	4979	Cibao Oriental (Nagua)-Empleado en sector privado-2017-Anual-33.300	1	new through import_export	25	1
2018	2021-05-31 17:17:47.384265+00	4978	Santo Domingo Oriental-Trabajo familiar-2017-Anual-7.100	1	new through import_export	25	1
2019	2021-05-31 17:17:47.397163+00	4977	Santo Domingo Oriental-Empleado en sector público-2017-Anual-57.100	1	new through import_export	25	1
2020	2021-05-31 17:17:47.409545+00	4976	Santo Domingo Oriental-Empleado en sector privado-2017-Anual-28.600	1	new through import_export	25	1
2021	2021-05-31 17:17:47.422142+00	4975	Santo Domingo Oriental-Dueño/cuenta propia-2017-Anual-7.100	1	new through import_export	25	1
2022	2021-05-31 17:17:47.435235+00	4974	Santiago (sede)-Trabajo familiar-2017-Anual-4.700	1	new through import_export	25	1
2023	2021-05-31 17:17:47.447376+00	4973	Santiago (sede)-Empleado en sector público-2017-Anual-44.200	1	new through import_export	25	1
2024	2021-05-31 17:17:47.459802+00	4972	Santiago (sede)-Empleado en sector privado-2017-Anual-25.600	1	new through import_export	25	1
2025	2021-05-31 17:17:47.472663+00	4971	Santiago (sede)-Dueño/cuenta propia-2017-Anual-25.600	1	new through import_export	25	1
2026	2021-05-31 17:17:47.485826+00	4970	Cibao Oriental (Nagua)-Trabajo familiar-2021-Anual-37.500	1	new through import_export	25	1
2027	2021-05-31 17:17:47.498678+00	4969	Cibao Oriental (Nagua)-Empleado en sector público-2021-Anual-37.500	1	new through import_export	25	1
2028	2021-05-31 17:17:47.511477+00	4968	Cibao Oriental (Nagua)-Dueño/cuenta propia-2021-Anual-25.000	1	new through import_export	25	1
2029	2021-05-31 17:17:47.524014+00	4967	Santo Domingo Oriental-Trabajo familiar-2021-Anual-14.300	1	new through import_export	25	1
2030	2021-05-31 17:17:47.536712+00	4966	Santo Domingo Oriental-Empleado en sector público-2021-Anual-50.000	1	new through import_export	25	1
2031	2021-05-31 17:17:47.55099+00	4965	Santo Domingo Oriental-Empleado en sector privado-2021-Anual-14.300	1	new through import_export	25	1
2032	2021-05-31 17:17:47.564124+00	4964	Santo Domingo Oriental-Dueño/cuenta propia-2021-Anual-21.400	1	new through import_export	25	1
2033	2021-05-31 17:17:47.576667+00	4963	Santiago (sede)-Trabajo familiar-2021-Anual-6.600	1	new through import_export	25	1
2034	2021-05-31 17:17:47.588998+00	4962	Santiago (sede)-Empleado en sector público-2021-Anual-52.200	1	new through import_export	25	1
2035	2021-05-31 17:17:47.602181+00	4961	Santiago (sede)-Empleado en sector privado-2021-Anual-30.400	1	new through import_export	25	1
2036	2021-05-31 17:17:47.614989+00	4960	Santiago (sede)-Dueño/cuenta propia-2021-Anual-10.800	1	new through import_export	25	1
2037	2021-05-31 17:17:47.627406+00	4959	Cibao Oriental (Nagua)-Empleado en sector público-2020-Anual-83.300	1	new through import_export	25	1
2038	2021-05-31 17:17:47.640265+00	4958	Cibao Oriental (Nagua)-Empleado en sector privado-2020-Anual-16.700	1	new through import_export	25	1
2039	2021-05-31 17:17:47.653171+00	4957	Santo Domingo Oriental-Trabajo familiar-2020-Anual-65.200	1	new through import_export	25	1
2040	2021-05-31 17:17:47.666129+00	4956	Santo Domingo Oriental-Empleado en sector público-2020-Anual-26.100	1	new through import_export	25	1
2041	2021-05-31 17:17:47.678679+00	4955	Santo Domingo Oriental-Dueño/cuenta propia-2020-Anual-8.700	1	new through import_export	25	1
2042	2021-05-31 17:17:47.694975+00	4954	Santiago (sede)-Trabajo familiar-2020-Anual-1.700	1	new through import_export	25	1
2043	2021-05-31 17:17:47.709077+00	4953	Santiago (sede)-Empleado en sector público-2020-Anual-38.300	1	new through import_export	25	1
2044	2021-05-31 17:17:47.725903+00	4952	Santiago (sede)-Empleado en sector privado-2020-Anual-40.000	1	new through import_export	25	1
2045	2021-05-31 17:17:47.745353+00	4951	Santiago (sede)-Dueño/cuenta propia-2020-Anual-20.000	1	new through import_export	25	1
2046	2021-08-13 14:41:35.579252+00	24831	Nagua-Seminarios / Certificacion de coaching	1	new through import_export	21	2
2047	2021-08-13 14:41:35.596982+00	24830	Santo Domingo-Seminarios / Certificacion de coaching	1	new through import_export	21	2
2048	2021-08-13 14:41:35.610369+00	24829	Santiago (sede)-Seminarios / Certificacion de coaching	1	new through import_export	21	2
2049	2021-08-13 14:41:35.623898+00	24828	Nagua-Seminarios / Conferencias	1	new through import_export	21	2
2050	2021-08-13 14:41:35.637788+00	24827	Santo Domingo-Seminarios / Conferencias	1	new through import_export	21	2
2051	2021-08-13 14:41:35.651174+00	24826	Santiago (sede)-Seminarios / Conferencias	1	new through import_export	21	2
2052	2021-08-13 14:41:35.665322+00	24825	Nagua-Seminarios	1	new through import_export	21	2
2053	2021-08-13 14:41:35.679239+00	24824	Nagua-Cursos/ talleres	1	new through import_export	21	2
2054	2021-08-13 14:41:35.693178+00	24823	Nagua-Diplomados	1	new through import_export	21	2
2055	2021-08-13 14:41:35.706291+00	24822	Santo Domingo-Seminarios	1	new through import_export	21	2
2056	2021-08-13 14:41:35.719931+00	24821	Santo Domingo-Cursos/ talleres	1	new through import_export	21	2
2057	2021-08-13 14:41:35.732984+00	24820	Santo Domingo-Diplomados	1	new through import_export	21	2
2058	2021-08-13 14:41:35.745726+00	24819	Santiago (sede)-Seminarios	1	new through import_export	21	2
2059	2021-08-13 14:41:35.758983+00	24818	Santiago (sede)-Cursos/ talleres	1	new through import_export	21	2
2060	2021-08-13 14:41:35.772642+00	24817	Santiago (sede)-Diplomados	1	new through import_export	21	2
2061	2021-08-13 14:42:08.269658+00	776	Nagua-Cursos/ talleres-2019-Anual-3	1	new through import_export	25	2
2062	2021-08-13 14:42:08.282917+00	775	Nagua-Diplomados-2019-Anual-2	1	new through import_export	25	2
2063	2021-08-13 14:42:08.295999+00	774	Santiago (sede)-Cursos/ talleres-2019-Anual-1	1	new through import_export	25	2
2064	2021-08-13 14:42:08.315975+00	773	Santiago (sede)-Diplomados-2019-Anual-19	1	new through import_export	25	2
2065	2021-08-13 14:42:08.335255+00	772	Nagua-Cursos/ talleres-2018-Anual-4	1	new through import_export	25	2
2066	2021-08-13 14:42:08.361421+00	771	Nagua-Diplomados-2018-Anual-2	1	new through import_export	25	2
2067	2021-08-13 14:42:08.388983+00	770	Santo Domingo-Cursos/ talleres-2018-Anual-7	1	new through import_export	25	2
2068	2021-08-13 14:42:08.417584+00	769	Santo Domingo-Diplomados-2018-Anual-5	1	new through import_export	25	2
2069	2021-08-13 14:42:08.445298+00	768	Santiago (sede)-Seminarios / Certificacion de coaching-2018-Anual-1	1	new through import_export	25	2
2070	2021-08-13 14:42:08.464734+00	767	Santiago (sede)-Cursos/ talleres-2018-Anual-11	1	new through import_export	25	2
2071	2021-08-13 14:42:08.485424+00	766	Santiago (sede)-Diplomados-2018-Anual-33	1	new through import_export	25	2
2072	2021-08-13 14:42:08.505837+00	765	Nagua-Seminarios / Conferencias-2017-Anual-5	1	new through import_export	25	2
2073	2021-08-13 14:42:08.523137+00	764	Nagua-Cursos/ talleres-2017-Anual-5	1	new through import_export	25	2
2074	2021-08-13 14:42:08.536443+00	763	Nagua-Diplomados-2017-Anual-18	1	new through import_export	25	2
2075	2021-08-13 14:42:08.554873+00	762	Santo Domingo-Seminarios / Conferencias-2017-Anual-5	1	new through import_export	25	2
2076	2021-08-13 14:42:08.567748+00	761	Santo Domingo-Cursos/ talleres-2017-Anual-12	1	new through import_export	25	2
2077	2021-08-13 14:42:08.581111+00	760	Santo Domingo-Diplomados-2017-Anual-1	1	new through import_export	25	2
2078	2021-08-13 14:42:08.594931+00	759	Santiago (sede)-Seminarios / Conferencias-2017-Anual-6	1	new through import_export	25	2
2079	2021-08-13 14:42:08.60844+00	758	Santiago (sede)-Cursos/ talleres-2017-Anual-13	1	new through import_export	25	2
2080	2021-08-13 14:42:08.621791+00	757	Santiago (sede)-Diplomados-2017-Anual-35	1	new through import_export	25	2
2081	2021-08-13 14:42:08.635075+00	756	Nagua-Seminarios-2021-Anual-3	1	new through import_export	25	2
2082	2021-08-13 14:42:08.648401+00	755	Nagua-Cursos/ talleres-2021-Anual-17	1	new through import_export	25	2
2083	2021-08-13 14:42:08.661733+00	754	Nagua-Diplomados-2021-Anual-24	1	new through import_export	25	2
2084	2021-08-13 14:42:08.673961+00	753	Santo Domingo-Seminarios-2021-Anual-1	1	new through import_export	25	2
2085	2021-08-13 14:42:08.68745+00	752	Santo Domingo-Cursos/ talleres-2021-Anual-20	1	new through import_export	25	2
2086	2021-08-13 14:42:08.700486+00	751	Santo Domingo-Diplomados-2021-Anual-8	1	new through import_export	25	2
2087	2021-08-13 14:42:08.713934+00	750	Santiago (sede)-Seminarios-2021-Anual-14	1	new through import_export	25	2
2088	2021-08-13 14:42:08.727054+00	749	Santiago (sede)-Cursos/ talleres-2021-Anual-9	1	new through import_export	25	2
2089	2021-08-13 14:42:08.73979+00	748	Santiago (sede)-Diplomados-2021-Anual-53	1	new through import_export	25	2
2090	2021-08-13 15:18:50.829421+00	776	Nagua-Cursos/ talleres-2019-Anual-3.000	3		25	2
2091	2021-08-13 15:18:50.84479+00	775	Nagua-Diplomados-2019-Anual-2.000	3		25	2
2092	2021-08-13 15:18:50.85909+00	774	Santiago (sede)-Cursos/ talleres-2019-Anual-1.000	3		25	2
2093	2021-08-13 15:18:50.873033+00	773	Santiago (sede)-Diplomados-2019-Anual-19.000	3		25	2
2094	2021-08-13 15:18:50.887313+00	772	Nagua-Cursos/ talleres-2018-Anual-4.000	3		25	2
2095	2021-08-13 15:18:50.900497+00	771	Nagua-Diplomados-2018-Anual-2.000	3		25	2
2096	2021-08-13 15:18:50.914417+00	770	Santo Domingo-Cursos/ talleres-2018-Anual-7.000	3		25	2
2097	2021-08-13 15:18:50.927616+00	769	Santo Domingo-Diplomados-2018-Anual-5.000	3		25	2
2098	2021-08-13 15:18:50.941632+00	768	Santiago (sede)-Seminarios / Certificacion de coaching-2018-Anual-1.000	3		25	2
2099	2021-08-13 15:18:50.954801+00	767	Santiago (sede)-Cursos/ talleres-2018-Anual-11.000	3		25	2
2100	2021-08-13 15:18:50.967993+00	766	Santiago (sede)-Diplomados-2018-Anual-33.000	3		25	2
2101	2021-08-13 15:18:50.98202+00	765	Nagua-Seminarios / Conferencias-2017-Anual-5.000	3		25	2
2102	2021-08-13 15:18:50.996302+00	764	Nagua-Cursos/ talleres-2017-Anual-5.000	3		25	2
2103	2021-08-13 15:18:51.010559+00	763	Nagua-Diplomados-2017-Anual-18.000	3		25	2
2104	2021-08-13 15:18:51.024024+00	762	Santo Domingo-Seminarios / Conferencias-2017-Anual-5.000	3		25	2
2105	2021-08-13 15:18:51.036821+00	761	Santo Domingo-Cursos/ talleres-2017-Anual-12.000	3		25	2
2106	2021-08-13 15:18:51.050712+00	760	Santo Domingo-Diplomados-2017-Anual-1.000	3		25	2
2107	2021-08-13 15:18:51.065956+00	759	Santiago (sede)-Seminarios / Conferencias-2017-Anual-6.000	3		25	2
2108	2021-08-13 15:18:51.079732+00	758	Santiago (sede)-Cursos/ talleres-2017-Anual-13.000	3		25	2
2109	2021-08-13 15:18:51.094707+00	757	Santiago (sede)-Diplomados-2017-Anual-35.000	3		25	2
2110	2021-08-13 15:18:51.109046+00	756	Nagua-Seminarios-2021-Anual-3.000	3		25	2
2111	2021-08-13 15:18:51.12359+00	755	Nagua-Cursos/ talleres-2021-Anual-17.000	3		25	2
2112	2021-08-13 15:18:51.138156+00	754	Nagua-Diplomados-2021-Anual-24.000	3		25	2
2113	2021-08-13 15:18:51.15317+00	753	Santo Domingo-Seminarios-2021-Anual-1.000	3		25	2
2114	2021-08-13 15:18:51.167853+00	752	Santo Domingo-Cursos/ talleres-2021-Anual-20.000	3		25	2
2115	2021-08-13 15:18:51.182731+00	751	Santo Domingo-Diplomados-2021-Anual-8.000	3		25	2
2116	2021-08-13 15:18:51.197411+00	750	Santiago (sede)-Seminarios-2021-Anual-14.000	3		25	2
2117	2021-08-13 15:18:51.212282+00	749	Santiago (sede)-Cursos/ talleres-2021-Anual-9.000	3		25	2
2118	2021-08-13 15:18:51.227074+00	748	Santiago (sede)-Diplomados-2021-Anual-53.000	3		25	2
2119	2021-08-13 15:19:25.990435+00	776	Nagua-Cursos/ talleres-2019-Anual-3	1	new through import_export	25	2
2120	2021-08-13 15:19:26.00394+00	775	Nagua-Diplomados-2019-Anual-2	1	new through import_export	25	2
2121	2021-08-13 15:19:26.016127+00	774	Santiago (sede)-Cursos/ talleres-2019-Anual-1	1	new through import_export	25	2
2122	2021-08-13 15:19:26.028854+00	773	Santiago (sede)-Diplomados-2019-Anual-19	1	new through import_export	25	2
2123	2021-08-13 15:19:26.041826+00	772	Nagua-Cursos/ talleres-2018-Anual-4	1	new through import_export	25	2
2124	2021-08-13 15:19:26.055238+00	771	Nagua-Diplomados-2018-Anual-2	1	new through import_export	25	2
2125	2021-08-13 15:19:26.069081+00	770	Santo Domingo-Cursos/ talleres-2018-Anual-7	1	new through import_export	25	2
2126	2021-08-13 15:19:26.082793+00	769	Santo Domingo-Diplomados-2018-Anual-5	1	new through import_export	25	2
2127	2021-08-13 15:19:26.098368+00	768	Santiago (sede)-Seminarios / Certificacion de coaching-2018-Anual-1	1	new through import_export	25	2
2128	2021-08-13 15:19:26.116087+00	767	Santiago (sede)-Cursos/ talleres-2018-Anual-11	1	new through import_export	25	2
2129	2021-08-13 15:19:26.134468+00	766	Santiago (sede)-Diplomados-2018-Anual-33	1	new through import_export	25	2
2130	2021-08-13 15:19:26.152274+00	765	Nagua-Seminarios / Conferencias-2017-Anual-5	1	new through import_export	25	2
2131	2021-08-13 15:19:26.165543+00	764	Nagua-Cursos/ talleres-2017-Anual-5	1	new through import_export	25	2
2132	2021-08-13 15:19:26.178561+00	763	Nagua-Diplomados-2017-Anual-18	1	new through import_export	25	2
2133	2021-08-13 15:19:26.19224+00	762	Santo Domingo-Seminarios / Conferencias-2017-Anual-5	1	new through import_export	25	2
2134	2021-08-13 15:19:26.206197+00	761	Santo Domingo-Cursos/ talleres-2017-Anual-12	1	new through import_export	25	2
2135	2021-08-13 15:19:26.219781+00	760	Santo Domingo-Diplomados-2017-Anual-1	1	new through import_export	25	2
2136	2021-08-13 15:19:26.233117+00	759	Santiago (sede)-Seminarios / Conferencias-2017-Anual-6	1	new through import_export	25	2
2137	2021-08-13 15:19:26.246203+00	758	Santiago (sede)-Cursos/ talleres-2017-Anual-13	1	new through import_export	25	2
2138	2021-08-13 15:19:26.260534+00	757	Santiago (sede)-Diplomados-2017-Anual-35	1	new through import_export	25	2
2139	2021-08-13 15:19:26.274632+00	756	Nagua-Seminarios-2021-Anual-3	1	new through import_export	25	2
2140	2021-08-13 15:19:26.289319+00	755	Nagua-Cursos/ talleres-2021-Anual-17	1	new through import_export	25	2
2141	2021-08-13 15:19:26.304223+00	754	Nagua-Diplomados-2021-Anual-24	1	new through import_export	25	2
2142	2021-08-13 15:19:26.317563+00	753	Santo Domingo-Seminarios-2021-Anual-1	1	new through import_export	25	2
2143	2021-08-13 15:19:26.332009+00	752	Santo Domingo-Cursos/ talleres-2021-Anual-20	1	new through import_export	25	2
2144	2021-08-13 15:19:26.347387+00	751	Santo Domingo-Diplomados-2021-Anual-8	1	new through import_export	25	2
2145	2021-08-13 15:19:26.3632+00	750	Santiago (sede)-Seminarios-2021-Anual-14	1	new through import_export	25	2
2146	2021-08-13 15:19:26.377857+00	749	Santiago (sede)-Cursos/ talleres-2021-Anual-9	1	new through import_export	25	2
2147	2021-08-13 15:19:26.39226+00	748	Santiago (sede)-Diplomados-2021-Anual-53	1	new through import_export	25	2
2148	2021-08-13 15:25:04.993743+00	772	Nagua-Cursos/ talleres-2018-Anual-4.000	2	update through import_export	25	2
2149	2021-08-13 15:25:05.006167+00	771	Nagua-Diplomados-2018-Anual-2.000	2	update through import_export	25	2
2150	2021-08-13 15:25:05.018557+00	770	Santo Domingo-Cursos/ talleres-2018-Anual-7.000	2	update through import_export	25	2
2151	2021-08-13 15:25:05.032011+00	769	Santo Domingo-Diplomados-2018-Anual-5.000	2	update through import_export	25	2
2152	2021-08-13 15:25:05.045678+00	768	Santiago (sede)-Seminarios / Certificacion de coaching-2018-Anual-1.000	2	update through import_export	25	2
2153	2021-08-13 15:25:05.059228+00	767	Santiago (sede)-Cursos/ talleres-2018-Anual-11.000	2	update through import_export	25	2
2154	2021-08-13 15:25:05.071953+00	766	Santiago (sede)-Diplomados-2018-Anual-33.000	2	update through import_export	25	2
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	authtoken	token
13	authtoken	tokenproxy
14	users	user
15	core	algoritmo
16	core	componente
17	core	corte
18	core	indicador
19	core	ovu
20	core	termino
21	core	segregacion
22	core	referencia
23	core	objetivos
24	core	fuenteinformacion
25	core	dato
26	core	informe
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2021-05-03 13:49:15.666101+00
2	contenttypes	0002_remove_content_type_name	2021-05-03 13:49:15.680893+00
3	auth	0001_initial	2021-05-03 13:49:15.713721+00
4	auth	0002_alter_permission_name_max_length	2021-05-03 13:49:15.7423+00
5	auth	0003_alter_user_email_max_length	2021-05-03 13:49:15.75525+00
6	auth	0004_alter_user_username_opts	2021-05-03 13:49:15.770245+00
7	auth	0005_alter_user_last_login_null	2021-05-03 13:49:15.782838+00
8	auth	0006_require_contenttypes_0002	2021-05-03 13:49:15.786501+00
9	auth	0007_alter_validators_add_error_messages	2021-05-03 13:49:15.797952+00
10	auth	0008_alter_user_username_max_length	2021-05-03 13:49:15.812465+00
11	users	0001_initial	2021-05-03 13:49:15.842473+00
12	account	0001_initial	2021-05-03 13:49:15.947199+00
13	account	0002_email_max_length	2021-05-03 13:49:16.000559+00
14	admin	0001_initial	2021-05-03 13:49:16.04592+00
15	admin	0002_logentry_remove_auto_add	2021-05-03 13:49:16.089796+00
16	admin	0003_logentry_add_action_flag_choices	2021-05-03 13:49:16.120332+00
17	auth	0009_alter_user_last_name_max_length	2021-05-03 13:49:16.156841+00
18	auth	0010_alter_group_name_max_length	2021-05-03 13:49:16.195825+00
19	auth	0011_update_proxy_permissions	2021-05-03 13:49:16.237397+00
20	auth	0012_alter_user_first_name_max_length	2021-05-03 13:49:16.269086+00
21	authtoken	0001_initial	2021-05-03 13:49:16.306118+00
22	authtoken	0002_auto_20160226_1747	2021-05-03 13:49:16.384637+00
23	authtoken	0003_tokenproxy	2021-05-03 13:49:16.388897+00
24	core	0001_initial	2021-05-03 13:49:16.524432+00
25	core	0002_auto_20200929_1857	2021-05-03 13:49:16.591459+00
26	core	0003_auto_20200929_1859	2021-05-03 13:49:16.607832+00
27	core	0004_auto_20200929_1900	2021-05-03 13:49:16.615273+00
28	core	0005_auto_20201215_2200	2021-05-03 13:49:16.673669+00
29	core	0006_auto_20201216_0220	2021-05-03 13:49:16.688777+00
30	core	0007_auto_20201228_0239	2021-05-03 13:49:16.712587+00
31	core	0008_auto_20201228_0304	2021-05-03 13:49:16.738378+00
32	core	0009_auto_20201228_0318	2021-05-03 13:49:16.771462+00
33	core	0010_auto_20201230_0004	2021-05-03 13:49:16.791855+00
34	core	0011_auto_20201230_0012	2021-05-03 13:49:16.811416+00
35	core	0012_auto_20210221_2009	2021-05-03 13:49:16.821485+00
36	sessions	0001_initial	2021-05-03 13:49:16.833522+00
37	sites	0001_initial	2021-05-03 13:49:16.848258+00
38	sites	0002_alter_domain_unique	2021-05-03 13:49:16.861346+00
39	sites	0003_set_site_domain_and_name	2021-05-03 13:49:16.91027+00
40	sites	0004_alter_options_ordering_domain	2021-05-03 13:49:16.918895+00
41	socialaccount	0001_initial	2021-05-03 13:49:17.010191+00
42	socialaccount	0002_token_max_lengths	2021-05-03 13:49:17.079596+00
43	socialaccount	0003_extra_data_default_dict	2021-05-03 13:49:17.093719+00
44	core	0013_auto_20210525_1648	2021-05-25 16:48:26.277515+00
45	core	0014_informe_visible	2021-05-25 16:51:04.674084+00
46	core	0015_informe_url	2021-05-27 13:21:12.473077+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
gmw9yhd92bbpkpow2y2vefjddvd3wu48	.eJxVjDsOwyAQRO9CHSHWfDdlep8BAQvBSYQlY1dR7h5bcpFUI817M2_mw7ZWv_W8-InYlQG7_HYxpGduB6BHaPeZp7mtyxT5ofCTdj7OlF-30_07qKHXfe2UQT0QoaA9tFXFKEdYwAZQMitnkhUDKEqaUJYgcgRMsaCWMgEQ-3wBxxQ3fw:1ldZ8c:n48Sxk7JG-eAM8fhinQHhTzWQ7Dilvgj5PVocmEfHqU	2021-05-17 14:01:30.308949+00
lai9omfnt8bwe02s5v42x9engq7f4fy2	.eJxVjDsOwyAQRO9CHSHWfDdlep8BAQvBSYQlY1dR7h5bcpFUI817M2_mw7ZWv_W8-InYlQG7_HYxpGduB6BHaPeZp7mtyxT5ofCTdj7OlF-30_07qKHXfe2UQT0QoaA9tFXFKEdYwAZQMitnkhUDKEqaUJYgcgRMsaCWMgEQ-3wBxxQ3fw:1lfOuI:vyIjHclxfFxp84pY_eUZglWYVS4Q7L63i54tRRSK6Co	2021-05-22 15:30:18.306693+00
lemg90bo2o5w13gbgnq1e3jm5aoga32g	.eJxVjDsOwyAQRO9CHSHWfDdlep8BAQvBSYQlY1dR7h5bcpFUI817M2_mw7ZWv_W8-InYlQG7_HYxpGduB6BHaPeZp7mtyxT5ofCTdj7OlF-30_07qKHXfe2UQT0QoaA9tFXFKEdYwAZQMitnkhUDKEqaUJYgcgRMsaCWMgEQ-3wBxxQ3fw:1llYce:Wm0ks6Mg1WHQSu1SwKDSDN9H-_fDEgWzOXGFtv1eLaM	2021-06-08 15:05:32.873162+00
uz56tw0q7vj2ji05ke5hfaqqj17qc9jz	.eJxVjM0OwiAQhN-FsyGwVn48eu8zENhdpGogKe3J-O62SQ96m8z3zbxFiOtSwtp5DhOJqwBx-u1SxCfXHdAj1nuT2OoyT0nuijxol2Mjft0O9--gxF62dUyQUSl7Jm0I2aq4JRgcZz-Qz-mC4Ng70NoqtinljAY8K_IG0CsUny_53Dhk:1mEYLx:EIfXvtArV6x8iJ-ww3K8rsjpt9OvehinF5zgDOX2UD4	2021-08-27 14:40:09.57591+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.django_site (id, domain, name) FROM stdin;
1	example.com	OVU
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.users_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$N0pDandkdWZBbDBw$0vvEi9NS8CLDVjOvikCogw	2021-05-25 15:05:32.735044+00	t	admin		t	t	2021-05-03 14:01:17.638978+00	
2	argon2$argon2i$v=19$m=512,t=2,p=2$alZ0M1p0OVhXdnd6$7EjqnFinviXF+fTCrPC5KQ	2021-08-13 14:40:09.450822+00	t	maparicio	maparicio@uapa.edu.do	t	t	2021-08-13 14:39:39.716661+00	
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 104, true);


--
-- Name: core_algoritmo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_algoritmo_id_seq', 463, true);


--
-- Name: core_componente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_componente_id_seq', 72, true);


--
-- Name: core_corte_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_corte_id_seq', 6, true);


--
-- Name: core_dato_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_dato_id_seq', 5002, true);


--
-- Name: core_fuenteinformacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_fuenteinformacion_id_seq', 1, false);


--
-- Name: core_indicador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_indicador_id_seq', 356, true);


--
-- Name: core_informe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_informe_id_seq', 3, true);


--
-- Name: core_objetivos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_objetivos_id_seq', 1, false);


--
-- Name: core_ovu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_ovu_id_seq', 1, false);


--
-- Name: core_referencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_referencia_id_seq', 1, false);


--
-- Name: core_referencia_indicador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_referencia_indicador_id_seq', 1, false);


--
-- Name: core_segregacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_segregacion_id_seq', 25553, true);


--
-- Name: core_segregacion_indicador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_segregacion_indicador_id_seq', 1682, true);


--
-- Name: core_termino_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.core_termino_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 2154, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 26, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 46, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.users_user_id_seq', 2, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: core_algoritmo core_algoritmo_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_algoritmo
    ADD CONSTRAINT core_algoritmo_pkey PRIMARY KEY (id);


--
-- Name: core_componente core_componente_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_componente
    ADD CONSTRAINT core_componente_pkey PRIMARY KEY (id);


--
-- Name: core_corte core_corte_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_corte
    ADD CONSTRAINT core_corte_pkey PRIMARY KEY (id);


--
-- Name: core_dato core_dato_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato
    ADD CONSTRAINT core_dato_pkey PRIMARY KEY (id);


--
-- Name: core_dato core_dato_segregacion_id_corte_id_indicador_id_8bd37e04_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato
    ADD CONSTRAINT core_dato_segregacion_id_corte_id_indicador_id_8bd37e04_uniq UNIQUE (segregacion_id, corte_id, indicador_id);


--
-- Name: core_fuenteinformacion core_fuenteinformacion_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_fuenteinformacion
    ADD CONSTRAINT core_fuenteinformacion_pkey PRIMARY KEY (id);


--
-- Name: core_indicador core_indicador_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_indicador
    ADD CONSTRAINT core_indicador_pkey PRIMARY KEY (id);


--
-- Name: core_informe core_informe_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_informe
    ADD CONSTRAINT core_informe_pkey PRIMARY KEY (id);


--
-- Name: core_objetivos core_objetivos_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_objetivos
    ADD CONSTRAINT core_objetivos_pkey PRIMARY KEY (id);


--
-- Name: core_ovu core_ovu_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_ovu
    ADD CONSTRAINT core_ovu_pkey PRIMARY KEY (id);


--
-- Name: core_referencia_indicador core_referencia_indicado_referencia_id_indicador__f0a36faf_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia_indicador
    ADD CONSTRAINT core_referencia_indicado_referencia_id_indicador__f0a36faf_uniq UNIQUE (referencia_id, indicador_id);


--
-- Name: core_referencia_indicador core_referencia_indicador_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia_indicador
    ADD CONSTRAINT core_referencia_indicador_pkey PRIMARY KEY (id);


--
-- Name: core_referencia core_referencia_institucion_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia
    ADD CONSTRAINT core_referencia_institucion_key UNIQUE (institucion);


--
-- Name: core_referencia core_referencia_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia
    ADD CONSTRAINT core_referencia_pkey PRIMARY KEY (id);


--
-- Name: core_segregacion_indicador core_segregacion_indicad_segregacion_id_indicador_b0db659f_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion_indicador
    ADD CONSTRAINT core_segregacion_indicad_segregacion_id_indicador_b0db659f_uniq UNIQUE (segregacion_id, indicador_id);


--
-- Name: core_segregacion_indicador core_segregacion_indicador_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion_indicador
    ADD CONSTRAINT core_segregacion_indicador_pkey PRIMARY KEY (id);


--
-- Name: core_segregacion core_segregacion_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion
    ADD CONSTRAINT core_segregacion_pkey PRIMARY KEY (id);


--
-- Name: core_termino core_termino_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_termino
    ADD CONSTRAINT core_termino_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: core_algoritmo_indicador_id_a35f7977; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_algoritmo_indicador_id_a35f7977 ON public.core_algoritmo USING btree (indicador_id);


--
-- Name: core_dato_corte_id_f8e9fb73; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_dato_corte_id_f8e9fb73 ON public.core_dato USING btree (corte_id);


--
-- Name: core_dato_indicador_id_2e417823; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_dato_indicador_id_2e417823 ON public.core_dato USING btree (indicador_id);


--
-- Name: core_dato_segregacion_id_c6c6bae0; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_dato_segregacion_id_c6c6bae0 ON public.core_dato USING btree (segregacion_id);


--
-- Name: core_fuenteinformacion_indicador_id_be2e2b9e; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_fuenteinformacion_indicador_id_be2e2b9e ON public.core_fuenteinformacion USING btree (indicador_id);


--
-- Name: core_fuenteinformacion_termino_id_391071c7; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_fuenteinformacion_termino_id_391071c7 ON public.core_fuenteinformacion USING btree (termino_id);


--
-- Name: core_indicador_componente_id_f76e3bf6; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_indicador_componente_id_f76e3bf6 ON public.core_indicador USING btree (componente_id);


--
-- Name: core_objetivos_ovu_id_f9c6ab02; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_objetivos_ovu_id_f9c6ab02 ON public.core_objetivos USING btree (ovu_id);


--
-- Name: core_referencia_indicador_indicador_id_da1b5868; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_referencia_indicador_indicador_id_da1b5868 ON public.core_referencia_indicador USING btree (indicador_id);


--
-- Name: core_referencia_indicador_referencia_id_0e0192de; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_referencia_indicador_referencia_id_0e0192de ON public.core_referencia_indicador USING btree (referencia_id);


--
-- Name: core_referencia_institucion_c4268dfc_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_referencia_institucion_c4268dfc_like ON public.core_referencia USING btree (institucion varchar_pattern_ops);


--
-- Name: core_segregacion_indicador_indicador_id_bbd0de9f; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_segregacion_indicador_indicador_id_bbd0de9f ON public.core_segregacion_indicador USING btree (indicador_id);


--
-- Name: core_segregacion_indicador_segregacion_id_273f156d; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_segregacion_indicador_segregacion_id_273f156d ON public.core_segregacion_indicador USING btree (segregacion_id);


--
-- Name: core_termino_algoritmo_id_8bfe8b03; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX core_termino_algoritmo_id_8bfe8b03 ON public.core_termino USING btree (algoritmo_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_algoritmo core_algoritmo_indicador_id_a35f7977_fk_core_indicador_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_algoritmo
    ADD CONSTRAINT core_algoritmo_indicador_id_a35f7977_fk_core_indicador_id FOREIGN KEY (indicador_id) REFERENCES public.core_indicador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dato core_dato_corte_id_f8e9fb73_fk_core_corte_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato
    ADD CONSTRAINT core_dato_corte_id_f8e9fb73_fk_core_corte_id FOREIGN KEY (corte_id) REFERENCES public.core_corte(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dato core_dato_indicador_id_2e417823_fk_core_indicador_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato
    ADD CONSTRAINT core_dato_indicador_id_2e417823_fk_core_indicador_id FOREIGN KEY (indicador_id) REFERENCES public.core_indicador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_dato core_dato_segregacion_id_c6c6bae0_fk_core_segregacion_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_dato
    ADD CONSTRAINT core_dato_segregacion_id_c6c6bae0_fk_core_segregacion_id FOREIGN KEY (segregacion_id) REFERENCES public.core_segregacion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_fuenteinformacion core_fuenteinformaci_indicador_id_be2e2b9e_fk_core_indi; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_fuenteinformacion
    ADD CONSTRAINT core_fuenteinformaci_indicador_id_be2e2b9e_fk_core_indi FOREIGN KEY (indicador_id) REFERENCES public.core_indicador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_fuenteinformacion core_fuenteinformacion_termino_id_391071c7_fk_core_termino_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_fuenteinformacion
    ADD CONSTRAINT core_fuenteinformacion_termino_id_391071c7_fk_core_termino_id FOREIGN KEY (termino_id) REFERENCES public.core_termino(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_indicador core_indicador_componente_id_f76e3bf6_fk_core_componente_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_indicador
    ADD CONSTRAINT core_indicador_componente_id_f76e3bf6_fk_core_componente_id FOREIGN KEY (componente_id) REFERENCES public.core_componente(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_objetivos core_objetivos_ovu_id_f9c6ab02_fk_core_ovu_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_objetivos
    ADD CONSTRAINT core_objetivos_ovu_id_f9c6ab02_fk_core_ovu_id FOREIGN KEY (ovu_id) REFERENCES public.core_ovu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_referencia_indicador core_referencia_indi_indicador_id_da1b5868_fk_core_indi; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia_indicador
    ADD CONSTRAINT core_referencia_indi_indicador_id_da1b5868_fk_core_indi FOREIGN KEY (indicador_id) REFERENCES public.core_indicador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_referencia_indicador core_referencia_indi_referencia_id_0e0192de_fk_core_refe; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_referencia_indicador
    ADD CONSTRAINT core_referencia_indi_referencia_id_0e0192de_fk_core_refe FOREIGN KEY (referencia_id) REFERENCES public.core_referencia(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_segregacion_indicador core_segregacion_ind_indicador_id_bbd0de9f_fk_core_indi; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion_indicador
    ADD CONSTRAINT core_segregacion_ind_indicador_id_bbd0de9f_fk_core_indi FOREIGN KEY (indicador_id) REFERENCES public.core_indicador(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_segregacion_indicador core_segregacion_ind_segregacion_id_273f156d_fk_core_segr; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_segregacion_indicador
    ADD CONSTRAINT core_segregacion_ind_segregacion_id_273f156d_fk_core_segr FOREIGN KEY (segregacion_id) REFERENCES public.core_segregacion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_termino core_termino_algoritmo_id_8bfe8b03_fk_core_algoritmo_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.core_termino
    ADD CONSTRAINT core_termino_algoritmo_id_8bfe8b03_fk_core_algoritmo_id FOREIGN KEY (algoritmo_id) REFERENCES public.core_algoritmo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: PDIQwBRBjmGuZHJpiaXRLttvvhSUJvMF
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

